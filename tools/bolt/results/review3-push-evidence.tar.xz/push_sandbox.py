from pathlib import Path
import json,sys,re
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');S=E.parent/'bolt-v4-20261013/v41/llvm-source';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
material=json.loads((E/'materials-published.json').read_text());h.require(material['status']=='PASS','GitHub materials not verified')
manifest=json.loads((E/'source-result.json').read_text());commit=manifest['draft_commit'];branch='refs/heads/sandbox/lhmax2025/bolt_pgo'
result={'status':'RUNNING','source_commit':commit,'material_pin':material['material_pin'],'branch':branch,'force':False,'Quickbuild_started':False}
try:
 def remote(label):
  text=h.call(['git','ls-remote','origin',branch],E/(label+'.txt'),cwd=S,timeout=120)
  rows=re.findall(r'^([0-9a-f]{40})\t'+re.escape(branch)+r'$',text,re.M)
  h.require(len(rows)==1,'unexpected sandbox remote query output');return rows[0]
 result['before']=remote('sandbox-before')
 h.require(result['before']==manifest['base'],'sandbox changed from expected b7 base; stop without push')
 h.call(['git','merge-base','--is-ancestor',result['before'],commit],E/'sandbox-ancestry.txt',cwd=S,timeout=30)
 h.call(['git','push','origin',commit+':'+branch],E/'sandbox-push.txt',cwd=S,timeout=180)
 result['after']=remote('sandbox-after');h.require(result['after']==commit,'sandbox remote after push does not match source')
 result['status']='PASS'
except BaseException as error:
 result['status']='FAIL';result['error']=str(error);raise
finally:
 h.save(E/'sandbox-result.json',result);print(json.dumps(result,indent=2),flush=True)
