%define debug_package %{nil}
Name: bolt-macro-proof
Version: 1
Release: 1
Summary: Literal production post macro fragment proof
License: Apache-2.0
Source1201: clang-bolt-helper.py
%define buildsubdir llvm-22.1.8
%define llvm_version 22
%description
Configuration evidence only; no claim of a new rpmbuild execution.
%prep
%build
%install
mkdir -p %{buildroot}/usr/bin
%files
/usr/bin/clang-22
%global __bolt_original_spec_install_post %{__spec_install_post}
%define __spec_install_post \
    %{__bolt_original_spec_install_post} \
    python3 %{SOURCE1201} post "%{buildroot}" "%{_builddir}/%{buildsubdir}/build/clang-bolt/install-state.json" "%{_builddir}/%{buildsubdir}/build/clang-bolt/ordinary-clang-22" "%{_builddir}/%{buildsubdir}/build/clang-bolt/post-gate" --resource-dir "%{buildroot}%{_libdir}/clang/%{llvm_version}" || exit 1
