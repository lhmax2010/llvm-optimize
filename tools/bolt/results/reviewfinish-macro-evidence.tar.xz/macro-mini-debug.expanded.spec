Name: bolt-macro-proof
Version: 1
Release: 1
Summary: Literal production post macro fragment proof
License: Apache-2.0
Source1201: clang-bolt-helper.py


%description
Configuration evidence only; no claim of a new rpmbuild execution.



%package debuginfo
Summary: Debug information for package bolt-macro-proof
Group: Development/Debug
AutoReq: 0
AutoProv: 1
%description debuginfo
This package provides debug information for package bolt-macro-proof.
Debug information is useful when developing applications that use this
package or when debugging this package.
%files debuginfo -f debugfiles.list


%package debugsource
Summary: Debug sources for package bolt-macro-proof
Group: Development/Debug
AutoReqProv: 0
%description debugsource
This package provides debug sources for package bolt-macro-proof.
Debug sources are useful when developing applications that use this
package or when debugging this package.
%files debugsource -f debugsourcefiles.list
%defattr(-,root,root)
%manifest bolt-macro-proof-debugsource.manifest 


%prep
%build
export AR=llvm-ar RANLIB=llvm-ranlib;
export CC=x86_64-tizen-linux-gnu-clang CXX=x86_64-tizen-linux-gnu-clang++;
export MAKEFLAGS+=" -k";


%install
export AR=llvm-ar RANLIB=llvm-ranlib;
export CC=x86_64-tizen-linux-gnu-clang CXX=x86_64-tizen-linux-gnu-clang++;

mkdir -p /home/abuild/bolt-work/bolt-v4-20261015-reviewfinish/macro-parse/BUILDROOTS/bolt-macro-proof-1-1.x86_64/usr/bin
%files
/usr/bin/clang-22
