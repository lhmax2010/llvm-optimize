
Name: bolt-macro-proof
Version: 1
Release: 1
Summary: Literal production post macro fragment proof
License: Apache-2.0
Source1201: clang-bolt-helper.py


%description
Configuration evidence only; no claim of a new rpmbuild execution.
%prep
%build
export AR=%{__ar_%{_toolchain}} RANLIB=%{__ranlib_%{_toolchain}};
export CC=%{__cc_%{_toolchain}} CXX=%{__cxx_%{_toolchain}};
export MAKEFLAGS+=" -k";


%install
export AR=%{__ar_%{_toolchain}} RANLIB=%{__ranlib_%{_toolchain}};
export CC=%{__cc_%{_toolchain}} CXX=%{__cxx_%{_toolchain}};

mkdir -p /home/abuild/bolt-work/bolt-v4-20261015-reviewfinish/macro-parse/BUILDROOTS/bolt-macro-proof-1-1.x86_64/usr/bin
%files
/usr/bin/clang-22
