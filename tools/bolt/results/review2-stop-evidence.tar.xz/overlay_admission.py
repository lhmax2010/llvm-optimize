from pathlib import Path
import os,fcntl,subprocess,time,json,shutil
E=Path(__file__).resolve().parent;D=E/'overlay-admission';D.mkdir()
for n in ('lower-probe','upper-probe','work-probe','scratch.overlay-probe'):(D/n).mkdir()
lock=Path('/home/linhao/Toolchain/development/heavy-stage.lock');start=time.monotonic();acquired=None;mounted=False
cmd=['sudo','-n','/bin/mount','-t','overlay','overlay','-o','lowerdir='+str(D/'lower-probe')+',upperdir='+str(D/'upper-probe')+',workdir='+str(D/'work-probe'),str(D/'scratch.overlay-probe')]
(D/'command.json').write_text(json.dumps(cmd,indent=2))
with lock.open('r+') as f:
 while True:
  try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);acquired=time.monotonic();break
  except BlockingIOError:
   if time.monotonic()-start>7200:raise RuntimeError('shared lock wait exceeded two hours')
   time.sleep(1)
 try:
  (D/'before.mountinfo').write_text(Path('/proc/self/mountinfo').read_text())
  (D/'lock.json').write_text(json.dumps({'pid':os.getpid(),'acquired':time.time(),'wait_s':acquired-start}))
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=15)
  (D/'mount.stdout').write_text(p.stdout);(D/'mount.stderr').write_text(p.stderr)
  mounted=p.returncode==0
  (D/'during.mountinfo').write_text(Path('/proc/self/mountinfo').read_text())
  result={'status':'OVERLAY_AVAILABLE' if mounted else 'NOT_RUN_OVERLAY_PERMISSION','rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'permission_probe_only':True,'real_tree_entered':False,'real_tree_mounted':False,'lower_tree_inventory':'NOT RUN: permission probe used only empty own directories','suggested_lower_from_docs35':'/home/linhao/Toolchain/development/llvm-optimize/temp/gbs-root-x86_64-archivefix-v2/local/BUILD-ROOTS/scratch.x86_64.0','no_copy_fallback':True,'disk_free_bytes':shutil.disk_usage(E).free}
 finally:
  if mounted:
   u=subprocess.run(['sudo','-n','/bin/umount',str(D/'scratch.overlay-probe')],capture_output=True,text=True,timeout=15)
   (D/'umount.json').write_text(json.dumps({'rc':u.returncode,'stdout':u.stdout,'stderr':u.stderr}));assert u.returncode==0,'overlay probe unmount failed'
  after=Path('/proc/self/mountinfo').read_text();(D/'after.mountinfo').write_text(after)
  assert ' '+str(D/'scratch.overlay-probe')+' ' not in after,'overlay probe remains'
  (D/'lock-release.json').write_text(json.dumps({'released':time.time(),'hold_s':time.monotonic()-acquired}));fcntl.flock(f,fcntl.LOCK_UN)
 result['lock_released']=True;result['wall_s']=time.monotonic()-start
 (E/'overlay-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
