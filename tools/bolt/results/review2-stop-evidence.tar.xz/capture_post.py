from pathlib import Path
import json,sys,subprocess,shutil,re,hashlib
from new_session import E,R1,INNER,HOST,root_command
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
macros='/usr/lib/rpm/macros:/usr/lib/rpm/macros.d/macros.*:/usr/lib/rpm/platform/%{_target}/macros:/usr/lib/rpm/fileattrs/*.attr:/usr/lib/rpm/tizen/macros:/etc/rpm/macros.*:/etc/rpm/macros:/etc/rpm/%{_target}/macros:/home/abuild/.rpmmacros'
top=INNER+'/post-capture-final';base=HOST/'post-capture-final';base.mkdir()
for d in ['BUILD','BUILDROOTS','RPMS','SRPMS','SPECS','tmp']:(base/d).mkdir()
wrapper=HOST/'capture-install-shell.sh'
wrapper.write_text('#!/bin/sh\nset -eu\nprintf "%s\\n" "$@" > '+h.quote(top+'/shell.argv')+'\nfor script do :; done\ncp "$script" '+h.quote(top+'/captured-script.sh')+'\nexit 0\n');wrapper.chmod(0o755)
result={'status':'RUNNING','method':'rpmbuild -bi --short-circuit with __spec_install_cmd capture wrapper; wrapper copies final generated script and never executes it','install_or_post_executed':False,'modes':{}}
scripts={}
for mode in ['debug','release']:
 for tag,spec in [('baseline','llvm-baseline.spec'),('on','llvm-draft.spec')]:
  label='post-script-'+mode+'-'+tag
  capture=base/'captured-script.sh'
  if capture.exists():capture.unlink()
  argv=['/usr/bin/rpmbuild','--macros='+macros,'-bi','--short-circuit','--nodeps','--nosignature','--target=x86_64','--define','_topdir '+top,'--define','_sourcedir '+INNER,'--define','_builddir '+top+'/BUILD','--define','_buildrootdir '+top+'/BUILDROOTS','--define','_tmppath '+top+'/tmp','--buildroot',top+'/BUILDROOT','--define','__spec_install_cmd '+INNER+'/capture-install-shell.sh %{___build_args}','--define','_build_create_debug 1','--define','_srcdefattr (-,root,root)']
  argv+=['--define','_toolchain clang'] if mode=='debug' else ['--undefine','_toolchain']
  argv+=[INNER+'/'+spec]
  command='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; exec python3 '+h.quote(INNER+'/record_call.py')+' '+h.quote(label)+' '+' '.join(h.quote(x) for x in argv)
  p=root_command(['/bin/sh','-c',command],True,capture_output=True,text=True,timeout=120)
  (E/(label+'.stdout')).write_text(p.stdout);(E/(label+'.stderr')).write_text(p.stderr)
  h.require(p.returncode==0,'script capture command failed '+label+': '+p.stderr)
  h.require(capture.is_file(),'capture wrapper did not save generated install script '+label)
  text=capture.read_text();scripts[mode,tag]=text;(E/(label+'.sh')).write_text(text)
  shutil.copyfile(base/'shell.argv',E/(label+'.shell.argv'))
  result.setdefault('calls',[]).append(json.loads((HOST/'calls'/(label+'.json')).read_text()))
 # The last production install command is followed by exactly the platform post chain.
 marker='echo "plugin load /usr/share/dotnet.tizen/netcoreapp/SOS/libsosplugin.so" > /root/.lldbinit'
 def chain(text):
  h.require(text.count(marker)==1,'cannot uniquely locate end of install body')
  return text.split(marker,1)[1]
 baseline=chain(scripts[mode,'baseline']);after=chain(scripts[mode,'on'])
 original=baseline
 h.require(after.startswith(original),'platform post commands differ from cb baseline: '+mode)
 extra=after[len(original):]
 h.require(extra.count(' post ')==1 and extra.count('BOLT_POST_GATE_PASS')==1,'BOLT tail duplicated or absent')
 h.require(re.fullmatch(r'\s*python3 [^\n]+ \|\| exit 1\s*\n\s*echo BOLT_POST_GATE_PASS\s*',extra) is not None,'unexpected commands after platform post or BOLT tail')
 (E/('post-chain-'+mode+'-baseline.sh')).write_text(original)
 (E/('post-chain-'+mode+'-on.sh')).write_text(after)
 (E/('post-chain-'+mode+'-added.sh')).write_text(extra)
 result['modes'][mode]={'platform_post_byte_equal':True,'platform_post_bytes':len(original.encode()),'platform_post_sha256':hashlib.sha256(original.encode()).hexdigest(),'BOLT_tail_is_last':True,'tail':extra,'shell_argv':(E/('post-script-'+mode+'-on.shell.argv')).read_text(),'actual_execution_in_step6':'NOT RUN: overlay permission unavailable'}
result['status']='PASS_CAPTURED_SCRIPTS';h.save(E/'post-scripts-result.json',result);print(json.dumps(result,indent=2),flush=True)
