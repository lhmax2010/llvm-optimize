#!/bin/sh


  RPM_SOURCE_DIR="/home/abuild/bolt-work/bolt-v4-20261015-review2"
  RPM_BUILD_DIR="/home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILD"
  RPM_OPT_FLAGS="-O2 -g -m64 -fmessage-length=0 -Wp,-D_FORTIFY_SOURCE=2 -fstack-protector -funwind-tables -fasynchronous-unwind-tables"
  RPM_ARCH="x86_64"
  RPM_OS="linux"
  export RPM_SOURCE_DIR RPM_BUILD_DIR RPM_OPT_FLAGS RPM_ARCH RPM_OS
  RPM_DOC_DIR="/usr/share/doc/packages"
  export RPM_DOC_DIR
  RPM_PACKAGE_NAME="llvm"
  RPM_PACKAGE_VERSION="22.1.8"
  RPM_PACKAGE_RELEASE="1"
  export RPM_PACKAGE_NAME RPM_PACKAGE_VERSION RPM_PACKAGE_RELEASE
  LANG=C
  export LANG
  unset CDPATH DISPLAY ||:
  RPM_BUILD_ROOT="/home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT"
  export RPM_BUILD_ROOT
  
  PKG_CONFIG_PATH="${PKG_CONFIG_PATH}:/usr/lib64/pkgconfig:/usr/share/pkgconfig"
  export PKG_CONFIG_PATH
  
  set -x
  umask 022
  cd "/home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILD"

/bin/rm -rf "$RPM_BUILD_ROOT"
/bin/mkdir -p "$RPM_BUILD_ROOT"

cd 'llvm-22.1.8'
export AR=llvm-ar RANLIB=llvm-ranlib;
export CC=x86_64-tizen-linux-gnu-clang CXX=x86_64-tizen-linux-gnu-clang++;

cd build
cmake -DCMAKE_INSTALL_PREFIX=/home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr -P cmake_install.cmake
ln -sf /usr/bin/clang++ /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/clang++-22

ln -sf clang /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/x86_64-tizen-linux-gnu-clang
ln -sf clang++ /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/x86_64-tizen-linux-gnu-clang++
# Use host triple and resource dir by default via <lang>.cfg
cat >> /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT//usr/bin/clang.cfg << EOF
-target x86_64-tizen-linux-gnu
-resource-dir /usr/lib64/clang/22
EOF
ln -sf clang.cfg /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT//usr/bin/clang++.cfg

# copy lldb for sdk
mkdir -p /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/home/owner/share/tmp/sdk_tools/lldb/bin
mkdir -p /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/home/owner/share/tmp/sdk_tools/lldb/lib64

mv /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/lldb /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/home/owner/share/tmp/sdk_tools/lldb/bin
mv /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/lldb-argdumper /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/home/owner/share/tmp/sdk_tools/lldb/bin
mv /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/lldb-server /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/home/owner/share/tmp/sdk_tools/lldb/bin

ln -sf /home/owner/share/tmp/sdk_tools/lldb/bin/lldb /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/bin/

cp -P /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/lib64/liblldb.so* /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/home/owner/share/tmp/sdk_tools/lldb/lib64/

# Install the clang python bits
mkdir -p /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/lib/python3.14/site-packages
cp -a ../clang/bindings/python/clang /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/lib/python3.14/site-packages/

rm -rf /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/lib64/debug/*
rm -rf /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/lib/libear/*
rm -rf /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT/usr/lib/libscanbuild/*


    
    /usr/lib/rpm/find-debuginfo.sh \
    -j40 \
     \
     \
     \
     \
    --build-id-seed "22.1.8-1" \
     \
    --unique-debug-src-base "llvm-22.1.8-1.x86_64" \
     \
     \
     \
     \
    -S debugsourcefiles.list \
    "/home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILD/llvm-22.1.8"\
    
   cp /usr/lib/rpm/debug.manifest /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILD/llvm-22.1.8/llvm-debuginfo.manifest 
   cp /usr/lib/rpm/debug.manifest /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILD/llvm-22.1.8/llvm-debugsource.manifest 
 

    /usr/lib/rpm/check-buildroot
    
    /usr/lib/rpm//brp-compress 
    
     
    /usr/lib/rpm/brp-strip-static-archive /bin/strip 
#    /usr/lib/rpm/brp-strip-comment-note /bin/strip /bin/objdump 

    /usr/lib/rpm/brp-python-hardlink 
    /usr/lib/rpm/tizen/find-docs.sh /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT 

    
    /usr/lib/rpm/tizen/find-isufiles.sh /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILD/llvm-22.1.8/isu.list 

    
    /etc/hal/rootstrap/hal-rootstrap-checker.sh /home/abuild/bolt-work/bolt-v4-20261015-review2 /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT x86_64 

    
    /etc/app-rootstrap/app-rootstrap-checker.sh /home/abuild/bolt-work/bolt-v4-20261015-review2 /home/abuild/bolt-work/bolt-v4-20261015-review2/post-capture-final/BUILDROOT x86_64 

