from pathlib import Path
import sys,json,os,shutil,subprocess
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');S=E.parent/'bolt-v4-20261013/v41/llvm-source';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
R=Path('/var/tmp/llvm-optimize-x86-archivefix-20261013/local/BUILD-ROOTS/scratch.x86_64.0');build=R/'home/abuild/rpmbuild/BUILD/llvm-22.1.8/build';old=E.parent/'bolt-v4-20261014-wednesday';identity=json.loads((old/'handoff-identity.json').read_text());checked=[]
for row in identity['checked_files']+identity['checked_rpms']:
 p=Path(row['path'])
 if p.name in ['CMakeCache.txt','build.ninja','.ninja_log']:continue
 h.require(h.digest(p)==row['sha256'] and p.stat().st_size==row['bytes'],'protected file changed '+str(p));checked.append(str(p))
protected=R/'home/abuild/review49-independent-install';rows=[]
for p in sorted(protected.rglob('*')):
 st=p.lstat();rows.append([p.relative_to(protected).as_posix(),st.st_mode,st.st_size,st.st_mtime_ns])
h.require(rows==json.loads((old/'protected-archive-metadata.json').read_text()),'archive evidence changed')
for n,sha in {'CMakeCache.txt':'17f7fbc72b14f6b1a5116aa17622e0af244fe84f2e72ef1e32bba61d3ca32876','build.ninja':'c0068a3e42ae3b4303357000ddb6f30a0f72d46da704128277a052953ead4d42'}.items():h.require(h.digest(build/n)==sha,'original disabled config changed '+n)
files=[p for p in (build/'lto.cache').rglob('*') if p.is_file()];cache={'files':len(files),'bytes':sum(p.stat().st_size for p in files)};h.require(cache=={'files':47987,'bytes':96881772832},'original cache size/count changed')
candidate=R/'home/abuild/bolt-work/bolt-v4-20261014-fallback/clang.candidate';h.require(h.digest(candidate)=='4ec07159aeb4f9300361b95955db05bfca06ece5b748796b28e9b8965145fff9','candidate changed')
h.require(not any(' '+str(R)+'/proc ' in line for line in Path('/proc/self/mountinfo').read_text().splitlines()),'proc mounted unexpectedly')
source=R/'home/abuild/rpmbuild/BUILD/llvm-22.1.8';rows=[]
for folder,dirs,files in os.walk(source,followlinks=False):
 if Path(folder)==source:dirs[:]=[d for d in dirs if d!='build']
 for n in sorted(dirs+files):
  p=Path(folder)/n;st=p.lstat();rows.append([p.relative_to(source).as_posix(),st.st_mode,st.st_size,st.st_mtime_ns])
h.require(rows==json.loads((E.parent/'bolt-v4-20261014-fallback/source-before.json').read_text()),'original source modified')

value={'status':'PASS','protected_files':checked,'RPMs_preserved':22,'archive_evidence_metadata_equal':True,'original_source_metadata_equal':True,'original_cache':cache,'candidate_sha256':h.digest(candidate),'root_free_bytes':shutil.disk_usage(build).free,'E_free_bytes':shutil.disk_usage(E).free}
h.save(E/'protection-audit.json',value);print(json.dumps(value,indent=2),flush=True)
