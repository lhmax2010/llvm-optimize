import sys,os,time,json,resource,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
d=Path(sys.argv[1]); script=Path(sys.argv[2])
(d/'child-env.json').write_text(json.dumps({'pid':os.getpid(),'nice':os.getpriority(os.PRIO_PROCESS,0),'ionice':subprocess.check_output(['ionice','-p',str(os.getpid())],text=True),'cgroup':Path('/proc/self/cgroup').read_text()},indent=2))
rc=subprocess.run([sys.executable,str(script)],cwd=d.parent).returncode
(d/'child-result.json').write_text(json.dumps({'rc':rc}))
while not (d/'release').exists():time.sleep(.1)
sys.exit(rc)
