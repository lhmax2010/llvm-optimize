from pathlib import Path
import sys,json,lzma,subprocess,shutil,hashlib,tarfile,io
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');S=E.parent/'bolt-v4-20261013/v41/llvm-source';R=B/'tools/bolt/results';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
stop=json.loads((E/'stop-result.json').read_text());source=stop['source_commit'];parent=stop['parent']
patch=subprocess.check_output(['git','format-patch','-1','--stdout','--binary'],cwd=S)
xz=lzma.compress(patch,preset=6);(E/'0000-clang-bolt-squashed-binary.patch.xz').write_bytes(xz)
# Public size cap: retain the complete binary patch locally; publish the full text diff and existing binary Source separately.
text_patch=subprocess.check_output(['git','format-patch','-1','--stdout'],cwd=S)
(B/'patches/bolt/0000-clang-bolt-squashed.patch').write_bytes(text_patch)
for p in E.glob('post-*.sh'):shutil.copyfile(p,R/('review4-'+p.name))
for name in ['post-capture-result.json','macro-result.json','stop-result.json','rebase-precommit.json']:
 shutil.copyfile(E/name,R/('review4-'+name))
for src,dest in [('packaging/llvm.spec','review4-rebased.spec'),('packaging/clang-bolt-helper.py','review4-rebased-helper.py')]:shutil.copyfile(S/src,R/dest)
result={'status':'STOP','source_commit':source,'parent':parent,'0004':'91f2ab3618900bb828a228c274d19004681e6d4d','source_files':[{ 'path':n,'bytes':(S/n).stat().st_size,'sha256':h.digest(S/n)} for n in ['packaging/llvm.spec','packaging/clang-bolt-helper.py','packaging/clang-bolt-v2.fdata.xz']],'helper_mirror_equal':(S/'packaging/clang-bolt-helper.py').read_bytes()==(B/'tools/bolt/bolt_helper.py').read_bytes(),'candidate_regenerated':False,'sandbox_pushed':False,'gerrit_review_pushed':False,'0004_patch_sha256':h.digest(B/'patches/bolt/0004-clang-bolt-third-review.patch'),'full_binary_format_patch_uncompressed_sha256':hashlib.sha256(patch).hexdigest(),'full_binary_format_patch_uncompressed_bytes':len(patch),'full_binary_format_patch_xz_bytes':len(xz)}
h.save(R/'review4-source-result.json',result)
# Preserve complete session code, calls, outputs and failure text, excluding all product payloads.
with tarfile.open(R/'review4-execution.tar.xz','w:xz') as t:
 for p in sorted(E.rglob('*')):
  if p.is_file() and not p.is_symlink() and p.stat().st_size<10_000_000 and p.suffix not in ('.pyc',) and '__pycache__' not in p.parts:
   t.add(p,arcname=p.relative_to(E).as_posix(),recursive=False)
m=json.loads((B/'patches/bolt/draft-manifest.json').read_text());m.update(draft_commit=source,base=parent,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=S,text=True).strip(),qualification='STOP_NEW_BASELINE_RPM_IDENTITY_MISMATCH; SQUASHED_SOURCE_NOT_FULLY_RECERTIFIED',sandbox_pushed=False,gerrit_review_pushed=False,sandbox_branch='sandbox/lhmax2025/bolt_pgo_v2',squashed_commit=source,squashed_parent=parent,files=result['source_files'],patch={'file':'0000-clang-bolt-squashed.patch','sha256':h.digest(B/'patches/bolt/0000-clang-bolt-squashed.patch'),'complete_binary_format_patch':False, 'binary_source_separate':'clang-bolt-v2.fdata.xz', 'full_binary_patch_local_only':'oversized public artifact; see source result bytes/SHA'},fixtures=252,final_squashed_tests='NOT RUN; stopped at RPM identity gate',post_capture='PASS new baseline debug/release; original platform bytes unchanged; BOLT tail last',disabled_macro_proof_reused=False,disabled_macro_proof='review4-macro-result.json',payload_check='FAIL before extraction: docs35 historical SHA mismatch')
for key in ['amended_from','spec_unchanged_from_d08','remote_before','remote_after','material_pin']:m.pop(key,None)
(B/'patches/bolt/draft-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
p=B/'docs/bolt/23_closure_post_certification.md';s=p.read_text();needle='111描述为102对象';s=s.replace(needle,'上述结论只覆盖保存的静态 Ninja 图；未加载 .ninja_deps/depfile，未做完整 dirty 判定。未知真实任务继续失败关闭，不能将离线闭包称为完整 Ninja 实际执行认证。\n\n'+needle,1);p.write_text(s)
report='''# 24 续跑十四：第三轮修复、变基与停止记录

STOP；压缩源提交 `%s`，父 `%s`；新分支 sandbox/lhmax2025/bolt_pgo_v2 未推。未启动 QB 或真实树演练。

## 人工裁决与执行边界

采用 PM 第三轮十二项修复、最新 tizen_base 单提交与重新认证要求。保持 profile/生成参数和候选4ec不变，不重生成。原树禁 cmake/ninja/-P，保护归档证据、22普通RPM和ARM树；作者/提交者/Signed-off-by均Hao Lin <hao.lin@samsung.com>，git -c、不改全局。全部门禁通过才允许推新sandbox；本轮有身份门禁失败，立即停止后续产品操作。

## 逐项状态

|项目|结果|
|---|---|
|helper/spec修复、0004|已实现，修复提交91f2ab3618900bb828a228c274d19004681e6d4d；完整patch公开|
|原214测试+38新增|252/252 PASS；stdout为空、stderr全部逐项原文|
|最后两项日志诊断微调及压缩提交后的全量重测|NOT RUN，停在载荷身份；不得把上述252项冒充最终压缩版本认证|
|新增安装顺序测试方法|已加入，读取实际展开快照；最终测试运行NOT RUN|
|真实link.original更严格检查|PASS，未执行链接|
|普通7df/候选4ec新增安全字段|PASS；RPATH均无，RUNPATH均为$ORIGIN/../lib64:|
|严格CLI离线闭包|PASS：1911边、1791普通、9新phony、111新任务，分类变化0；确切argv、输入SHA和rules子集已发布|
|最新tizen_base|PASS，与预期67619ec8一致；无额外提交，356949未合入|
|压缩单提交及身份|PASS，父为新基线；helper/profile与0004逐字节相同；spec只加基线Source1005/util-linux/转换原文|
|OFF两模式展开|PASS，与新基线debug 20段、release 18段逐字节相同|
|ON两模式安装顺序|PASS：snapshot < compare-root < 转换 < 替换；ON/OFF转换均一次|
|四份新基线post捕获|PASS，平台链逐字节同基线、BOLT尾检最后；debug有FD、release有brp-strip|
|22RPM完整载荷|FAIL，首个RPM与docs35历史记录身份不符，未解包|
|压缩提交上再次全量测试、tiny/双根post|NOT RUN，身份门禁失败后停止；不得沿用旧基线认证冒充本轮|
|maintenance.md完整维护手册|NOT RUN，停止后不继续实现后续步骤|
|新sandbox推送/QB/真实树演练|NOT RUN；新sandbox未查询/未推，不触碰旧分支|

## 阻断原文及身份

`GateError: docs35 RPM SHA changed: %s`

|字段|docs35历史记录|当前只读观测|
|---|---|---|
|字节|%d|%d|
|SHA256|%s|%s|

这只证明当前路径的RPM不是docs35登记的同一文件，不推断文件损坏或变化原因。未自行信任新SHA、改载荷、改用其他包或重试门禁。1199098关联Base快照索引仅有12个非debug LLVM包，缺所需10个debug包，故选择PM已授权的docs35完整22包回退；也不把该回退集说成67619ec8新构建物。

共享锁持有44.195秒后释放，失败scope退出并回收；未开始解包、无大文件写入。两个post/宏采集proc挂载均finally卸载，前/中/后mountinfo见execution包。未在原树运行cmake/ninja/-P、未改原RPM或归档证据。

## 准备性错误与测试断言

1. 查AGENTS搜索范围一次过大，遇到其他目录权限拒绝；随后改逐级明确路径，未修改该处文件。
2. 首轮夹具旧语义未同步，作为一类准备错误修正一次：10GiB写入正例改为11GiB free；warning负例改error；另按新约定同步两处英文重生成断言与真实构建标记。首轮260含导入类的重复计数，纠正导入后252个不同测试方法通过；原214方法保留，新增38。
3. 新展开解析器用\\s把换行纳入段名，触发KeyError，没有产品差异判定；一次改为水平空白后，两模式OFF及安装顺序全PASS。保留初次stdout/stderr。
4. 发布预检发现包含profile二进制的完整format-patch压缩后仍超10MB公开上限；一次修正为公开文本补丁+已有Source，完整二进制补丁只在E保留。该限制未变更产品门禁。
5. 新安装顺序测试与最后日志诊断修改已保存，尚未作最终全量重跑；停止后不补跑。

## 材料与后续边界

0004保留相对ad8完整format-patch；0000是压缩单提交的完整文本format-patch，profile二进制Source另附既有clang-bolt-v2.fdata.xz。包含二进制的完整format-patch仅留本地：xz后仍超过10,000,000字节公开上限，未上传，身份/大小见source-result；不能把公开文本补丁说成自包含二进制补丁。公开原始helper/spec、两模式六份展开、四post脚本及逐字比较、真实链接/安全结果、完整测试原文、闭包输入SHA与rules子集、失败原文/资源记录。原始脚本与format-patch空白均保留，不纳入人工空白修整。

下一轮需要PM指定可信且可取得的完整普通RPM身份或明确新的处置；本轮不替用户重新授权。压缩提交尚未认证完成，不能启动QB。代码评审材料先提交GitHub bolt-v4；后续启动仍由用户决定。
'''%(source,parent,stop['RPM_path'],stop['expected_bytes'],stop['actual_bytes'],stop['expected_sha256'],stop['actual_sha256'])
(B/'docs/bolt/24_rebase_recertification.md').write_text(report)
p=B/'docs/bolt/STATUS.md';s=p.read_text();marker='## 2026-10-15 续跑十三A：PASS，sandbox已推；QB未启动';start=s.index(marker);s=s[:start]+'''## 2026-10-15 续跑十三A（历史完成）

ad8a2606父b7，214夹具、闭包111、完整22RPM/四post/真实门禁PASS，sandbox已推、QB未启动。完整裁决、资源、纠正与raw见[23](23_closure_post_certification.md)及43c6a3720606bb1f8ed79b666be726c929ba1f2b版STATUS，历史证据未删。

## 2026-10-15 续跑十四：STOP，RPM身份不符，新sandbox未推

PM裁决：采用十二项修复；保持4ec候选/profile/生成参数，变基最新tizen_base并压单提交；全部重新认证PASS才推新sandbox/lhmax2025/bolt_pgo_v2；QB和真实树演练由用户在PM审后启动。Hao Lin署名，保护/资源/原树禁用规则不变。

0004源91f2ab3618900bb828a228c274d19004681e6d4d；压缩源%s，父67619ec8bbbac7238a6cfc33a481ccfbcd12206f（与预期一致，356949未合入）。252夹具PASS、严格离线闭包1911/1791/9/111且分类变化0、真实link检查与新增安全字段PASS；新基线两模式OFF debug20/release18段逐字相同、ON转换顺序PASS、四post平台段逐字相同且尾检最后。

新载荷选授权docs35回退（1199098索引缺10个debug包），首个clang RPM SHA与docs35记录不符，立即STOP，尚未解包，未换SHA/包或重试。预期%s，实际%s；字节%d→%d。不推断变化原因。锁44.195秒释放、scope回收、proc卸载。

最终压缩提交全量重测/新安装顺序测试运行/真实tiny和双根post/完整载荷/maintenance/新sandbox均NOT RUN；不得把此前252结果冒充最终压缩版本认证。源helper/profile保持0004字节，新候选未生成。完整逐项状态、准备性纠正、原文与身份见[24](24_rebase_recertification.md)。
'''%(source,stop['expected_sha256'],stop['actual_sha256'],stop['expected_bytes'],stop['actual_bytes']);p.write_text(s)
# Every public document stays below the inherited 50,000-byte ceiling.
for p in (B/'docs/bolt/STATUS.md',B/'docs/bolt/24_rebase_recertification.md',B/'docs/bolt/23_closure_post_certification.md'):h.require(p.stat().st_size<=50000,'document too large: '+str(p))
print(json.dumps({'published_preparation':'PASS','source':source,'STOP':stop['actual_sha256'],'patch_xz_bytes':len(xz),'STATUS_bytes':(B/'docs/bolt/STATUS.md').stat().st_size},indent=2))
