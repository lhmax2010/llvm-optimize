from pathlib import Path
import subprocess,json,os,sys,time,fcntl
from run_scope import run,available,GIB
E=Path(__file__).resolve().parent
R1=Path('/var/tmp/llvm-optimize-x86-archivefix-20261013/local/BUILD-ROOTS/scratch.x86_64.0')
INNER='/home/abuild/bolt-work/bolt-v4-20261015-review4';HOST=R1/INNER.lstrip('/')
BUILD='/home/abuild/rpmbuild/BUILD/llvm-22.1.8/build'
LOCK=Path('/home/linhao/Toolchain/development/heavy-stage.lock')
def root_command(argv,user=False,**kw):
 command=['sudo','-n','/usr/sbin/chroot']+(['--userspec=1000:1000'] if user else [])+[str(R1)]+(['/usr/bin/env','TMPDIR='+INNER+'/tmp'] if user else [])+list(map(str,argv))
 return subprocess.run(command,**kw)
def snapshot(d,label):
 text=Path('/proc/self/mountinfo').read_text();(d/(label+'.mountinfo')).write_text(text)
 return [l for l in text.splitlines() if ' '+str(R1)+'/proc ' in l]
def session(name,script,cap=16,locked=True):
 d=E/(name+'-session');d.mkdir(exist_ok=False);f=None;mounted=False;acquired=None;deadline=time.monotonic()+3600
 try:
  while available()<(12 if cap==16 else 6)*GIB:
   with (d/'memory-wait.jsonl').open('a') as out:out.write(json.dumps({'time':time.time(),'available':available()})+'\n')
   print('WAIT_MEMORY',name,available(),flush=True)
   if time.monotonic()+300>deadline:raise RuntimeError('STOP_MEMORY_WAIT_60_MIN')
   for _ in range(5):time.sleep(60)
  if locked:
   f=LOCK.open('r+');start=time.monotonic()
   while True:
    try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);acquired=time.monotonic();break
    except BlockingIOError:
     if time.monotonic()-start>=7200:raise RuntimeError('STOP_LOCK_TIMEOUT_2_HOURS')
     time.sleep(1)
   (d/'lock.json').write_text(json.dumps({'pid':os.getpid(),'acquired':time.time(),'wait_s':time.monotonic()-start}))
  if available()<(12 if cap==16 else 6)*GIB:
   if f:fcntl.flock(f,fcntl.LOCK_UN);f.close();f=None
   while available()<(12 if cap==16 else 6)*GIB:
    if time.monotonic()+300>deadline:raise RuntimeError('STOP_MEMORY_WAIT_60_MIN')
    print('WAIT_MEMORY_AFTER_LOCK',name,available(),flush=True)
    for _ in range(5):time.sleep(60)
   if locked:
    f=LOCK.open('r+');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);acquired=time.monotonic()
    (d/'lock.json').write_text(json.dumps({'pid':os.getpid(),'acquired':time.time(),'wait_s':time.monotonic()-start,'memory_readmission':True}))
  assert not snapshot(d,'before'),'x86 proc already mounted; cannot own another mount'
  p=root_command(['/bin/mount','-n','-tproc','none','/proc'],capture_output=True,text=True)
  (d/'mount.stdout').write_text(p.stdout);(d/'mount.stderr').write_text(p.stderr)
  if p.returncode:raise RuntimeError('STOP_PROC_MOUNT rc='+str(p.returncode))
  mounted=True;assert snapshot(d,'during'),'new proc mount not visible'
  result=run(name,script,cap);(d/'result.json').write_text(json.dumps(result,indent=2));return result
 finally:
  if mounted:
   p=root_command(['/bin/umount','/proc'],capture_output=True,text=True);(d/'umount.stdout').write_text(p.stdout);(d/'umount.stderr').write_text(p.stderr);assert p.returncode==0,'own proc unmount failed'
  assert not snapshot(d,'after'),'own proc mount remains'
  if f:
   held=time.monotonic()-acquired if acquired else 0;(d/'lock-release.json').write_text(json.dumps({'released':time.time(),'hold_s':held}));fcntl.flock(f,fcntl.LOCK_UN);f.close();assert held<=3600,'held shared lock over60min'
if __name__=='__main__':
 result=session(sys.argv[1],Path(sys.argv[2]),int(sys.argv[3]),sys.argv[4]=='locked');print(json.dumps(result),flush=True);sys.exit(0 if result['status']=='PASS' else 1)
