from pathlib import Path
import sys,json,subprocess
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
inventory=E.parent/'archive-fix-v2-final-20261009/continue-20261009/rpm-inventory.json';p=json.loads(inventory.read_text())[0];rpm=Path(p['path'])
q=subprocess.run(['rpm','-qp','--qf','NAME=%{NAME}\nVERSION=%{VERSION}\nRELEASE=%{RELEASE}\nBUILDTIME=%{BUILDTIME}\nBUILDHOST=%{BUILDHOST}\nSOURCERPM=%{SOURCERPM}\n',str(rpm)],capture_output=True,text=True)
S=E.parent/'bolt-v4-20261013/v41/llvm-source'
r={'status':'STOP_PRODUCT_IDENTITY_GATE','expected_source':'docs/35 authorized fallback, original inventory','inventory_path':str(inventory),'inventory_sha256':h.digest(inventory),'RPM_path':str(rpm),'expected_sha256':p['sha256'],'actual_sha256':h.digest(rpm),'expected_bytes':p['bytes'],'actual_bytes':rpm.stat().st_size,'header_query_rc':q.returncode,'header_raw':q.stdout,'header_stderr':q.stderr,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'parent':subprocess.check_output(['git','rev-parse','HEAD^'],cwd=S,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True),'extraction_started':False,'sandbox_pushed':False,'QB_started':False,'real_tree_rehearsal_started':False,'no_fallback_retry':True}
h.save(E/'stop-result.json',r);print(json.dumps(r,indent=2))
