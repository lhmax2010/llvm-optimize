from pathlib import Path
import shutil,subprocess,re,json,sys
E=Path(__file__).resolve().parent;old=E.parent/'bolt-v4-20261015-review3';S=E.parent/'bolt-v4-20261013/v41/llvm-source'
for name in ['new_session.py','metrics.py','locked_run.py']:
 s=(old/name).read_text().replace('bolt-v4-20261015-review3','bolt-v4-20261015-review4');(E/name).write_text(s)
from new_session import R1,HOST,INNER
HOST.mkdir(exist_ok=False);(HOST/'tmp').mkdir()
for name in ['rpm-env-prefix.sh','record_call.py']:
 shutil.copyfile(R1/'home/abuild/bolt-work/bolt-v4-20261015-review3'/name,HOST/name)
for path in (R1/'home/abuild/rpmbuild/SOURCES').iterdir():
 (HOST/path.name).symlink_to('/home/abuild/rpmbuild/SOURCES/'+path.name)
for name in ['llvm.spec','clang-bolt-helper.py','clang-bolt-v2.fdata.xz','llvm-static-archives-native.py']:
 dest=HOST/('llvm-draft.spec' if name=='llvm.spec' else name)
 if dest.is_symlink():dest.unlink()
 shutil.copyfile(S/'packaging'/name,dest)
(HOST/'llvm-baseline.spec').write_bytes(subprocess.check_output(['git','show','origin/tizen_base:packaging/llvm.spec'],cwd=S))
macros=(R1/'home/abuild/.rpmmacros').read_text();(HOST/'release.rpmmacros').write_text('\n'.join(l for l in macros.splitlines() if not re.match(r'^%_toolchain(?:\s|$)',l))+'\n')
p=HOST/'post-capture/BUILD/llvm-22.1.8';p.mkdir(parents=True);shutil.copyfile(S/'packaging/llvm.manifest',p/'llvm.manifest')
(E/'root-prepared.json').write_text(json.dumps({'root_work':str(HOST),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'baseline':subprocess.check_output(['git','rev-parse','origin/tizen_base'],cwd=S,text=True).strip()},indent=2))
# Build one correct capture implementation: both actual modes, no cached previous calls.
s=(old/'capture_release_corrected.py').read_text();s=s.replace("'debug_calls_reused':json.loads((E/'post-modes-first/post-capture-result.json').read_text())['calls'][:2],",'');s=s.replace("'preparation_corrections':['post-chain boundary locator corrected once','macro mode environment corrected once; source/platform/global files unchanged']","'preparation_corrections':[]")
s=s.replace("for mode in ['release']:","for mode in ['debug','release']:")
s=s.replace("argv+=['--define','_toolchain clang'] if mode=='debug'", "argv+=['--define','_toolchain clang','--define','_build_create_debug 1'] if mode=='debug'")
s=s.replace("macros.replace('/home/abuild/.rpmmacros',INNER+'/release.rpmmacros')", "(macros if mode=='debug' else macros.replace('/home/abuild/.rpmmacros',INNER+'/release.rpmmacros'))")
s=s.replace(" scripts.update({('debug',tag):(E/('post-debug-'+tag+'.sh')).read_text() for tag in ['baseline','candidate']})\n",'')
s=s.replace('cb679968','67619ec8');(E/'capture_post.py').write_text(s)
