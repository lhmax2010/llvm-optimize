from pathlib import Path
import json,sys,subprocess,stat,shutil
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
inventory=E.parent/'archive-fix-v2-final-20261009/continue-20261009/rpm-inventory.json';packages=json.loads(inventory.read_text());h.require(len(packages)==22,'fallback inventory is not 22 RPMs')
fmt='[%{FILENAMES}\t%{FILEMODES}\t%{FILEDIGESTS}\t%{FILELINKTOS}\t%{LONGFILESIZES}\n]';rows=[]
for p in packages:
 path=Path(p['path']);h.require(h.digest(path)==p['sha256'],'docs35 RPM SHA changed: '+str(path))
 q=subprocess.run(['rpm','-qp','--qf',fmt,str(path)],capture_output=True,text=True);h.require(q.returncode==0,'RPM query failed: '+q.stderr)
 files=[]
 for line in q.stdout.splitlines():
  name,mode,digest,target,size=line.split('\t');mode=int(mode)
  kind='file' if stat.S_ISREG(mode) else 'symlink' if stat.S_ISLNK(mode) else 'dir' if stat.S_ISDIR(mode) else 'special'
  h.require(kind!='special','special RPM path '+name);files.append({'path':name,'type':kind,'bytes':int(size)})
 rows.append({'name':p['name'],'RPM_path':str(path),'RPM_sha256':p['sha256'],'regular_payload_bytes':sum(f['bytes'] for f in files if f['type']=='file'),'files':files})
h.save(E/'payload-inputs.json',{'source':'docs/35 archive-fix v2 ordinary local 22 RPMs, explicitly authorized fallback','preferred_source':'QB1199098 associated Base 20261015.022255 x86_64 package index has the 12 non-debug LLVM packages, but none of the 10 debuginfo/debugsource RPMs needed for the complete 22-RPM root','new_baseline':'67619ec8bbbac7238a6cfc33a481ccfbcd12206f; 356949 not merged','source_inventory_sha256':h.digest(inventory),'packages':rows})
# Reuse the proven safe extraction path, with this newly verified fallback input set.
s=(E.parent/'bolt-v4-20261015-review3/full_payload.py').read_text()
s=s.replace("packages=json.loads((E.parent/'bolt-v4-20261015-validation/RPM-baseline.json').read_text())['packages'];assert len(packages)==22", "packages=json.loads((E/'payload-inputs.json').read_text())['packages'];assert len(packages)==22")
a=s.index("spec=importlib.util.spec_from_file_location");b=s.index("result={'status'",a);s=s[:a]+s[b:]
s=s.replace("'d08_helper_evidence_only':old_result,", "'source':'docs35 archive-fix-v2 fallback; not a newly built 67619ec8 RPM set',")
(E/'extract_payload.py').write_text(s)
exec(compile(s,str(E/'extract_payload.py'),'exec'))
