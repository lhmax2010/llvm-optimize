import os,sys,json,time,subprocess,signal
from pathlib import Path
E=Path(__file__).resolve().parent
GIB=1024**3

def available():
 return int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024

def run(name,script,cap=4):
 script=Path(script).resolve()
 d=E/(name+'-scope');d.mkdir(exist_ok=False)
 minimum=(12 if cap==16 else 6)*GIB
 a=available();(d/'admission.jsonl').write_text(json.dumps({'time':time.time(),'available':a,'minimum':minimum})+'\n')
 if a<minimum:
  result={'status':'SKIP_ADMISSION','rc':None};(d/'result.json').write_text(json.dumps(result));return result
 unit='bolt-v4-'+name+'-'+str(os.getpid())+'.scope'
 child=E/'scope_child.py'
 cmd=['systemd-run','--user','--scope','--unit='+unit,'-p','MemoryMax='+str(cap*GIB),'-p','MemorySwapMax=0','-p','OOMPolicy=stop','nice','-n',('15' if cap==16 else '19'),'ionice','-c','3',sys.executable,str(child),str(d),str(script)]
 (d/'command.json').write_text(json.dumps(cmd,indent=2))
 env=dict(os.environ,TMPDIR=str(E/'tmp'),PYTHONDONTWRITEBYTECODE='1');(E/'tmp').mkdir(exist_ok=True)
 start=time.monotonic();low=False
 with (d/'stdout').open('w') as out,(d/'stderr').open('w') as err:
  p=subprocess.Popen(cmd,cwd=E,env=env,stdout=out,stderr=err)
  cg=None
  try:
   while p.poll() is None:
    a=available()
    if cg is None:
     s=subprocess.run(['systemctl','--user','show',unit,'-p','ControlGroup','--value'],capture_output=True,text=True)
     if s.stdout.strip():cg=Path('/sys/fs/cgroup'+s.stdout.strip())
    row={'time':time.time(),'available':a}
    if cg and cg.exists():
     processes=[]
     try:
      for pid in (cg/'cgroup.procs').read_text().split():
       try:
        status=Path('/proc/'+pid+'/status').read_text();processes.append({'pid':int(pid),'name':status.splitlines()[0], 'nice':int(Path('/proc/'+pid+'/stat').read_text().split()[18]), 'VmHWM':next((x for x in status.splitlines() if x.startswith('VmHWM:')), None)})
       except OSError:pass
     except OSError:pass
     row['processes']=processes
    if cg and cg.exists():
     for field in ['memory.current','memory.peak','memory.events','memory.max','memory.swap.max','cgroup.procs']:
      try:row[field]=(cg/field).read_text()
      except OSError:pass
    with (d/'samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    if a<3*GIB:
     low=True;subprocess.run(['systemctl','--user','kill','--kill-whom=all','--signal=SIGKILL',unit],capture_output=True);break
    if (d/'child-result.json').exists():
     (d/'final-cgroup.json').write_text(json.dumps(row,indent=2));(d/'release').touch()
    if time.monotonic()-start>3500:
     subprocess.run(['systemctl','--user','kill','--kill-whom=all','--signal=SIGKILL',unit],capture_output=True);break
    time.sleep(0.5)
   rc=p.wait(timeout=20)
  finally:
   if p.poll() is None:subprocess.run(['systemctl','--user','kill','--kill-whom=all','--signal=SIGKILL',unit],capture_output=True);p.wait()
 unit_result=subprocess.run(['systemctl','--user','show',unit,'-p','Result','-p','ControlGroup','-p','ActiveState','-p','SubState'],capture_output=True,text=True).stdout
 if cg and cg.exists():
  last={}
  for field in ['memory.peak','memory.events','cgroup.procs']:
   try:last[field]=(cg/field).read_text()
   except OSError:pass
  (d/'exit-cgroup.json').write_text(json.dumps(last,indent=2))
  subprocess.run(['systemctl','--user','kill','--kill-whom=all','--signal=SIGKILL',unit],capture_output=True)
  for _ in range(40):
   if not cg.exists():break
   time.sleep(.25)
  if cg.exists():raise RuntimeError('own experiment cgroup not reaped; stop all later experiments')
 (d/'unit-exit.txt').write_text(unit_result)
 result={'status':'ABORT_LOW_MEMORY' if low else ('PASS' if rc==0 else 'FAIL'),'rc':rc,'wall':time.monotonic()-start,'unit':unit,'cgroup':str(cg)}
 result['unit_after']=subprocess.run(['systemctl','--user','show',unit,'-p','ActiveState','-p','SubState'],capture_output=True,text=True).stdout
 (d/'result.json').write_text(json.dumps(result,indent=2));print(name,json.dumps(result),flush=True);return result
if __name__=='__main__':
 result=run(sys.argv[1],Path(sys.argv[2]),int(sys.argv[3]) if len(sys.argv)>3 else 4)
 sys.exit(0 if result['status']=='PASS' else 1)
