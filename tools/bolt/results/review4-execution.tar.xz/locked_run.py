from pathlib import Path
import sys,time,fcntl,json
from run_scope import run,available,GIB
E=Path(__file__).resolve().parent
name,script=sys.argv[1:3];d=E/(name+'-lock');d.mkdir();acquired=None;start=time.monotonic()
with Path('/home/linhao/Toolchain/development/heavy-stage.lock').open('r+') as lock:
    deadline=time.monotonic()+3600
    while available()<12*GIB:
        print('WAIT_MEMORY',available(),flush=True)
        if time.monotonic()+300>deadline:raise RuntimeError('memory admission wait exceeded60min')
        for i in range(5):time.sleep(60)
    while True:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);acquired=time.monotonic();break
        except BlockingIOError:
            if time.monotonic()-start>7200:raise RuntimeError('shared lock wait exceeded2h')
            time.sleep(1)
    try:
        (d/'acquired.json').write_text(json.dumps({'time':time.time(),'wait_s':acquired-start}))
        print('LOCK_ACQUIRED',name,flush=True)
        if available()<12*GIB:raise RuntimeError('memory admission lost after lock; no product operation started')
        result=run(name,Path(script),16)
    finally:
        held=time.monotonic()-acquired;fcntl.flock(lock,fcntl.LOCK_UN)
        (d/'released.json').write_text(json.dumps({'time':time.time(),'held_s':held}));assert held<3600
    sys.exit(0 if result['status']=='PASS' else 1)
