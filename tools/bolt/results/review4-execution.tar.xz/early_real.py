import sys,json
from pathlib import Path
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
E=Path(__file__).resolve().parent
link=E.parent/'bolt-v4-20261014-relink-first/link.original'
result=h.replay_script(link.read_text(),'/home/abuild/bolt-work/review4/replay-output','/home/abuild/bolt-work/review4/replay-link.d')
h.save(E/'real-link-check.json',{'pass':True,'input':str(link),'sha256':h.digest(link),'script_sha256':__import__('hashlib').sha256(result.encode()).hexdigest(),'executed':False})
R=Path('/var/tmp/llvm-optimize-x86-archivefix-20261013/local/BUILD-ROOTS/scratch.x86_64.0')
a=R/'home/abuild/rpmbuild/BUILD/llvm-22.1.8/build/bin/clang-22';b=R/'home/abuild/bolt-work/bolt-v4-20261014-fallback/clang.candidate'
# Capture raw new fields even if the comparison fails.
x=h.security_properties(a);y=h.security_properties(b)
h.save(E/'new-security-fields.json',{str(p):{k:v[k] for k in ('DT_RPATH','DT_RUNPATH')} for p,v in ((a,x),(b,y))})
r=h.security_compare(a,b);h.save(E/'early-security.json',r)
print(json.dumps({'link':'PASS','security':r},ensure_ascii=False))
