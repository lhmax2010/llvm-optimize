from pathlib import Path
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt'); p=B/'tools/bolt/bolt_helper.py';s=p.read_text()
s=s.replace("PROFILE_SHA = 'd9b132f9430dfed32e080c65b4422bd76eba4a9c2101a2b18a7f66c94133b326'",'''CERTIFIED = {'llvm_version': '22.1.8', 'bolt_version': 'LLVM version 22.1.8',
             'profile_sha256': 'd9b132f9430dfed32e080c65b4422bd76eba4a9c2101a2b18a7f66c94133b326',
             'bolt_task_count': 111, 'tf_refresh_task_count': 2}
PROFILE_SHA = CERTIFIED['profile_sha256']
BUILD_SUCCESS = 'BOLT_NINJA_EXIT_0'
REGEN_ERROR = ('dry-run shows "Re-running CMake..."; build.ninja still needs regeneration '
               'after the BOLT configure, so the real plan is not visible')


def preflight():
    require(sys.version_info >= (3, 9), 'Python actual=%s expected=>=3.9' % (tuple(sys.version_info[:3]),))
    required = ('waitid', 'waitstatus_to_exitcode', 'P_PID', 'WEXITED', 'WNOHANG', 'WNOWAIT', 'CLD_EXITED')
    missing = [name for name in required if not hasattr(os, name)]
    require(not missing, 'Python os interfaces actual=missing %s expected=%s' % (missing, required))
    return {'preflight_pass': True, 'python': list(sys.version_info[:3]), 'os_interfaces': list(required)}


def certified():
    return {**CERTIFIED, 'whitelist_counts': {'bolt': len(BOLT_TASK_DESCRIPTIONS),
                                             'tf_refresh': len(TF_REFRESH_DESCRIPTIONS)}}


def profile_identity(path):
    actual = digest(path)
    require(actual == PROFILE_SHA, 'profile SHA actual=%s expected=%s; remedy: first verify the Source identity; '
            'do not assume the profile is stale' % (actual, PROFILE_SHA))
''')
s=s.replace("require(digest(output) == PROFILE_SHA, 'profile uncompressed SHA mismatch')","profile_identity(output)").replace("require(digest(profile) == PROFILE_SHA, 'profile SHA mismatch')","profile_identity(profile)")
s=s.replace("require(not any(arg.startswith('@') for arg in shlex.split(body)),", "args = shlex.split(body)\n    require(not any(arg.startswith('@') or (arg.startswith('-Wl,') and any(part.startswith('@') for part in arg[4:].split(','))) for arg in args),")
s=s.replace("'&&' not in body and ';' not in body and '`' not in body and '$(' not in body", "not any(c in body for c in ';`|&<>') and '$(' not in body")
s=s.replace("'profile R exceeds 5 percent'", "'profile R actual=%s expected=<=0.05; remedy: verify input identity, then retrain the profile or disable BOLT; never raise the threshold' % ((s+u)/(n+u))")
s=s.replace("'profile S/N exceeds 5 percent'", "'profile S/N actual=%s expected=<=0.05; remedy: verify input identity, then retrain the profile or disable BOLT; never raise the threshold' % (s/n)")
s=s.replace("require(shndx != 65535, 'XINDEX not supported')", "require(shndx < len(self.sections) or shndx in (0xfff1, 0xfff2), 'invalid symbol shndx: actual=%d expected=section index, SHN_ABS or SHN_COMMON' % shndx)")
s=s.replace("needed = []; flags = {}; bind_now = False", "needed = []; flags = {}; bind_now = False; search_paths = {}")
s=s.replace("                if tag == 24:", "                if tag in (15, 29):\n                    key = 'DT_RPATH' if tag == 15 else 'DT_RUNPATH'\n                    require(key not in search_paths, 'duplicate dynamic search path tag: '+key)\n                    search_paths[key] = e.string(strings[4], strings[5], value)\n                if tag == 24:")
s=s.replace("'DT_FLAGS_FLAGS1': flags,", "'DT_RPATH': search_paths.get('DT_RPATH'), 'DT_RUNPATH': search_paths.get('DT_RUNPATH'),\n                'DT_FLAGS_FLAGS1': flags,")
s=s.replace("require(lines == ['LLVM version 22.1.8'], 'uncertified BOLT tool version')", "require(lines == [CERTIFIED['bolt_version']], 'uncertified BOLT tool version actual=%s expected=%s; remedy: update certified constants and recertify, or disable with --without clang_bolt / bcond_with' % (lines, CERTIFIED['bolt_version']))")
s=s.replace("    counts = {'objects': 0,", "    diagnostics = [line for line in lines if line.startswith('ninja: warning:')]\n    lines = [line for line in lines if not line.startswith('ninja: warning:')]\n    require(not any('Re-running CMake...' in line for line in lines), REGEN_ERROR)\n    counts = {'objects': 0,",1)
s=s.replace("'configuration_refresh_tasks': 0, 'descriptions': []", "'configuration_refresh_tasks': 0, 'descriptions': [], 'ninja_diagnostics': diagnostics")
a=s.index('    if len(lines) == 1 and re.fullmatch',s.index('def tool_plan'));b=s.index('    descriptions = []',a);s=s[:a]+s[b:]
s=s.replace("'unapproved BOLT task: '+body", "'unapproved BOLT task: actual=%s expected=certified BOLT/TF tasks; remedy: inspect configuration and dirty causes, regenerate the certified whitelist and recertify if needed; never expand it automatically' % body")
s=s.replace("'configuration_refresh_tasks': len(tf), 'descriptions': descriptions}", "'configuration_refresh_tasks': len(tf), 'descriptions': descriptions, 'ninja_diagnostics': diagnostics}")
s=s.replace("    value = {'configuration_refresh_tasks': plan['configuration_refresh_tasks']}", "    executable = build/'bin/llvm-bolt'\n    exists = executable.exists()\n    value = {'configuration_refresh_tasks': plan['configuration_refresh_tasks'],\n             'executable_before': {'exists': exists, 'sha256': digest(executable) if exists and executable.is_file() else None}}")
s=s.replace("def tool_verify(build, plan, text, state):\n    descriptions", "def tool_verify(build, plan, text, state):\n    lines = text.splitlines()\n    require(bool(lines) and lines[-1] == BUILD_SUCCESS and lines.count(BUILD_SUCCESS) == 1,\n            'missing, duplicate or non-final '+BUILD_SUCCESS)\n    descriptions")
s=s.replace("    for line in text.splitlines():\n        match = re.fullmatch(r'\\[(\\d+)/(\\d+)\\] (.+)', line)", "    for line in lines[:-1]:\n        match = re.fullmatch(r'\\[(\\d+)/(\\d+)\\] (.+)', line)")
s=s.replace("        if match is None:\n            continue\n        f, t", "        if match is None:\n            require(not re.match(r'\\[\\d', line), 'malformed real build progress: '+line)\n            continue\n        f, t")
s=s.replace("    executable = Path(build)/'bin/llvm-bolt'", "    require(plan['plan_type'] != 'build' or bool(descriptions), 'build plan executed no tasks')\n    executable = Path(build)/'bin/llvm-bolt'")
s=s.replace("    return {'tool_build_verified': True,", "    after_sha = digest(executable)\n    before = state['executable_before']\n    return {'planned_tasks': plan['tasks'], 'executed_tasks': len(descriptions),\n            'executable_before': before['exists'], 'executable_before_sha256': before['sha256'],\n            'executable_after_sha256': after_sha,\n            'executable_produced_by_this_build': 'Linking CXX executable bin/llvm-bolt' in descriptions,\n            'tool_build_verified': True,")
s=s.replace("else 0\n    value = {'destination'", "else GIB\n    value = {'destination'")
s=s.replace("    s=sub.add_parser('security');", "    sub.add_parser('preflight'); sub.add_parser('certified')\n    s=sub.add_parser('security');")
s=s.replace("    if a.cmd=='security':", "    if a.cmd=='preflight':result=preflight()\n    elif a.cmd=='certified':result=certified()\n    elif a.cmd=='security':")
p.write_text(s)
S=Path('/home/linhao/Toolchain/development/llvm-optimize/temp/bolt-v4-20261013/v41/llvm-source')
(S/'packaging/clang-bolt-helper.py').write_text(s)
p=S/'packaging/llvm.spec';s=p.read_text();s=s.replace('BuildRequires: xz','BuildRequires: python3 >= 3.9\nBuildRequires: xz',1)
s=s.replace('echo "BOLT_BUILDROOT_OK %{buildroot}"','echo "BOLT_BUILDROOT_OK %{buildroot}"\npython3 %{SOURCE1201} preflight || exit 1\npython3 %{SOURCE1201} certified || exit 1')
s=s.replace('then\n  cat "$BOLT_WORK/tool-build.txt"','then\n  echo BOLT_NINJA_EXIT_0 >> "$BOLT_WORK/tool-build.txt"\n  cat "$BOLT_WORK/tool-build.txt"')
s=s.replace('  "$BOLT_WORK/install-after-pipeline.json" || exit 1','  "$BOLT_WORK/install-after-pipeline.json" || exit 1\necho BOLT_COMPARE_ROOT_PASS\n# Any subsequent buildroot mutation (including native archive conversion) must follow this gate.')
p.write_text(s)
