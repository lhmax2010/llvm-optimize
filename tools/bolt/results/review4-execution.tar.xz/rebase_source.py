from pathlib import Path
import subprocess,json,hashlib
E=Path(__file__).resolve().parent;S=E.parent/'bolt-v4-20261013/v41/llvm-source'
def git(*args):return subprocess.check_output(['git',*args],cwd=S)
base=git('rev-parse','origin/tizen_base').decode().strip();fixed=git('rev-parse','HEAD').decode().strip()
oldspec=git('show','cb679968:packaging/llvm.spec').decode();newbase=git('show',base+':packaging/llvm.spec').decode();s=(S/'packaging/llvm.spec').read_text()
# Insert each unchanged native-archive baseline addition into the fixed BOLT spec.
s=s.replace('Source1004: mlgo_x86_model.tar.gz\n','Source1004: mlgo_x86_model.tar.gz\nSource1005: llvm-static-archives-native.py\n\n%ifarch x86_64\nBuildRequires: util-linux\n%endif\n',1)
start=newbase.index('%ifarch x86_64\n# Run after compilation');end=newbase.index('%post -n clang',start);native=newbase[start:end]
anchor='%ifarch x86_64\n%if %{with clang_bolt}\n# Candidate is fully stripped'
assert s.count(anchor)==1;s=s.replace(anchor,native+anchor)
(E/'rebased.spec').write_text(s);(E/'fixed.spec').write_bytes(git('show',fixed+':packaging/llvm.spec'))
helper=git('show',fixed+':packaging/clang-bolt-helper.py');profile=git('show',fixed+':packaging/clang-bolt-v2.fdata.xz')
subprocess.run(['git','checkout','--detach',base],cwd=S,check=True)
(S/'packaging/llvm.spec').write_text(s);(S/'packaging/clang-bolt-helper.py').write_bytes(helper);(S/'packaging/clang-bolt-v2.fdata.xz').write_bytes(profile)
result={'base':base,'repair_commit':fixed,'new_commits_from_expected':[],'356949_merged':False,'helper_byte_equal':True,'profile_byte_equal':True,'spec_integration':'only Source1005/util-linux/native conversion additions copied verbatim from new baseline'}
(E/'rebase-precommit.json').write_text(json.dumps(result,indent=2)+'\n')
