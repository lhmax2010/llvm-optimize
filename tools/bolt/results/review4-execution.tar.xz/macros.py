from pathlib import Path
import json,sys,re,hashlib,difflib
from new_session import E,R1,INNER,HOST,root_command
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
macros='/usr/lib/rpm/macros:/usr/lib/rpm/macros.d/macros.*:/usr/lib/rpm/platform/%{_target}/macros:/usr/lib/rpm/fileattrs/*.attr:/usr/lib/rpm/tizen/macros:/etc/rpm/macros.*:/etc/rpm/macros:/etc/rpm/%{_target}/macros:/home/abuild/.rpmmacros'
result={'status':'RUNNING','base':'67619ec8bbbac7238a6cfc33a481ccfbcd12206f','modes':{},'calls':[]}
def parts(text):
 matches=list(re.finditer(r'^%(?:prep|build|install|check|clean|post(?:un)?|pre(?:un)?|files)(?:[ \t][^\n]*)?$',text,re.M))
 return {m[0]:text[m.start():matches[i+1].start() if i+1<len(matches) else len(text)] for i,m in enumerate(matches)}
for mode in ('debug','release'):
 expanded={}
 for tag in ('baseline','on','off'):
  args=['/usr/bin/rpmspec','--macros='+(macros if mode=='debug' else macros.replace('/home/abuild/.rpmmacros',INNER+'/release.rpmmacros')),'--parse','--define','_topdir '+INNER+'/macro-parse','--define','_sourcedir '+INNER,'--define','_builddir '+INNER+'/macro-parse/BUILD','--define','_buildrootdir '+INNER+'/macro-parse/BUILDROOTS']
  if mode=='debug':args+=['--define','_toolchain clang','--define','_build_create_debug 1']
  if tag=='off':args+=['--define','_without_clang_bolt --without-clang_bolt']
  args+=[INNER+('/llvm-baseline.spec' if tag=='baseline' else '/llvm-draft.spec')]
  label='macro-'+mode+'-'+tag
  command='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; exec python3 '+h.quote(INNER+'/record_call.py')+' '+label+' '+' '.join(h.quote(v) for v in args)
  p=root_command(['/bin/sh','-c',command],True,capture_output=True,text=True,timeout=120)
  (E/(label+'.stdout')).write_text(p.stdout);(E/(label+'.stderr')).write_text(p.stderr)
  h.require(p.returncode==0,'rpmspec failed '+label)
  expanded[tag]=p.stdout.split('\n',1)[1];(E/(label+'.expanded.spec')).write_text(expanded[tag])
  result['calls'].append(json.loads((HOST/'calls'/(label+'.json')).read_text()))
 base,off=parts(expanded['baseline']),parts(expanded['off']);different=[k for k in base.keys()|off.keys() if base.get(k)!=off.get(k)]
 for k in different:(E/(mode+'-'+k[1:].replace(' ','_')+'.diff')).write_text(''.join(difflib.unified_diff(base.get(k,'').splitlines(True),off.get(k,'').splitlines(True))))
 h.require(not different,'OFF sections differ from new baseline: '+str(different))
 on=parts(expanded['on'])['%install'];conversion='python3 '+INNER+'/llvm-static-archives-native.py --root '
 pos=[on.index('python3 '+INNER+'/clang-bolt-helper.py '+op) for op in ('snapshot ','compare-root ')]
 pos+=[on.index(conversion),on.index('python3 '+INNER+'/clang-bolt-helper.py install ')]
 h.require(pos==sorted(pos) and len(set(pos))==4,'BOLT/conversion install order incorrect: '+mode)
 h.require(on.count(conversion)==1 and off['%install'].count(conversion)==1,'native conversion count incorrect: '+mode)
 h.require(on.index('echo BOLT_COMPARE_ROOT_PASS')<pos[2],'compare-root anchor must precede conversion')
 result['modes'][mode]={'OFF_byte_equal_sections':sorted(base),'install_order_positions':pos,'conversion_on_count':on.count(conversion),'conversion_off_count':off['%install'].count(conversion),'status':'PASS'}
result['status']='PASS';h.save(E/'macro-result.json',result);print(json.dumps(result,indent=2))
