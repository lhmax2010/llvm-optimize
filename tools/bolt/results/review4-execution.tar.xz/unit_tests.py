import subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt')
with (E/'tests.stdout.txt').open('wb') as out,(E/'tests.stderr.txt').open('wb') as err:
    r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tools/bolt','-p','test_*.py','-v'],cwd=B,stdout=out,stderr=err)
sys.exit(r.returncode)
