from pathlib import Path
import sys,json,time,traceback
E=Path(__file__).resolve().parent
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
R=Path('/var/tmp/llvm-optimize-x86-archivefix-20261013/local/BUILD-ROOTS/scratch.x86_64.0')
a=R/'home/abuild/rpmbuild/BUILD/llvm-22.1.8/build/bin/clang-22';b=R/'home/abuild/bolt-work/bolt-v4-20261014-fallback/clang.candidate'
start=time.monotonic();sha={k:h.digest(p) for k,p in [('ordinary',a),('candidate',b)]}
h.require(sha['ordinary']=='7df0ff90dbca7f99ed6a642546281584dbfaab1528a94abf7a1bb524ca371b2c','ordinary identity changed')
h.require(sha['candidate']=='4ec07159aeb4f9300361b95955db05bfca06ece5b748796b28e9b8965145fff9','candidate identity changed')
values={k:h.security_properties(p) for k,p in [('ordinary',a),('candidate',b)]}
h.save(E/'real-security-properties.json',values)
try:
 result=h.security_compare(a,b)
except h.GateError as error:
 result={'status':'FAIL_SECURITY_DIFFERENCE','error':str(error),'sha256':sha,'differences':{k:{'ordinary':values['ordinary'][k],'candidate':values['candidate'][k]} for k in values['ordinary'] if values['ordinary'][k]!=values['candidate'][k]},'wall_s':time.monotonic()-start}
 h.save(E/'real-security-result.json',result);print(json.dumps(result,ensure_ascii=False,indent=2),flush=True);sys.exit(1)
result.update(status='PASS',wall_s=time.monotonic()-start);h.save(E/'real-security-result.json',result);print(json.dumps(result,indent=2),flush=True)
