from pathlib import Path
import json,sys,subprocess,re,hashlib,difflib
from new_session import E,R1,INNER,HOST,root_command
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
macros='/usr/lib/rpm/macros:/usr/lib/rpm/macros.d/macros.*:/usr/lib/rpm/platform/%{_target}/macros:/usr/lib/rpm/fileattrs/*.attr:/usr/lib/rpm/tizen/macros:/etc/rpm/macros.*:/etc/rpm/macros:/etc/rpm/%{_target}/macros:/home/abuild/.rpmmacros'
source=(HOST/'llvm-draft.spec').read_text();a=source.index('%global __bolt_original_spec_install_post');b=source.index('\n%endif',a);fragment=source[a:b]+'\n'
(E/'post-fragment.spec').write_text(fragment)
rows=[];sections={};expanded={}
def parse(label,path,mode,off=False):
 args=['/usr/bin/rpmspec','--macros='+macros,'--parse','--define','_topdir '+INNER+'/macro-parse','--define','_sourcedir '+INNER,'--define','_builddir '+INNER+'/macro-parse/BUILD','--define','_buildrootdir '+INNER+'/macro-parse/BUILDROOTS']
 args+=['--define','_toolchain clang'] if mode=='debug' else ['--undefine','_toolchain']
 if off:args+=['--define','_without_clang_bolt --without-clang_bolt']
 args+=[path]
 command='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; exec python3 '+h.quote(INNER+'/record_call.py')+' '+h.quote(label)+' '+' '.join(h.quote(x) for x in args)
 p=root_command(['/bin/sh','-c',command],True,capture_output=True,text=True,timeout=120)
 (E/(label+'.stdout')).write_text(p.stdout);(E/(label+'.stderr')).write_text(p.stderr)
 h.require(p.returncode==0,'rpmspec failed '+label)
 value=p.stdout.split('\n',1)[1];(E/(label+'.expanded.spec')).write_text(value)
 rows.append({'label':label,'mode':mode,'without_clang_bolt':off,'expanded_sha256':hashlib.sha256(value.encode()).hexdigest(),'call':json.loads((HOST/'calls'/(label+'.json')).read_text())})
 return value
def parts(text):
 matches=list(re.finditer(r'^%(?:prep|build|install|check|clean|post(?:un)?|pre(?:un)?|files)(?:\s[^\n]*)?$',text,re.M));result={}
 for i,m in enumerate(matches):
  key=m[0];result[key]=text[m.start():matches[i+1].start() if i+1<len(matches) else len(text)]
 return result
args=['/usr/bin/rpmbuild','--macros='+macros,'--without','clang_bolt','--eval','%{?_without_clang_bolt}']
command='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; exec python3 '+h.quote(INNER+'/record_call.py')+' macro-without-effect '+' '.join(h.quote(x) for x in args)
p=root_command(['/bin/sh','-c',command],True,capture_output=True,text=True,timeout=120)
(E/'macro-without-effect.stdout').write_text(p.stdout);(E/'macro-without-effect.stderr').write_text(p.stderr)
h.require(p.returncode==0 and p.stdout.split('\n',1)[1].strip()=='--without-clang_bolt','rpmbuild --without macro effect unproven')
result={'status':'RUNNING','modes':{},'rows':rows,'macro_fragment':fragment,'literal_fragment_sha256':hashlib.sha256(fragment.encode()).hexdigest(),'without_compatibility':'rpmspec rejects --without; rpmbuild --without sets _without_clang_bolt to literal --without-clang_bolt (not integer1); rpmspec receives that exact macro definition; installed bcond_without tests existence only','historical_note':'20 mini specs substituted helper/work/resource paths directly; they were structurally equivalent, not literally identical. Current canonical mini specs below embed the exact source fragment; parsed only, no new rpmbuild claim.'}
for mode in ('debug','release'):
 for tag,off,name in [('on',False,'llvm-draft.spec'),('off',True,'llvm-draft.spec'),('baseline',False,'llvm-baseline.spec')]:
  label='macro-'+mode+'-'+tag;expanded[mode,tag]=parse(label,INNER+'/'+name,mode,off)
 base,off=parts(expanded[mode,'baseline']),parts(expanded[mode,'off'])
 differences=[]
 for key in sorted(base.keys()|off.keys()):
  if base.get(key)!=off.get(key):
   differences.append(key);(E/(mode+'-'+key[1:].replace(' ','_')+'.diff')).write_text(''.join(difflib.unified_diff(base.get(key,'').splitlines(True),off.get(key,'').splitlines(True),fromfile='baseline',tofile='BOLT-off')))
 result['modes'][mode]={'section_count':len(base),'byte_equal_sections':[k for k in base if base.get(k)==off.get(k)],'different_sections':differences}
 # Canonical mini spec: exact source override, and a real position after install/files.
 mini=('' if mode=='debug' else '%define debug_package %{nil}\n')+'''Name: bolt-macro-proof
Version: 1
Release: 1
Summary: Literal production post macro fragment proof
License: Apache-2.0
Source1201: clang-bolt-helper.py
%define buildsubdir llvm-22.1.8
%define llvm_version 22
%description
Configuration evidence only; no claim of a new rpmbuild execution.
'''+('%debug_package\n' if mode=='debug' else '')+'''%prep
%build
%install
mkdir -p %{buildroot}/usr/bin
%files
/usr/bin/clang-22
'''+fragment
 h.require(mini[mini.index('%global __bolt_original_spec_install_post'):]==fragment,'mini fragment differs')
 h.require(mini.index('%install\n')<mini.index('%files\n')<mini.index('%global __bolt_original_spec_install_post'),'mini macro order wrong')
 h.require(source.index('%install\n')<source.index('%files\n')<source.index(fragment),'source macro order wrong')
 (HOST/('macro-mini-'+mode+'.spec')).write_text(mini);(E/('macro-mini-'+mode+'.spec')).write_text(mini)
 parse('macro-mini-'+mode,INNER+'/macro-mini-'+mode+'.spec',mode)
 result['modes'][mode]['mini_source_fragment_byte_equal']=True
 result['modes'][mode]['fragment_after_install_and_files']=True
result['status']='FAIL_DISABLED_SPEC_DIFF' if any(x['different_sections'] for x in result['modes'].values()) else 'PASS'
h.save(E/'macro-result.json',result);print(json.dumps(result,indent=2),flush=True)
h.require(result['status']=='PASS','BOLT disabled sections differ from cb baseline; stop')
