import os,subprocess,sys,json
from pathlib import Path
B=Path("/home/linhao/Toolchain/development/llvm-optimize-bolt")
r=subprocess.run([sys.executable,"-m","unittest","discover","-s","tools/bolt","-p","test_*.py","-v"],cwd=B,capture_output=True,text=True)
E=Path(__file__).resolve().parent
(E/"tests.stdout").write_text(r.stdout);(E/"tests.stderr").write_text(r.stderr)
(E/"tests-result.json").write_text(json.dumps({"rc":r.returncode},indent=2))
print(r.stderr[-3000:]);sys.exit(r.returncode)
