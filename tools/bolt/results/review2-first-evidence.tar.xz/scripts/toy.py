from pathlib import Path
import json,shutil,subprocess,sys,time,re
from new_session import E,R1,INNER,HOST,root_command
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
HOST.mkdir(exist_ok=False);(HOST/'tmp').mkdir();source=HOST/'toy';build=source/'build';source.mkdir();build.mkdir()
for src,name in [(E/'probe_call.py','probe_call.py'),(E.parent/'bolt-v4-20261015-reviewfinish/rpm-env-prefix.sh','rpm-env-prefix.sh')]:shutil.copyfile(src,HOST/name)
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.16)
project(review2_probe C)
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/anchor.c" "int __tf_xla_runtime_anchor(void){return 0;}\\n")
add_library(probe STATIC "${CMAKE_CURRENT_BINARY_DIR}/anchor.c")
''')
calls=[]
def invoke(label,argv,cwd=INNER+'/toy/build'):
 cmd='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; set +x; cd '+h.quote(cwd)+'; exec python3 '+h.quote(INNER+'/probe_call.py')+' '+h.quote(label)+' '+' '.join(h.quote(x) for x in argv)
 p=root_command(['/bin/sh','-c',cmd],True,capture_output=True,text=True,timeout=150)
 (E/(label+'.wrapper.stdout')).write_text(p.stdout);(E/(label+'.wrapper.stderr')).write_text(p.stderr)
 record=json.loads((HOST/'toy-calls'/(label+'.json')).read_text());calls.append(record)
 for suffix in ['stdout','stderr','combined','json']:shutil.copyfile(HOST/'toy-calls'/(label+'.'+suffix),E/(label+'.'+suffix))
 h.require(p.returncode==0,label+' failed; see raw streams')
 return (E/(label+'.stdout')).read_text(),(E/(label+'.stderr')).read_text()
invoke('cmake-version',['/bin/cmake','--version']);invoke('ninja-version',['/bin/ninja','--version'])
configure=['/bin/cmake','-S',INNER+'/toy','-B',INNER+'/toy/build','-G','Ninja','-DCMAKE_C_COMPILER=clang','-DCMAKE_C_FLAGS=','-DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY']
invoke('toy-configure',configure);invoke('toy-build',['/bin/ninja','-j1','probe'])
out,err=invoke('toy-up-to-date',['/bin/ninja','-n','probe'])
result={'status':'RUNNING','calls':calls,'up_to_date':{'stdout':out,'stderr':err,'expected_single_no_work':out.strip()=='ninja: no work to do.' and not err},'caveat':'toy-only project; C flags empty and try-compile static; LLVM tree not configured or built; combined log is selector receipt order across two pipes'}
h.require(result['up_to_date']['expected_single_no_work'],'unexpected up-to-date output')
time.sleep(1.1);invoke('toy-touch',['/bin/touch',INNER+'/toy/CMakeLists.txt'])
out,err=invoke('toy-rerun',['/bin/ninja','-n','probe'])
lines=out.splitlines();progress=[re.fullmatch(r'\[(\d+)/(\d+)\] (.*)',line) for line in lines]
agrees=len(lines)==1 and progress[0] is not None and progress[0][3]=='Re-running CMake...' and not err
result['dirty_manifest']={'stdout':out,'stderr':err,'only_one_regeneration_progress_line':agrees}
if not agrees:
 result['status']='STOP_PM_DRY_RUN_ASSUMPTION_REFUTED';h.save(E/'toy-result.json',result);print(json.dumps(result,indent=2),flush=True);raise h.GateError('PM dry-run regeneration assumption refuted; stop')
anchor=build/'anchor.c';before={'sha256':h.digest(anchor),'bytes':anchor.stat().st_size,'mtime_ns':anchor.stat().st_mtime_ns}
time.sleep(1.1);invoke('toy-reconfigure',configure);after={'sha256':h.digest(anchor),'bytes':anchor.stat().st_size,'mtime_ns':anchor.stat().st_mtime_ns}
out,err=invoke('toy-write-rerun',['/bin/ninja','-n','probe'])
result['file_WRITE']={'before':before,'after':after,'stdout':out,'stderr':err,'source_mtime_refreshed':after['mtime_ns']>before['mtime_ns'],'object_recompile':'Building C object ' in out,'archive_relink':'Linking C static library ' in out}
h.require(result['file_WRITE']['source_mtime_refreshed'] and result['file_WRITE']['object_recompile'],'file WRITE evidence missing')
result['status']='PASS';h.save(E/'toy-result.json',result);print(json.dumps(result,indent=2),flush=True)
