from pathlib import Path
import json,re,hashlib,shutil,collections
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');old=E.parent/'bolt-measurement-20260918/incremental-final'
raw=old/'ninja-dry-run.log';text=raw.read_text();rows=[];nonprogress=[]
for line in text.splitlines():
 m=re.fullmatch(r'(\d{4}-\d\d-\d\dT\S+) \[(\d+)/(\d+)\] (.+)',line)
 if m:rows.append({'timestamp':m[1],'f':int(m[2]),'t':int(m[3]),'description':m[4],'raw':line})
 else:nonprogress.append(line)
assert len(rows)==126 and [r['f'] for r in rows]==list(range(1,127)) and {r['t'] for r in rows}=={126}
tf=[r for r in rows if r['description'] in ['Building C object lib64/tf_runtime/CMakeFiles/tf_xla_runtime.dir/tf_xla_runtime_dummy.c.o','Linking C static library lib64/libtf_xla_runtime.a']];assert len(tf)==2
descriptions=json.loads((B/'tools/bolt/results/review-tool-descriptions.json').read_text())
classes=collections.Counter('BOLT_objects' if r['description'].startswith('Building CXX object tools/bolt/') else 'BOLT_static_libraries' if r['description'].startswith('Linking CXX static library lib64/libLLVMBOLT') else 'BOLT_executables' if r['description'].startswith('Linking CXX executable bin/') else 'TF' if r in tf else 'other_historical_tasks' for r in rows)
result={'status':'PASS_FORMAT_AND_TF_EVIDENCE','source':str(raw),'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'total_lines':len(text.splitlines()),'progress_rows':len(rows),'progress_prefix':'collector timestamp before [f/t]; original unprefixed stdout/stderr not separately recoverable','f_contiguous_from1':True,'t_constant':126,'tf_rows':tf,'nonprogress_lines':nonprogress,'classes':dict(classes),'not_current_configuration':'historical runtime ON, AArch64+X86 and merge-fdata; cannot certify current task whitelist','current_110_exact_descriptions_present':sum(r['description'] in descriptions for r in rows)}
(E/'historical-result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copyfile(raw,B/'tools/bolt/results/review2-historical-dry-run.txt')
(B/'tools/bolt/results/review2-historical-format.json').write_text(json.dumps(result,indent=2)+'\n')
(E/'historical-unprefixed-derived.txt').write_text('\n'.join('[%d/%d] %s'%(r['f'],r['t'],r['description']) for r in rows)+'\n')
print(json.dumps(result,indent=2),flush=True)
