from pathlib import Path
import subprocess,sys,os,json,selectors,time
base=Path(__file__).resolve().parent/'toy-calls';base.mkdir(exist_ok=True)
label=sys.argv[1];argv=sys.argv[2:];start=time.monotonic()
env=dict(os.environ,LC_ALL='C',NINJA_STATUS='[%f/%t] ')
record={'argv':argv,'cwd':os.getcwd(),'PATH':env['PATH'],'which_clang':subprocess.check_output(['which','clang'],text=True).strip(),'which_clangxx':subprocess.check_output(['which','clang++'],text=True).strip(),'LC_ALL':env['LC_ALL'],'NINJA_STATUS':env['NINJA_STATUS']}
with (base/(label+'.stdout')).open('wb') as out,(base/(label+'.stderr')).open('wb') as err,(base/(label+'.combined')).open('wb') as combined:
 p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ,out);selector.register(p.stderr,selectors.EVENT_READ,err)
 while selector.get_map():
  if time.monotonic()-start>120:p.kill();raise RuntimeError('toy command timeout')
  for key,_ in selector.select(.1):
   data=os.read(key.fd,65536)
   if data:key.data.write(data);combined.write(data)
   else:selector.unregister(key.fileobj);key.fileobj.close()
 record['rc']=p.wait(timeout=10)
record['wall_s']=time.monotonic()-start
(base/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.exit(record['rc'])
