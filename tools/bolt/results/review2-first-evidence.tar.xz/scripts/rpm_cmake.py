from pathlib import Path
import sys,json,subprocess,hashlib,re
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
baseline=E.parent/'bolt-v4-20261015-validation/RPM-baseline.json';packages=json.loads(baseline.read_text())['packages'];assert len(packages)==22
tokens=['LLVMBOLT','llvm-bolt','perf2bolt','llvm-boltdiff','merge-fdata'];rows=[];old_hits=[];new_hits=[]
for package in packages:
 rpm=Path(package['RPM_path']);h.require(h.digest(rpm)==package['RPM_sha256'],'ordinary RPM identity changed '+package['name'])
 p=subprocess.run(['rpm','-qp','--nosignature','--nodigest','--queryformat','[%{FILENAMES}\n]',str(rpm)],capture_output=True,text=True,timeout=60)
 (E/(package['name']+'-filelist.stdout')).write_text(p.stdout);(E/(package['name']+'-filelist.stderr')).write_text(p.stderr);h.require(p.returncode==0,'RPM filelist failed')
 names=sorted(name for name in p.stdout.splitlines() if name.lower().endswith('.cmake'))
 expected=sorted(row['path'] for row in package['files'] if row['path'].lower().endswith('.cmake'));h.require(names==expected,'RPM header baseline mismatch')
 root=E/'rpm-cmake'/package['name'];root.mkdir(parents=True)
 if names:
  with (E/(package['name']+'-extract.stderr')).open('w') as err:
   a=subprocess.Popen(['rpm2cpio',str(rpm)],stdout=subprocess.PIPE,stderr=err)
   q=subprocess.run(['cpio','-id','--quiet','--no-absolute-filenames','*.cmake'],stdin=a.stdout,cwd=root,stdout=err,stderr=err,timeout=120);a.stdout.close();arc=a.wait(timeout=15)
  h.require(q.returncode==arc==0,'CMake extraction failed '+package['name'])
 actual=sorted('/'+p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink());h.require(actual==names,'CMake extraction coverage differs '+package['name'])
 file_rows=[]
 for name in names:
  path=root/name.lstrip('/');h.require(path.is_file() and not path.is_symlink(),'unexpected cmake link '+name)
  text=path.read_text(errors='surrogateescape');sha=h.digest(path);header=next(r for r in package['files'] if r['path']==name);h.require(sha==header['sha256'],'CMake payload/header SHA mismatch')
  previous=[{'line':i,'text':line,'matched_substrings':re.findall('BOLT',line.upper())} for i,line in enumerate(text.splitlines(),1) if 'BOLT' in line.upper()]
  current=[{'line':i,'text':line,'matched_substrings':[token for token in tokens if token in line]} for i,line in enumerate(text.splitlines(),1) if any(token in line for token in tokens)]
  if previous:old_hits.append({'package':package['name'],'path':name,'matches':previous})
  if current:new_hits.append({'package':package['name'],'path':name,'matches':current})
  file_rows.append({'path':name,'sha256':sha,'bytes':path.stat().st_size,'old_hit_count':len(previous),'new_hit_count':len(current)})
 rows.append({'package':package['name'],'RPM_sha256':package['RPM_sha256'],'header_query_rc':p.returncode,'cmake_files':file_rows})
result={'status':'FAIL_NEW_CMAKE_TOKEN' if new_hits else 'PASS','packages':rows,'package_count':len(rows),'cmake_count':sum(len(r['cmake_files']) for r in rows),'old_hits':old_hits,'new_hits':new_hits,'new_rule_case_sensitive':tokens,'b7_post_false_rejection':bool(old_hits) and not new_hits}
h.save(E/'rpm-cmake-result.json',result);print(json.dumps({k:v for k,v in result.items() if k!='packages'},indent=2),flush=True)
h.require(not new_hits,'new CMake rule found BOLT product; stop')
