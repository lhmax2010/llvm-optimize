# Install script for directory: /home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang-tools-extra/clang-tidy

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/bin/llvm-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clangTidy" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib64" TYPE STATIC_LIBRARY FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/libclangTidy.a")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/android/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/abseil/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/altera/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/boost/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/bugprone/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/cert/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/concurrency/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/cppcoreguidelines/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/custom/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/darwin/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/fuchsia/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/google/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/hicpp/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/linuxkernel/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/llvm/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/llvmlibc/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/misc/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/modernize/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/mpi/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/objc/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/openmp/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/performance/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/portability/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/readability/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/zircon/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/plugin/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/tool/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/utils/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-tidy-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/clang-tidy" TYPE DIRECTORY FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang-tools-extra/clang-tidy/." FILES_MATCHING REGEX "/[^/]*\\.h$")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/tools/extra/clang-tidy/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
