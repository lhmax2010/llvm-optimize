# Install script for directory: /home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/bin/llvm-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/builtins.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/float.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__float_float.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__float_header_macro.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__float_infinity_nan.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/inttypes.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/iso646.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/limits.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/module.modulemap"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdalign.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdarg.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg___gnuc_va_list.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg___va_copy.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_header_macro.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_va_arg.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_va_copy.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_va_list.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdatomic.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdbool.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdcountof.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdckdint.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stddef.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stddefer.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_header_macro.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_max_align_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_null.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_nullptr_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_offsetof.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_ptrdiff_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_rsize_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_size_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_unreachable.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_wchar_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_wint_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdint.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdnoreturn.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tgmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/unwind.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/varargs.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm_acle.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm_cmse.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/armintr.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm64intr.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm_neon_sve_bridge.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_builtin_vars.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_math.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_cmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_complex_builtins.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_device_functions.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_texture_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_libdevice_declares.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_math_forward_declares.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_runtime_wrapper.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hexagon_circ_brev_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hexagon_protos.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hexagon_types.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hvx_hexagon_protos.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_libdevice_declares.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_cmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_math.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_stdlib.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_runtime_wrapper.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/larchintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lasxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lsxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/msa.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/opencl-c.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/opencl-c-base.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/altivec.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amo.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/htmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/htmxlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_bitmanip.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_corev_alu.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_crypto.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_nds.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_ntlh.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sifive_vector.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/andes_vector.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_mips.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_spirv_builtins.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/s390intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vecintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/velintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/velintrin_gen.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/velintrin_approx.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/adcintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/adxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ammintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxavx512intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxcomplexintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxfp16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxfp8intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxmovrsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxtf32intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512bf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512convertintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512minmaxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512niintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512satcvtdsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512satcvtintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2bf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2convertintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2copyintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2minmaxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2niintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2satcvtdsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2satcvtintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512bf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512bitalgintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512bwintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512cdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512dqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512fintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512fp16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512ifmaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512ifmavlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vbmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vbmiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vbmivlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlbf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlbitalgintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlbwintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlcdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vldqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlfp16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlvbmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlvnniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlvp2intersectintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vnniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vp2intersectintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vpopcntdqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vpopcntdqvlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxifmaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxneconvertintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxvnniint16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxvnniint8intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxvnniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/bmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/bmiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cetintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cldemoteintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/clflushoptintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/clwbintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/clzerointrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cmpccxaddintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/crc32intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/emmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/enqcmdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/f16cintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/fma4intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/fmaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/fxsrintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/gfniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hresetintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ia32intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/immintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/invpcidintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/keylockerintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lwpintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lzcntintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mm3dnow.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movdirintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movrs_avx10_2_512intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movrs_avx10_2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movrsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mwaitxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/nmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/pconfigintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/pkuintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/pmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/popcntintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/prfchiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/prfchwintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ptrauth.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ptwriteintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/raointintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/rdpruintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/rdseedintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/rtmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/serializeintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sgxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sha512intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/shaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sm3intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sm4intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sm4evexintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/smmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tbmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tsxldtrkintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/uintrintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/usermsrintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vaesintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vpclmulqdqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/waitpkgintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/wbnoinvdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__wmmintrin_aes.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/wmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__wmmintrin_pclmul.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/x86gprintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/x86intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xopintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsavecintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsaveintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsaveoptintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsavesintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xtestintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cet.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cpuid.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/gpuintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/nvptxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amdgpuintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/spirvintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/wasm_simd128.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/intrin0.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vadefs.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/yvals_core.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mm_malloc.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_neon.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_fp16.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_sve.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_sme.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_bf16.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_mve.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_cde.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_vector_types.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/cuda_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/algorithm"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/cmath"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/complex"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/new"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/cuda_wrappers/bits" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/c++config.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/shared_ptr_base.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/basic_string.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/basic_string.tcc"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/cuda_wrappers/__utility" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/__utility/declval.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/ppc_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/mmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/xmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/mm_malloc.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/emmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/pmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/tmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/smmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/nmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/bmiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/bmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/immintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/x86intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/x86gprintrin.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/llvm_libc_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/assert.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/stdio.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/stdlib.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/string.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/ctype.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/inttypes.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_libc_wrappers/time.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/openmp_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/math.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/cmath"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/complex"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/complex.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/__clang_openmp_device_functions.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/complex_cmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/new"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/llvm_offload_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_offload_wrappers/__llvm_offload.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_offload_wrappers/__llvm_offload_host.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_offload_wrappers/__llvm_offload_device.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang-resource-headers" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/zos_wrappers" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/zos_wrappers/builtins.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "core-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/builtins.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/float.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__float_float.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__float_header_macro.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__float_infinity_nan.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/inttypes.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/iso646.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/limits.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/module.modulemap"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdalign.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdarg.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg___gnuc_va_list.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg___va_copy.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_header_macro.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_va_arg.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_va_copy.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stdarg_va_list.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdatomic.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdbool.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdcountof.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdckdint.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stddef.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stddefer.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_header_macro.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_max_align_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_null.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_nullptr_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_offsetof.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_ptrdiff_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_rsize_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_size_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_unreachable.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_wchar_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__stddef_wint_t.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdint.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/stdnoreturn.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tgmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/unwind.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/varargs.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "arm-common-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm_acle.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_neon.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_fp16.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "arm-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm_cmse.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/armintr.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_mve.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_cde.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "aarch64-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm64intr.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/arm_neon_sve_bridge.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_sve.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_sme.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_bf16.h"
    "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/arm_vector_types.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "cuda-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/cuda_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/algorithm"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/cmath"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/complex"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/new"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "cuda-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/cuda_wrappers/bits" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/c++config.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/shared_ptr_base.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/basic_string.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/bits/basic_string.tcc"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "cuda-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/cuda_wrappers/__utility" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cuda_wrappers/__utility/declval.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "cuda-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_builtin_vars.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_math.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_cmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_complex_builtins.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_device_functions.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_texture_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_libdevice_declares.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_math_forward_declares.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_cuda_runtime_wrapper.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "hexagon-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hexagon_circ_brev_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hexagon_protos.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hexagon_types.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hvx_hexagon_protos.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "hip-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_libdevice_declares.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_cmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_math.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_stdlib.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_hip_runtime_wrapper.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "loongarch-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/larchintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lasxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lsxintrin.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "mips-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/msa.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ppc-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/ppc_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/mmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/xmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/mm_malloc.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/emmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/pmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/tmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/smmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/nmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/bmiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/bmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/immintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/x86intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ppc_wrappers/x86gprintrin.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ppc-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/altivec.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amo.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ppc-htm-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/htmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/htmxlintrin.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "riscv-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_bitmanip.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_corev_alu.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_crypto.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_nds.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_ntlh.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sifive_vector.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/andes_vector.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/riscv_mips.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "systemz-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/s390intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vecintrin.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "systemz-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/zos_wrappers" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/zos_wrappers/builtins.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "ve-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/velintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/velintrin_gen.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/velintrin_approx.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "webassembly-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/wasm_simd128.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "x86-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/adcintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/adxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ammintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxavx512intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxcomplexintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxfp16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxfp8intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxmovrsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amxtf32intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512bf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512convertintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512minmaxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512niintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512satcvtdsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2_512satcvtintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2bf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2convertintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2copyintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2minmaxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2niintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2satcvtdsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx10_2satcvtintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512bf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512bitalgintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512bwintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512cdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512dqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512fintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512fp16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512ifmaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512ifmavlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vbmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vbmiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vbmivlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlbf16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlbitalgintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlbwintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlcdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vldqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlfp16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlvbmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlvnniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vlvp2intersectintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vnniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vp2intersectintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vpopcntdqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avx512vpopcntdqvlintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxifmaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxneconvertintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxvnniint16intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxvnniint8intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/avxvnniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/bmi2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/bmiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cetintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cldemoteintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/clflushoptintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/clwbintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/clzerointrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cmpccxaddintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/crc32intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/emmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/enqcmdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/f16cintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/fma4intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/fmaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/fxsrintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/gfniintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hresetintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ia32intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/immintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/invpcidintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/keylockerintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lwpintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/lzcntintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mm3dnow.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movdirintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movrs_avx10_2_512intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movrs_avx10_2intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/movrsintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mwaitxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/nmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/pconfigintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/pkuintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/pmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/popcntintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/prfchiintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/prfchwintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ptrauth.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/ptwriteintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/raointintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/rdpruintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/rdseedintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/rtmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/serializeintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sgxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sha512intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/shaintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sm3intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sm4intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/sm4evexintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/smmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tbmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/tsxldtrkintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/uintrintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/usermsrintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vaesintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vpclmulqdqintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/waitpkgintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/wbnoinvdintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__wmmintrin_aes.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/wmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__wmmintrin_pclmul.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/x86gprintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/x86intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xmmintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xopintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsavecintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsaveintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsaveoptintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xsavesintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/xtestintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cet.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/cpuid.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "gpu-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/gpuintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/nvptxintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/amdgpuintrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/spirvintrin.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "hlsl-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "hlsl-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/hlsl" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_basic_types.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_alias_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_compat_overloads.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_intrinsic_helpers.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_intrinsics.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_detail.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/hlsl/hlsl_spirv.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "spirv-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/__clang_spirv_builtins.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "opencl-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/opencl-c.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/opencl-c-base.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "openmp-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/openmp_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/math.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/cmath"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/complex"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/complex.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/__clang_openmp_device_functions.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/complex_cmath.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/openmp_wrappers/new"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "openmp-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include/llvm_offload_wrappers" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_offload_wrappers/__llvm_offload.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_offload_wrappers/__llvm_offload_host.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/llvm_offload_wrappers/__llvm_offload_device.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "utility-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/mm_malloc.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "windows-resource-headers")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/include" TYPE FILE FILES
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/intrin0.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/intrin.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/vadefs.h"
    "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/lib/Headers/yvals_core.h"
    )
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/lib/Headers/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
