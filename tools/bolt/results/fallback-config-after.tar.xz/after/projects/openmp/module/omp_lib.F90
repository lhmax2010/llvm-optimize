! include/omp_lib.f90.var

!
!//===----------------------------------------------------------------------===//
!//
!// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
!// See https://llvm.org/LICENSE.txt for license information.
!// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
!//
!//===----------------------------------------------------------------------===//
!

      module omp_lib_kinds

        use, intrinsic :: iso_c_binding

        ! Set PRIVATE by default to explicitly only export what is meant
        ! to be exported by this MODULE.
        private

        integer, parameter, public :: omp_integer_kind       = c_int
        integer, parameter, public :: omp_logical_kind       = 4
        integer, parameter, public :: omp_real_kind          = c_float
        integer, parameter, public :: kmp_double_kind        = c_double
        integer, parameter, public :: omp_lock_kind          = c_intptr_t
        integer, parameter, public :: omp_nest_lock_kind     = c_intptr_t
        integer, parameter, public :: omp_sched_kind         = omp_integer_kind
        integer, parameter, public :: omp_proc_bind_kind     = omp_integer_kind
        integer, parameter, public :: kmp_pointer_kind       = c_intptr_t
        integer, parameter, public :: kmp_size_t_kind        = c_size_t
        integer, parameter, public :: kmp_affinity_mask_kind = c_intptr_t
        integer, parameter, public :: kmp_cancel_kind        = omp_integer_kind
        integer, parameter, public :: omp_sync_hint_kind     = omp_integer_kind
        integer, parameter, public :: omp_lock_hint_kind     = omp_sync_hint_kind
        integer, parameter, public :: omp_control_tool_kind  = omp_integer_kind
        integer, parameter, public :: omp_control_tool_result_kind = omp_integer_kind
        integer, parameter, public :: omp_allocator_handle_kind = c_intptr_t
        integer, parameter, public :: omp_memspace_handle_kind = c_intptr_t
        integer, parameter, public :: omp_alloctrait_key_kind = omp_integer_kind
        integer, parameter, public :: omp_alloctrait_val_kind = c_intptr_t
        integer, parameter, public :: omp_interop_kind = c_intptr_t
        integer, parameter, public :: omp_interop_fr_kind = omp_integer_kind

        type omp_alloctrait
          integer(kind=omp_alloctrait_key_kind) key
          integer(kind=omp_alloctrait_val_kind) value
        end type omp_alloctrait
        public :: omp_alloctrait

        integer, parameter, public :: omp_pause_resource_kind = omp_integer_kind
        integer, parameter, public :: omp_depend_kind = c_intptr_t
        integer, parameter, public :: omp_event_handle_kind = c_intptr_t

      end module omp_lib_kinds

      module omp_lib

        use omp_lib_kinds

        ! Set PRIVATE by default to explicitly only export what is meant
        ! to be exported by this MODULE.
        private

        ! Re-export definitions in omp_lib_kinds
        public :: omp_integer_kind
        public :: omp_logical_kind
        public :: omp_real_kind
        public :: kmp_double_kind
        public :: omp_lock_kind
        public :: omp_nest_lock_kind
        public :: omp_sched_kind
        public :: omp_proc_bind_kind
        public :: kmp_pointer_kind
        public :: kmp_size_t_kind
        public :: kmp_affinity_mask_kind
        public :: kmp_cancel_kind
        public :: omp_sync_hint_kind
        public :: omp_lock_hint_kind
        public :: omp_control_tool_kind
        public :: omp_control_tool_result_kind
        public :: omp_allocator_handle_kind
        public :: omp_memspace_handle_kind
        public :: omp_alloctrait_key_kind
        public :: omp_alloctrait_val_kind
        public :: omp_interop_kind
        public :: omp_interop_fr_kind
        public :: omp_alloctrait
        public :: omp_pause_resource_kind
        public :: omp_depend_kind
        public :: omp_event_handle_kind

        integer (kind=omp_integer_kind), parameter, public :: openmp_version    = 201611
        integer (kind=omp_integer_kind), parameter, public :: kmp_version_major = 5
        integer (kind=omp_integer_kind), parameter, public :: kmp_version_minor = 0
        integer (kind=omp_integer_kind), parameter, public :: kmp_version_build = 20140926
        character(*)               kmp_build_date
        parameter( kmp_build_date = 'No_Timestamp' )

        integer(kind=omp_sched_kind), parameter, public :: omp_sched_static  = 1
        integer(kind=omp_sched_kind), parameter, public :: omp_sched_dynamic = 2
        integer(kind=omp_sched_kind), parameter, public :: omp_sched_guided  = 3
        integer(kind=omp_sched_kind), parameter, public :: omp_sched_auto    = 4
        integer(kind=omp_sched_kind), parameter, public :: omp_sched_monotonic = int(Z'80000000', kind=omp_sched_kind)

        integer (kind=omp_proc_bind_kind), parameter, public :: omp_proc_bind_false = 0
        integer (kind=omp_proc_bind_kind), parameter, public :: omp_proc_bind_true = 1
        integer (kind=omp_proc_bind_kind), parameter, public :: omp_proc_bind_master = 2
        integer (kind=omp_proc_bind_kind), parameter, public :: omp_proc_bind_close = 3
        integer (kind=omp_proc_bind_kind), parameter, public :: omp_proc_bind_spread = 4

        integer (kind=kmp_cancel_kind), parameter, public :: kmp_cancel_parallel = 1
        integer (kind=kmp_cancel_kind), parameter, public :: kmp_cancel_loop = 2
        integer (kind=kmp_cancel_kind), parameter, public :: kmp_cancel_sections = 3
        integer (kind=kmp_cancel_kind), parameter, public :: kmp_cancel_taskgroup = 4

        integer (kind=omp_sync_hint_kind), parameter, public :: omp_sync_hint_none           = 0
        integer (kind=omp_sync_hint_kind), parameter, public :: omp_sync_hint_uncontended    = 1
        integer (kind=omp_sync_hint_kind), parameter, public :: omp_sync_hint_contended      = 2
        integer (kind=omp_sync_hint_kind), parameter, public :: omp_sync_hint_nonspeculative = 4
        integer (kind=omp_sync_hint_kind), parameter, public :: omp_sync_hint_speculative    = 8
        integer (kind=omp_lock_hint_kind), parameter, public :: omp_lock_hint_none = omp_sync_hint_none
        integer (kind=omp_lock_hint_kind), parameter, public :: omp_lock_hint_uncontended = omp_sync_hint_uncontended
        integer (kind=omp_lock_hint_kind), parameter, public :: omp_lock_hint_contended = omp_sync_hint_contended
        integer (kind=omp_lock_hint_kind), parameter, public :: omp_lock_hint_nonspeculative = omp_sync_hint_nonspeculative
        integer (kind=omp_lock_hint_kind), parameter, public :: omp_lock_hint_speculative = omp_sync_hint_speculative
        integer (kind=omp_lock_hint_kind), parameter, public :: kmp_lock_hint_hle         = 65536
        integer (kind=omp_lock_hint_kind), parameter, public :: kmp_lock_hint_rtm         = 131072
        integer (kind=omp_lock_hint_kind), parameter, public :: kmp_lock_hint_adaptive    = 262144

        integer (kind=omp_control_tool_kind), parameter, public :: omp_control_tool_start = 1
        integer (kind=omp_control_tool_kind), parameter, public :: omp_control_tool_pause = 2
        integer (kind=omp_control_tool_kind), parameter, public :: omp_control_tool_flush = 3
        integer (kind=omp_control_tool_kind), parameter, public :: omp_control_tool_end = 4

        integer (kind=omp_control_tool_result_kind), parameter, public :: omp_control_tool_notool = -2
        integer (kind=omp_control_tool_result_kind), parameter, public :: omp_control_tool_nocallback = -1
        integer (kind=omp_control_tool_result_kind), parameter, public :: omp_control_tool_success = 0
        integer (kind=omp_control_tool_result_kind), parameter, public :: omp_control_tool_ignored = 1

        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_sync_hint = 1
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_alignment = 2
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_access = 3
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_pool_size = 4
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_fallback = 5
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_fb_data = 6
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_pinned = 7
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_partition = 8
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_pin_device = 9
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_preferred_device = 10
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_device_access = 11
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_target_access = 12
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_atomic_scope = 13
        integer (kind=omp_alloctrait_key_kind), parameter, public :: omp_atk_part_size = 14

        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_default = -1
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_false = 0
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_true = 1
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_contended = 3
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_uncontended = 4
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_serialized = 5
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_sequential = omp_atv_serialized
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_private = 6
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_device = 7
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_thread = 8
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_pteam = 9
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_cgroup = 10
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_default_mem_fb = 11
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_null_fb = 12
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_abort_fb = 13
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_allocator_fb = 14
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_environment = 15
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_nearest = 16
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_blocked = 17
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_interleaved = 18
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_all = 19
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_single = 20
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_multiple = 21
        integer (kind=omp_alloctrait_val_kind), parameter, public :: omp_atv_memspace = 22

        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_null_allocator = 0
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_default_mem_alloc = 1
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_large_cap_mem_alloc = 2
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_const_mem_alloc = 3
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_high_bw_mem_alloc = 4
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_low_lat_mem_alloc = 5
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_cgroup_mem_alloc = 6
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_pteam_mem_alloc = 7
        integer (kind=omp_allocator_handle_kind), parameter, public :: omp_thread_mem_alloc = 8
        integer (kind=omp_allocator_handle_kind), parameter, public :: llvm_omp_target_host_mem_alloc = 100
        integer (kind=omp_allocator_handle_kind), parameter, public :: llvm_omp_target_shared_mem_alloc = 101
        integer (kind=omp_allocator_handle_kind), parameter, public :: llvm_omp_target_device_mem_alloc = 102

        integer (kind=omp_memspace_handle_kind), parameter, public :: omp_null_mem_space = 0
        integer (kind=omp_memspace_handle_kind), parameter, public :: omp_default_mem_space = 99
        integer (kind=omp_memspace_handle_kind), parameter, public :: omp_large_cap_mem_space = 1
        integer (kind=omp_memspace_handle_kind), parameter, public :: omp_const_mem_space = 2
        integer (kind=omp_memspace_handle_kind), parameter, public :: omp_high_bw_mem_space = 3
        integer (kind=omp_memspace_handle_kind), parameter, public :: omp_low_lat_mem_space = 4
        integer (kind=omp_memspace_handle_kind), parameter, public :: llvm_omp_target_host_mem_space = 100
        integer (kind=omp_memspace_handle_kind), parameter, public :: llvm_omp_target_shared_mem_space = 101
        integer (kind=omp_memspace_handle_kind), parameter, public :: llvm_omp_target_device_mem_space = 102

        integer (kind=omp_pause_resource_kind), parameter, public :: omp_pause_resume = 0
        integer (kind=omp_pause_resource_kind), parameter, public :: omp_pause_soft = 1
        integer (kind=omp_pause_resource_kind), parameter, public :: omp_pause_hard = 2
        integer (kind=omp_pause_resource_kind), parameter, public :: omp_pause_stop_tool = 3

        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_cuda = 1
        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_cuda_driver = 2
        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_opencl = 3
        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_sycl = 4
        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_hip = 5
        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_level_zero = 6
        integer (kind=omp_interop_fr_kind), parameter, public :: omp_ifr_last = 7

        integer (kind=omp_interop_kind), parameter, public :: omp_interop_none = 0

        interface

!         ***
!         *** omp_* entry points
!         ***

          subroutine omp_set_num_threads(num_threads) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: num_threads
          end subroutine omp_set_num_threads

          subroutine omp_set_dynamic(dynamic_threads) bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind), value :: dynamic_threads
          end subroutine omp_set_dynamic

          subroutine omp_set_nested(nested) bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind), value :: nested
          end subroutine omp_set_nested

          function omp_get_num_threads() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_num_threads
          end function omp_get_num_threads

          function omp_get_max_threads() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_max_threads
          end function omp_get_max_threads

          function omp_get_thread_num() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_thread_num
          end function omp_get_thread_num

          function omp_get_num_procs() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_num_procs
          end function omp_get_num_procs

          function omp_in_parallel() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_in_parallel
          end function omp_in_parallel

          function omp_in_final() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_in_final
          end function omp_in_final

          function omp_get_dynamic() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_get_dynamic
          end function omp_get_dynamic

          function omp_get_nested() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_get_nested
          end function omp_get_nested

          function omp_get_thread_limit() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_thread_limit
          end function omp_get_thread_limit

          subroutine omp_set_max_active_levels(max_levels) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: max_levels
          end subroutine omp_set_max_active_levels

          function omp_get_max_active_levels() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_max_active_levels
          end function omp_get_max_active_levels

          function omp_get_level() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_level
          end function omp_get_level

          function omp_get_active_level() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_active_level
          end function omp_get_active_level

          function omp_get_ancestor_thread_num(level) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_ancestor_thread_num
            integer (kind=omp_integer_kind), value :: level
          end function omp_get_ancestor_thread_num

          function omp_get_team_size(level) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_team_size
            integer (kind=omp_integer_kind), value :: level
          end function omp_get_team_size

          subroutine omp_set_schedule(kind, chunk_size) bind(c)
            use omp_lib_kinds
            integer (kind=omp_sched_kind), value :: kind
            integer (kind=omp_integer_kind), value :: chunk_size
          end subroutine omp_set_schedule

          subroutine omp_get_schedule(kind, chunk_size) bind(c)
            use omp_lib_kinds
            integer (kind=omp_sched_kind) kind
            integer (kind=omp_integer_kind) chunk_size
          end subroutine omp_get_schedule

          function omp_get_proc_bind() bind(c)
            use omp_lib_kinds
            integer (kind=omp_proc_bind_kind) omp_get_proc_bind
          end function omp_get_proc_bind

          function omp_get_num_places() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_num_places
          end function omp_get_num_places

          function omp_get_place_num_procs(place_num) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: place_num
            integer (kind=omp_integer_kind) omp_get_place_num_procs
          end function omp_get_place_num_procs

          subroutine omp_get_place_proc_ids(place_num, ids) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: place_num
            integer (kind=omp_integer_kind) ids(*)
          end subroutine omp_get_place_proc_ids

          function omp_get_place_num() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_place_num
          end function omp_get_place_num

          function omp_get_partition_num_places() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_partition_num_places
          end function omp_get_partition_num_places

          subroutine omp_get_partition_place_nums(place_nums) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) place_nums(*)
          end subroutine omp_get_partition_place_nums

          function omp_get_wtime() bind(c)
            use omp_lib_kinds
            real (kind=kmp_double_kind) omp_get_wtime
          end function omp_get_wtime

          function omp_get_wtick() bind(c)
            use omp_lib_kinds
            real (kind=kmp_double_kind) omp_get_wtick
          end function omp_get_wtick

          function omp_get_default_device() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_default_device
          end function omp_get_default_device

          subroutine omp_set_default_device(device_num) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: device_num
          end subroutine omp_set_default_device

          function omp_get_num_devices() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_num_devices
          end function omp_get_num_devices

          function omp_get_num_teams() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_num_teams
          end function omp_get_num_teams

          function omp_get_team_num() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_team_num
          end function omp_get_team_num

          function omp_get_cancellation() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_get_cancellation
          end function omp_get_cancellation

          function omp_is_initial_device() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_is_initial_device
          end function omp_is_initial_device

          function omp_get_initial_device() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_initial_device
          end function omp_get_initial_device

          function omp_get_device_num() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_device_num
          end function omp_get_device_num

          function omp_pause_resource(kind, device_num) bind(c)
            use omp_lib_kinds
            integer (kind=omp_pause_resource_kind), value :: kind
            integer (kind=omp_integer_kind), value :: device_num
            integer (kind=omp_integer_kind) omp_pause_resource
          end function omp_pause_resource

          function omp_pause_resource_all(kind) bind(c)
            use omp_lib_kinds
            integer (kind=omp_pause_resource_kind), value :: kind
            integer (kind=omp_integer_kind) omp_pause_resource_all
          end function omp_pause_resource_all

          function omp_get_supported_active_levels() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_supported_active_levels
          end function omp_get_supported_active_levels

          subroutine omp_fulfill_event(event) bind(c)
            use omp_lib_kinds
            integer (kind=omp_event_handle_kind), value :: event
          end subroutine omp_fulfill_event

          subroutine omp_init_lock(svar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_init_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_lock_kind) svar
          end subroutine omp_init_lock

          subroutine omp_destroy_lock(svar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_destroy_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_lock_kind) svar
          end subroutine omp_destroy_lock

          subroutine omp_set_lock(svar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_set_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_lock_kind) svar
          end subroutine omp_set_lock

          subroutine omp_unset_lock(svar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_unset_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_lock_kind) svar
          end subroutine omp_unset_lock

          function omp_test_lock(svar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_test_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_test_lock
            integer (kind=omp_lock_kind) svar
          end function omp_test_lock

          subroutine omp_init_nest_lock(nvar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_init_nest_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_nest_lock_kind) nvar
          end subroutine omp_init_nest_lock

          subroutine omp_destroy_nest_lock(nvar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_destroy_nest_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_nest_lock_kind) nvar
          end subroutine omp_destroy_nest_lock

          subroutine omp_set_nest_lock(nvar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_set_nest_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_nest_lock_kind) nvar
          end subroutine omp_set_nest_lock

          subroutine omp_unset_nest_lock(nvar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_unset_nest_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_nest_lock_kind) nvar
          end subroutine omp_unset_nest_lock

          function omp_test_nest_lock(nvar) bind(c)
#ifdef __INTEL_COMPILER
!DIR$ IF(__INTEL_COMPILER.GE.1400)
!DIR$ attributes known_intrinsic :: omp_test_nest_lock
!DIR$ ENDIF
#endif
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_test_nest_lock
            integer (kind=omp_nest_lock_kind) nvar
          end function omp_test_nest_lock

          function omp_get_max_task_priority() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_max_task_priority
          end function omp_get_max_task_priority

          subroutine omp_init_lock_with_hint(svar, hint) bind(c)
            use omp_lib_kinds
            integer (kind=omp_lock_kind) svar
            integer (kind=omp_lock_hint_kind), value :: hint
          end subroutine omp_init_lock_with_hint

          subroutine omp_init_nest_lock_with_hint(nvar, hint) bind(c)
            use omp_lib_kinds
            integer (kind=omp_nest_lock_kind) nvar
            integer (kind=omp_lock_hint_kind), value :: hint
          end subroutine omp_init_nest_lock_with_hint

          function omp_control_tool(command, modifier, arg) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_control_tool
            integer (kind=omp_control_tool_kind), value :: command
            integer (kind=omp_control_tool_kind), value :: modifier
            integer (kind=kmp_pointer_kind), optional :: arg
          end function omp_control_tool

          function omp_init_allocator(memspace, ntraits, traits)
            use omp_lib_kinds
            integer (kind=omp_allocator_handle_kind) omp_init_allocator
            integer (kind=omp_memspace_handle_kind) :: memspace
            integer (kind=omp_integer_kind) :: ntraits
            type(omp_alloctrait), intent(in) :: traits(*)
          end function omp_init_allocator

          subroutine omp_destroy_allocator(allocator) bind(c)
            use omp_lib_kinds
            integer (kind=omp_allocator_handle_kind), value :: allocator
          end subroutine omp_destroy_allocator

          subroutine omp_set_default_allocator(allocator) bind(c)
            use omp_lib_kinds
            integer (kind=omp_allocator_handle_kind), value :: allocator
          end subroutine omp_set_default_allocator

          function omp_get_default_allocator() bind(c)
            use omp_lib_kinds
            integer (kind=omp_allocator_handle_kind) omp_get_default_allocator
          end function omp_get_default_allocator

          subroutine omp_set_affinity_format(format)
            character (len=*) :: format
          end subroutine omp_set_affinity_format

          function omp_get_affinity_format(buffer)
            use omp_lib_kinds
            character (len=*) :: buffer
            integer (kind=kmp_size_t_kind) :: omp_get_affinity_format
          end function omp_get_affinity_format

          subroutine omp_display_affinity(format)
            character (len=*) :: format
          end subroutine omp_display_affinity

          function omp_capture_affinity(buffer, format)
            use omp_lib_kinds
            character (len=*) :: format
            character (len=*) :: buffer
            integer (kind=kmp_size_t_kind) :: omp_capture_affinity
          end function omp_capture_affinity

          subroutine omp_set_num_teams(num_teams) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: num_teams
          end subroutine omp_set_num_teams

          function omp_get_max_teams() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_max_teams
          end function omp_get_max_teams

          subroutine omp_set_teams_thread_limit(thread_limit) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: thread_limit
          end subroutine omp_set_teams_thread_limit

          function omp_get_teams_thread_limit() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) omp_get_teams_thread_limit
          end function omp_get_teams_thread_limit

          subroutine omp_display_env(verbose) bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind), value :: verbose
          end subroutine omp_display_env

          function omp_target_alloc(size, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_size_t, c_int
            type(c_ptr) omp_target_alloc
            integer(c_size_t), value :: size
            integer(c_int), value :: device_num
          end function omp_target_alloc

          subroutine omp_target_free(device_ptr, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_int
            type(c_ptr), value :: device_ptr
            integer(c_int), value :: device_num
          end subroutine omp_target_free

          function omp_target_is_present(ptr, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_int
            integer(c_int) omp_target_is_present
            type(c_ptr), value :: ptr
            integer(c_int), value :: device_num
          end function omp_target_is_present

          function omp_target_memcpy(dst, src, length, dst_offset, src_offset, &
              dst_device_num, src_device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_size_t, c_int
            integer(c_int) omp_target_memcpy
            type(c_ptr), value :: dst, src
            integer(c_size_t), value :: length, dst_offset, src_offset
            integer(c_int), value :: dst_device_num, src_device_num
          end function omp_target_memcpy

          function omp_target_memcpy_rect(dst, src, element_size, num_dims,    &
              volume, dst_offsets, src_offsets, dst_dimensions,                &
              src_dimensions, dst_device_num, src_device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_size_t, c_int
            integer(c_int) omp_target_memcpy_rect
            type(c_ptr), value :: dst, src
            integer(c_size_t), value :: element_size
            integer(c_int), value :: num_dims, dst_device_num, src_device_num
            integer(c_size_t), intent(in) :: volume(*), dst_offsets(*),        &
                src_offsets(*), dst_dimensions(*), src_dimensions(*)
          end function omp_target_memcpy_rect

          function omp_target_memcpy_async(dst, src, length, dst_offset,       &
              src_offset, dst_device_num, src_device_num, depobj_count,        &
              depobj_list) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only: c_ptr, c_size_t, c_int
            integer(c_int) omp_target_memcpy_async
            type(c_ptr), value :: dst, src
            integer(c_size_t), value :: length, dst_offset, src_offset
            integer(c_int), value :: dst_device_num, src_device_num,           &
                depobj_count
            integer(omp_depend_kind), optional :: depobj_list(*)
          end function omp_target_memcpy_async

          function omp_target_memcpy_rect_async(dst, src, element_size,        &
              num_dims, volume, dst_offsets, src_offsets, dst_dimensions,      &
              src_dimensions, dst_device_num, src_device_num, depobj_count,    &
              depobj_list) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only: c_ptr, c_size_t, c_int
            integer(c_int) omp_target_memcpy_rect_async
            type(c_ptr), value :: dst, src
            integer(c_size_t), value :: element_size
            integer(c_int), value :: num_dims, dst_device_num, src_device_num, &
                depobj_count
            integer(c_size_t), intent(in) :: volume(*), dst_offsets(*),        &
                src_offsets(*), dst_dimensions(*), src_dimensions(*)
            integer (omp_depend_kind), optional :: depobj_list(*)
          end function omp_target_memcpy_rect_async

          function omp_target_memset(ptr, val, count, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only : c_ptr, c_int, c_size_t
            type(c_ptr) :: omp_target_memset
            type(c_ptr), value :: ptr
            integer(c_int), value :: val
            integer(c_size_t), value :: count
            integer(c_int), value :: device_num
          end function

          function omp_target_memset_async(ptr, val, count, device_num, &
                                           depobj_count, depobj_list) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr, c_int, c_size_t
            type(c_ptr) :: omp_target_memset_async
            type(c_ptr), value :: ptr
            integer(c_int), value :: val
            integer(c_size_t), value :: count
            integer(c_int), value :: device_num
            integer(c_int), value :: depobj_count
            integer(omp_depend_kind), optional :: depobj_list(*)
          end function

          function omp_target_associate_ptr(host_ptr, device_ptr, size,        &
              device_offset, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_size_t, c_int
            integer(c_int) omp_target_associate_ptr
            type(c_ptr), value :: host_ptr, device_ptr
            integer(c_size_t), value :: size, device_offset
            integer(c_int), value :: device_num
          end function omp_target_associate_ptr

          function omp_get_mapped_ptr(ptr, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_int
            type(c_ptr) omp_get_mapped_ptr
            type(c_ptr), value :: ptr
            integer(c_int), value :: device_num
          end function omp_get_mapped_ptr

          function omp_target_disassociate_ptr(ptr, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only: c_ptr, c_int
            integer(c_int) omp_target_disassociate_ptr
            type(c_ptr), value :: ptr
            integer(c_int), value :: device_num
          end function omp_target_disassociate_ptr

          function omp_target_is_accessible(ptr, size, device_num) bind(c)
            use, intrinsic :: iso_c_binding, only : c_ptr, c_size_t, c_int
            integer(c_int) omp_target_is_accessible
            type(c_ptr), value :: ptr
            integer(c_size_t), value :: size
            integer(c_int), value :: device_num
          end function omp_target_is_accessible

          function omp_alloc(size, allocator) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr, c_size_t
            type(c_ptr) omp_alloc
            integer(c_size_t), value :: size
            integer(omp_allocator_handle_kind), value :: allocator
          end function omp_alloc

          function omp_aligned_alloc(alignment, size, allocator) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr, c_size_t
            type(c_ptr) omp_aligned_alloc
            integer(c_size_t), value :: alignment, size
            integer(omp_allocator_handle_kind), value :: allocator
          end function omp_aligned_alloc

          function omp_calloc(nmemb, size, allocator) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr, c_size_t
            type(c_ptr) omp_calloc
            integer(c_size_t), value :: nmemb, size
            integer(omp_allocator_handle_kind), value :: allocator
          end function omp_calloc

          function omp_aligned_calloc(alignment, nmemb, size, allocator) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr, c_size_t
            type(c_ptr) omp_aligned_calloc
            integer(c_size_t), value :: alignment, nmemb, size
            integer(omp_allocator_handle_kind), value :: allocator
          end function omp_aligned_calloc

          function omp_realloc(ptr, size, allocator, free_allocator) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr, c_size_t
            type(c_ptr) omp_realloc
            type(c_ptr), value :: ptr
            integer(c_size_t), value :: size
            integer(omp_allocator_handle_kind), value :: allocator
            integer(omp_allocator_handle_kind), value :: free_allocator
          end function omp_realloc

          subroutine omp_free(ptr, allocator) bind(c)
            use omp_lib_kinds
            use, intrinsic :: iso_c_binding, only : c_ptr
            type(c_ptr), value :: ptr
            integer(omp_allocator_handle_kind), value :: allocator
          end subroutine omp_free

          function omp_in_explicit_task() bind(c)
            use omp_lib_kinds
            logical (kind=omp_logical_kind) omp_in_explicit_task
          end function omp_in_explicit_task

          function omp_get_devices_memspace(ndevs, devs, memspace)
            use omp_lib_kinds
            integer(omp_memspace_handle_kind) :: omp_get_devices_memspace
            integer, intent(in) :: ndevs
            integer, intent(in) :: devs(*)
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_devices_memspace

          function omp_get_device_memspace(dev, memspace)
            use omp_lib_kinds
            integer(omp_memspace_handle_kind) :: omp_get_device_memspace
            integer, intent(in) :: dev
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_device_memspace

          function omp_get_devices_and_host_memspace(ndevs, devs, memspace)
            use omp_lib_kinds
            integer(omp_memspace_handle_kind) ::                               &
                omp_get_devices_and_host_memspace
            integer, intent(in) :: ndevs
            integer, intent(in) :: devs(*)
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_devices_and_host_memspace

          function omp_get_device_and_host_memspace(dev, memspace)
            use omp_lib_kinds
            integer(omp_memspace_handle_kind) ::                               &
                omp_get_device_and_host_memspace
            integer, intent(in) :: dev
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_device_and_host_memspace

          function omp_get_devices_all_memspace(memspace)
            use omp_lib_kinds
            integer(omp_memspace_handle_kind) :: omp_get_devices_all_memspace
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_devices_all_memspace

          function omp_get_devices_allocator(ndevs, devs, memspace)
            use omp_lib_kinds
            integer(omp_allocator_handle_kind) :: omp_get_devices_allocator
            integer, intent(in) :: ndevs
            integer, intent(in) :: devs(*)
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_devices_allocator

          function omp_get_device_allocator(dev, memspace)
            use omp_lib_kinds
            integer(omp_allocator_handle_kind) :: omp_get_device_allocator
            integer, intent(in) :: dev
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_device_allocator

          function omp_get_devices_and_host_allocator(ndevs, devs, memspace)
            use omp_lib_kinds
            integer(omp_allocator_handle_kind) ::                              &
                omp_get_devices_and_host_allocator
            integer, intent(in) :: ndevs
            integer, intent(in) :: devs(*)
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_devices_and_host_allocator

          function omp_get_device_and_host_allocator(dev, memspace)
            use omp_lib_kinds
            integer(omp_allocator_handle_kind) ::                              &
                omp_get_device_and_host_allocator
            integer, intent(in) :: dev
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_device_and_host_allocator

          function omp_get_devices_all_allocator(memspace)
            use omp_lib_kinds
            integer(omp_allocator_handle_kind) ::                              &
                omp_get_devices_all_allocator
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_devices_all_allocator

          function omp_get_memspace_num_resources(memspace)
            use omp_lib_kinds
            integer omp_get_memspace_num_resources
            integer(omp_memspace_handle_kind), intent(in) :: memspace
          end function omp_get_memspace_num_resources

          function omp_get_submemspace(memspace, num_resources, resources)
            use omp_lib_kinds
            integer(omp_memspace_handle_kind) omp_get_submemspace
            integer(omp_memspace_handle_kind), intent(in) :: memspace
            integer, intent(in) :: num_resources
            integer, intent(in) :: resources(*)
          end function omp_get_submemspace

!         ***
!         *** kmp_* entry points
!         ***

          subroutine kmp_set_stacksize(size) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: size
          end subroutine kmp_set_stacksize

          subroutine kmp_set_stacksize_s(size) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_size_t_kind), value :: size
          end subroutine kmp_set_stacksize_s

          subroutine kmp_set_blocktime(msec) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: msec
          end subroutine kmp_set_blocktime

          subroutine kmp_set_library_serial() bind(c)
          end subroutine kmp_set_library_serial

          subroutine kmp_set_library_turnaround() bind(c)
          end subroutine kmp_set_library_turnaround

          subroutine kmp_set_library_throughput() bind(c)
          end subroutine kmp_set_library_throughput

          subroutine kmp_set_library(libnum) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: libnum
          end subroutine kmp_set_library

          subroutine kmp_set_defaults(string)
            character (len=*) :: string
          end subroutine kmp_set_defaults

          function kmp_get_stacksize() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_get_stacksize
          end function kmp_get_stacksize

          function kmp_get_stacksize_s() bind(c)
            use omp_lib_kinds
            integer (kind=kmp_size_t_kind) kmp_get_stacksize_s
          end function kmp_get_stacksize_s

          function kmp_get_blocktime() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_get_blocktime
          end function kmp_get_blocktime

          function kmp_get_library() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_get_library
          end function kmp_get_library

          subroutine kmp_set_disp_num_buffers(num) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind), value :: num
          end subroutine kmp_set_disp_num_buffers

          function kmp_set_affinity(mask) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_set_affinity
            integer (kind=kmp_affinity_mask_kind) mask
          end function kmp_set_affinity

          function kmp_get_affinity(mask) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_get_affinity
            integer (kind=kmp_affinity_mask_kind) mask
          end function kmp_get_affinity

          function kmp_get_affinity_max_proc() bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_get_affinity_max_proc
          end function kmp_get_affinity_max_proc

          subroutine kmp_create_affinity_mask(mask) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_affinity_mask_kind) mask
          end subroutine kmp_create_affinity_mask

          subroutine kmp_destroy_affinity_mask(mask) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_affinity_mask_kind) mask
          end subroutine kmp_destroy_affinity_mask

          function kmp_set_affinity_mask_proc(proc, mask) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_set_affinity_mask_proc
            integer (kind=omp_integer_kind), value :: proc
            integer (kind=kmp_affinity_mask_kind) mask
          end function kmp_set_affinity_mask_proc

          function kmp_unset_affinity_mask_proc(proc, mask) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_unset_affinity_mask_proc
            integer (kind=omp_integer_kind), value :: proc
            integer (kind=kmp_affinity_mask_kind) mask
          end function kmp_unset_affinity_mask_proc

          function kmp_get_affinity_mask_proc(proc, mask) bind(c)
            use omp_lib_kinds
            integer (kind=omp_integer_kind) kmp_get_affinity_mask_proc
            integer (kind=omp_integer_kind), value :: proc
            integer (kind=kmp_affinity_mask_kind) mask
          end function kmp_get_affinity_mask_proc

          function kmp_malloc(size) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_pointer_kind) kmp_malloc
            integer (kind=kmp_size_t_kind), value :: size
          end function kmp_malloc

          function kmp_aligned_malloc(size, alignment) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_pointer_kind) kmp_aligned_malloc
            integer (kind=kmp_size_t_kind), value :: size
            integer (kind=kmp_size_t_kind), value :: alignment
          end function kmp_aligned_malloc

          function kmp_calloc(nelem, elsize) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_pointer_kind) kmp_calloc
            integer (kind=kmp_size_t_kind), value :: nelem
            integer (kind=kmp_size_t_kind), value :: elsize
          end function kmp_calloc

          function kmp_realloc(ptr, size) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_pointer_kind) kmp_realloc
            integer (kind=kmp_pointer_kind), value :: ptr
            integer (kind=kmp_size_t_kind), value :: size
          end function kmp_realloc

          subroutine kmp_free(ptr) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_pointer_kind), value :: ptr
          end subroutine kmp_free

          subroutine kmp_set_warnings_on() bind(c)
          end subroutine kmp_set_warnings_on

          subroutine kmp_set_warnings_off() bind(c)
          end subroutine kmp_set_warnings_off

          function kmp_get_cancellation_status(cancelkind) bind(c)
            use omp_lib_kinds
            integer (kind=kmp_cancel_kind), value :: cancelkind
            logical (kind=omp_logical_kind) kmp_get_cancellation_status
          end function kmp_get_cancellation_status

        end interface

        ! make the above routine definitions public
        public :: omp_set_num_threads
        public :: omp_set_dynamic
        public :: omp_set_nested
        public :: omp_get_num_threads
        public :: omp_get_max_threads
        public :: omp_get_thread_num
        public :: omp_get_num_procs
        public :: omp_in_parallel
        public :: omp_in_final
        public :: omp_get_dynamic
        public :: omp_get_nested
        public :: omp_get_thread_limit
        public :: omp_set_max_active_levels
        public :: omp_get_max_active_levels
        public :: omp_get_level
        public :: omp_get_active_level
        public :: omp_get_ancestor_thread_num
        public :: omp_get_team_size
        public :: omp_set_schedule
        public :: omp_get_schedule
        public :: omp_get_proc_bind
        public :: omp_get_num_places
        public :: omp_get_place_num_procs
        public :: omp_get_place_proc_ids
        public :: omp_get_place_num
        public :: omp_get_partition_num_places
        public :: omp_get_partition_place_nums
        public :: omp_get_wtime
        public :: omp_get_wtick
        public :: omp_get_default_device
        public :: omp_set_default_device
        public :: omp_get_num_devices
        public :: omp_get_num_teams
        public :: omp_get_team_num
        public :: omp_get_cancellation
        public :: omp_is_initial_device
        public :: omp_get_initial_device
        public :: omp_get_device_num
        public :: omp_pause_resource
        public :: omp_pause_resource_all
        public :: omp_get_supported_active_levels
        public :: omp_fulfill_event
        public :: omp_init_lock
        public :: omp_destroy_lock
        public :: omp_set_lock
        public :: omp_unset_lock
        public :: omp_test_lock
        public :: omp_init_nest_lock
        public :: omp_destroy_nest_lock
        public :: omp_set_nest_lock
        public :: omp_unset_nest_lock
        public :: omp_test_nest_lock
        public :: omp_get_max_task_priority
        public :: omp_init_lock_with_hint
        public :: omp_init_nest_lock_with_hint
        public :: omp_control_tool
        public :: omp_init_allocator
        public :: omp_destroy_allocator
        public :: omp_set_default_allocator
        public :: omp_get_default_allocator
        public :: omp_set_affinity_format
        public :: omp_get_affinity_format
        public :: omp_display_affinity
        public :: omp_capture_affinity
        public :: omp_set_num_teams
        public :: omp_get_max_teams
        public :: omp_set_teams_thread_limit
        public :: omp_get_teams_thread_limit
        public :: omp_display_env
        public :: omp_target_alloc
        public :: omp_target_free
        public :: omp_target_is_present
        public :: omp_target_memcpy
        public :: omp_target_memcpy_rect
        public :: omp_target_memcpy_async
        public :: omp_target_memcpy_rect_async
        public :: omp_target_memset
        public :: omp_target_memset_async
        public :: omp_target_associate_ptr
        public :: omp_get_mapped_ptr
        public :: omp_target_disassociate_ptr
        public :: omp_target_is_accessible
        public :: omp_alloc
        public :: omp_aligned_alloc
        public :: omp_calloc
        public :: omp_aligned_calloc
        public :: omp_realloc
        public :: omp_free
        public :: omp_in_explicit_task
        public :: kmp_set_stacksize
        public :: kmp_set_stacksize_s
        public :: kmp_set_blocktime
        public :: kmp_set_library_serial
        public :: kmp_set_library_turnaround
        public :: kmp_set_library_throughput
        public :: kmp_set_library
        public :: kmp_set_defaults
        public :: kmp_get_stacksize
        public :: kmp_get_stacksize_s
        public :: kmp_get_blocktime
        public :: kmp_get_library
        public :: kmp_set_disp_num_buffers
        public :: kmp_set_affinity
        public :: kmp_get_affinity
        public :: kmp_get_affinity_max_proc
        public :: kmp_create_affinity_mask
        public :: kmp_destroy_affinity_mask
        public :: kmp_set_affinity_mask_proc
        public :: kmp_unset_affinity_mask_proc
        public :: kmp_get_affinity_mask_proc
        public :: kmp_malloc
        public :: kmp_aligned_malloc
        public :: kmp_calloc
        public :: kmp_realloc
        public :: kmp_free
        public :: kmp_set_warnings_on
        public :: kmp_set_warnings_off
        public :: kmp_get_cancellation_status

      end module omp_lib
