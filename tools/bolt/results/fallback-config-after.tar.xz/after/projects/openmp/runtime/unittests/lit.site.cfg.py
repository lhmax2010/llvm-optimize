

config.openmp_unittests_dir = "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/projects/openmp/runtime/unittests/../unittests"
config.llvm_build_mode = lit_config.substitute(".")

# Let the main config do the real work.
lit_config.load_config(config, "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/openmp/runtime/unittests/../test/Unit/lit.cfg.py")

