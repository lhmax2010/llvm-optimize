# Install script for directory: /home/abuild/rpmbuild/BUILD/llvm-22.1.8/compiler-rt/lib/asan

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/bin/llvm-objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang_rt.asan-x86_64" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE STATIC_LIBRARY FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.a")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang_rt.asan_cxx-x86_64" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE STATIC_LIBRARY FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan_cxx-x86_64.a")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang_rt.asan_static-x86_64" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE STATIC_LIBRARY FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan_static-x86_64.a")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang_rt.asan-preinit-x86_64" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE STATIC_LIBRARY FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan-preinit-x86_64.a")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang_rt.asan-dynamic-x86_64" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE SHARED_LIBRARY FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/bin/llvm-strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "clang_rt.asan-dynamic-x86_64" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE FILE FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan_cxx-x86_64.a.syms")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/lib/linux" TYPE FILE FILES "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/clang/22/lib/linux/libclang_rt.asan-x86_64.a.syms")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "asan" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin/../lib64/clang/22/share" TYPE FILE FILES "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/compiler-rt/lib/asan/asan_ignorelist.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/projects/compiler-rt/lib/asan/scripts/cmake_install.cmake")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/projects/compiler-rt/lib/asan/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
