int __tf_xla_runtime_anchor(void){return 0;}
