# This file allows users to call find_package(LLD) and pick up our targets.



set(LLVM_VERSION 22.1.8)
find_package(LLVM ${LLVM_VERSION} EXACT REQUIRED CONFIG
             HINTS "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/./lib64/cmake/llvm")

set(LLD_EXPORTED_TARGETS "lldCommon;lld;lldCOFF;lldELF;lldMachO;lldMinGW;lldWasm")
set(LLD_CMAKE_DIR "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/cmake/lld")
set(LLD_INCLUDE_DIRS "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/lld/include;/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/lld/include")

# Provide all our library targets to users.
include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/lib64/cmake/lld/LLDTargets.cmake")
