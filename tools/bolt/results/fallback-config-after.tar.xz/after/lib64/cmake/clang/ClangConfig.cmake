# This file allows users to call find_package(Clang) and pick up our targets.



set(LLVM_VERSION 22.1.8)
find_package(LLVM ${LLVM_VERSION} EXACT REQUIRED CONFIG
             HINTS "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/./lib64/cmake/llvm")

set(CLANG_EXPORTED_TARGETS "clang-tblgen;clang-resource-headers;clangBasic;clangAPINotes;clangLex;clangParse;clangAST;clangDynamicASTMatchers;clangASTMatchers;clangCrossTU;clangSema;clangCodeGen;clangAnalysis;clangAnalysisFlowSensitive;clangAnalysisFlowSensitiveModels;clangAnalysisLifetimeSafety;clangAnalysisScalable;clangEdit;clangExtractAPI;clangRewrite;clangDriver;clangOptions;clangSerialization;clangRewriteFrontend;clangFrontend;clangFrontendTool;clangToolingCore;clangToolingInclusions;clangToolingInclusionsStdlib;clangToolingRefactoring;clangToolingASTDiff;clangToolingSyntax;clangTransformer;clangTooling;clangDependencyScanning;clangDirectoryWatcher;clangIndex;clangIndexSerialization;clangInstallAPI;clangStaticAnalyzerCore;clangStaticAnalyzerCheckers;clangStaticAnalyzerFrontend;clangFormat;clangInterpreter;clangSupport;diagtool;clang;clang-format;clangHandleCXX;clangHandleLLVM;clang-linker-wrapper;clang-nvlink-wrapper;clang-offload-bundler;clang-scan-deps;clang-sycl-linker;clang-installapi;clang-repl;clang-refactor;clang-cpp;clang-check;clang-extdef-mapping;clangApplyReplacements;clang-apply-replacements;clangReorderFields;clang-reorder-fields;modularize;clangTidy;clangTidyAndroidModule;clangTidyAbseilModule;clangTidyAlteraModule;clangTidyBoostModule;clangTidyBugproneModule;clangTidyCERTModule;clangTidyConcurrencyModule;clangTidyCppCoreGuidelinesModule;clangTidyCustomModule;clangTidyDarwinModule;clangTidyFuchsiaModule;clangTidyGoogleModule;clangTidyHICPPModule;clangTidyLinuxKernelModule;clangTidyLLVMModule;clangTidyLLVMLibcModule;clangTidyMiscModule;clangTidyModernizeModule;clangTidyMPIModule;clangTidyObjCModule;clangTidyOpenMPModule;clangTidyPerformanceModule;clangTidyPortabilityModule;clangTidyReadabilityModule;clangTidyZirconModule;clangTidyPlugin;clangTidyMain;clang-tidy;clangTidyUtils;clangChangeNamespace;clang-change-namespace;clangDocSupport;clangDoc;clang-doc;clangIncludeFixer;clangIncludeFixerPlugin;clang-include-fixer;findAllSymbols;find-all-symbols;clangMove;clang-move;clangQuery;clang-query;clangIncludeCleaner;clang-include-cleaner;pp-trace;clangdSupport;clangDaemon;clangDaemonTweaks;clangdMain;clangd;clangdRemoteIndex;libclang;offload-arch")
set(CLANG_CMAKE_DIR "/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/./lib64/cmake/clang")
set(CLANG_INCLUDE_DIRS "/home/abuild/rpmbuild/BUILD/llvm-22.1.8/clang/include;/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/tools/clang/include")
set(CLANG_LINK_CLANG_DYLIB "OFF")
set(CLANG_DEFAULT_LINKER "")

# Provide all our library targets to users.
include("/home/abuild/bolt-work/bolt-v4-20261014-fallback/config-install-temp/./lib64/cmake/clang/ClangTargets.cmake")

# By creating clang-tablegen-targets here, subprojects that depend on Clang's
# tablegen-generated headers can always depend on this target whether building
# in-tree with Clang or not.
if(NOT TARGET clang-tablegen-targets)
  add_custom_target(clang-tablegen-targets)
endif()
