from pathlib import Path
import json,re,hashlib,collections,lzma,shutil
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt')
ROOT=Path('/var/tmp/llvm-optimize-x86-archivefix-20261013/local/BUILD-ROOTS/scratch.x86_64.0/home/abuild/rpmbuild/BUILD/llvm-22.1.8')
closure=json.loads((E/'closure-v2.json').read_text());descs=json.loads((E/'descriptions-v2.json').read_text())
raw=(B/'tools/bolt/results/review2-historical-dry-run.txt').read_text();rows=[];approved=[]
tf={'Building C object lib64/tf_runtime/CMakeFiles/tf_xla_runtime.dir/tf_xla_runtime_dummy.c.o','Linking C static library lib64/libtf_xla_runtime.a'}
for line in raw.splitlines():
    m=re.search(r'\[(\d+)/(\d+)\] (.+)$',line)
    if not m:continue
    i,total,description=int(m[1]),int(m[2]),m[3]
    if description in descs:category='BOLT';reason='current independently derived 111-task closure';approved.append(description)
    elif description in tf:category='TF';reason='paired configure-refreshed anchor';approved.append(description)
    elif re.fullmatch(r"(?:Creating directories for|No (?:download|update|patch|install) step for|Performing (?:configure|build) step for|Completed) 'bolt_rt'",description):category='disabled-runtime';reason='BOLT_ENABLE_RUNTIME=OFF'
    elif description in ['Building CXX object tools/bolt/tools/merge-fdata/CMakeFiles/merge-fdata.dir/merge-fdata.cpp.o','Linking CXX executable bin/merge-fdata']:category='disabled-merge-fdata';reason='historical explicitly requested merge-fdata; current target only llvm-bolt, BOLT_BUILD_TOOLS=OFF'
    elif description in ['Building CXX object tools/bolt/lib/Target/AArch64/CMakeFiles/LLVMBOLTTargetAArch64.dir/AArch64MCPlusBuilder.cpp.o','Building CXX object tools/bolt/lib/Target/AArch64/CMakeFiles/LLVMBOLTTargetAArch64.dir/AArch64MCSymbolizer.cpp.o','Linking CXX static library lib64/libLLVMBOLTTargetAArch64.a']:category='disabled-AArch64';reason='BOLT_TARGETS_TO_BUILD=X86'
    else:category='UNATTRIBUTED';reason='STOP'
    rows.append({'f':i,'t':total,'description':description,'category':category,'reason':reason,'raw':line})
counts=dict(collections.Counter(row['category'] for row in rows))
result={'status':'PASS' if len(rows)==126 and counts.get('UNATTRIBUTED',0)==0 else 'FAIL','counts':counts,'unattributed':counts.get('UNATTRIBUTED',0),'rows':rows,'filtered_task_count':len(approved)}
(E/'history-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['status']=='PASS','unattributed historical task; STOP'
fixture=''.join('[%d/%d] %s\n'%(i+1,len(approved),d) for i,d in enumerate(approved));(E/'history-current-plan.txt').write_text(fixture)
producers={}
for n in ['llvm/cmake/modules/TensorFlowCompile.cmake','llvm/lib/Analysis/CMakeLists.txt','llvm/lib/CodeGen/CMakeLists.txt','mlgo_verify_assets/mlgo_sysroot/xla_aot_runtime_src/CMakeLists.txt']:
    p=ROOT/n;producers[n]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'lines':p.read_text().splitlines()}
external=closure['build_directory_external_inputs'];assert external==['.','lib/Analysis/InlinerSizeModel.o','lib/CodeGen/RegAllocEvictModel.o','lib64/tf_runtime/tf_xla_runtime_dummy.c'],external
audit=[]
for name in external:
    if name=='.':
        audit.append({'path':name,'kind':'directory','producer':'CMake binary directory; phony order-only anchor, not a file','rewritten_on_reconfigure':False,'historical_downstream_tasks':[]});continue
    is_tf='tf_xla_runtime_dummy' in name
    model=Path(name).stem;source=ROOT/'mlgo_verify_assets'/(model+'.o')
    item={'path':name,'kind':'file','producer':'mlgo_verify_assets/mlgo_sysroot/xla_aot_runtime_src/CMakeLists.txt:6-7 file(WRITE)' if is_tf else 'llvm/cmake/modules/TensorFlowCompile.cmake:73-91 tf_find_and_compile override branch configure_file(COPYONLY)','rewritten_on_reconfigure':is_tf,'reason':'file(WRITE) refreshes anchor each configure' if is_tf else 'configure_file COPYONLY preserves destination when override content is unchanged; spec passes same model override files','historical_downstream_tasks':[r['description'] for r in rows if r['description'] in tf] if is_tf else [r['description'] for r in rows if ('libLLVMAnalysis.a' if model=='InlinerSizeModel' else 'libLLVMCodeGen.a') in r['description']]}
    if not is_tf:
        target=ROOT/'build'/name
        item.update(override_source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),existing_binary_dir_object_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
        assert item['source_sha256']==item['existing_binary_dir_object_sha256'],'model object differs from configured override; STOP'
    audit.append(item)
result2={'status':'PASS','build_directory_external_inputs':audit,'only_refreshed_file':'lib64/tf_runtime/tf_xla_runtime_dummy.c','source_code':producers,'source_spec_evidence':{'path':'packaging/llvm.spec','model_override_lines':[{'line':i,'text':s} for i,s in enumerate((E.parent/'bolt-v4-20261013/v41/llvm-source/packaging/llvm.spec').read_text().splitlines(),1) if 'LLVM_OVERRIDE_MODEL_' in s]},'no_CMake_or_Ninja_executed':True}
(E/'external-input-audit.json').write_text(json.dumps(result2,indent=2)+'\n')
R=B/'tools/bolt/results'
for old,new in [('descriptions-v2.json','review-tool-descriptions-v2.json'),('history-reconciliation.json','review3-history-reconciliation.json'),('history-current-plan.txt','review3-history-current-plan.txt'),('external-input-audit.json','review3-external-input-audit.json')]:shutil.copyfile(E/old,R/new)
with lzma.open(R/'review-closure-v2.json.xz','wb') as f:f.write((E/'closure-v2.json').read_bytes())
shutil.copyfile(E/'closure_v2.py',R/'review-closure-v2.py')
table='|历史编号|分类|完整描述|依据|\n|---:|---|---|---|\n'+''.join('|%d|%s|%s|%s|\n'%(r['f'],r['category'],r['description'],r['reason']) for r in rows)
(R/'review3-history-reconciliation.md').write_text(table)
print(json.dumps({'history':counts,'filtered':len(approved),'external_audit':audit},indent=2),flush=True)
