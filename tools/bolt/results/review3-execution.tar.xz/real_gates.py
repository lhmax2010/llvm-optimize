from pathlib import Path
import sys,json,shutil,subprocess,time
from new_session import E,R1,INNER,HOST,root_command
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');S=E.parent/'bolt-v4-20261013/v41/llvm-source';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
old=E.parent/'bolt-v4-20261015-validation';ordinary='/home/abuild/rpmbuild/BUILD/llvm-22.1.8/build/bin/clang-22';candidate='/home/abuild/bolt-work/bolt-v4-20261014-fallback/clang.candidate';expected='4ec07159aeb4f9300361b95955db05bfca06ece5b748796b28e9b8965145fff9'
h.require(h.digest(R1/candidate.lstrip('/'))==expected,'candidate SHA changed')
for target in [S/'packaging/clang-bolt-helper.py',HOST/'clang-bolt-helper.py']:shutil.copyfile(B/'tools/bolt/bolt_helper.py',target)
resource='/home/abuild/rpmbuild/BUILD/llvm-22.1.8/build/lib64/clang/22'
calls=[]
def invoke(label,args):
 command='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; exec python3 '+h.quote(INNER+'/record_call.py')+' '+h.quote(label)+' '+' '.join(h.quote(x) for x in ['python3',INNER+'/clang-bolt-helper.py']+args)
 p=root_command(['/bin/sh','-c',command],True,capture_output=True,text=True,timeout=240)
 (E/(label+'.stdout')).write_text(p.stdout);(E/(label+'.stderr')).write_text(p.stderr)
 h.require(p.returncode==0,'real product gate failed '+label)
 calls.append(json.loads((HOST/'calls'/(label+'.json')).read_text()))
 return json.loads(p.stdout.split('\n',1)[1])
result={'status':'RUNNING','candidate_sha256':expected,'candidate_regenerated':False,'calls':calls,'modes':{}}
result['tiny']=invoke('real-tiny',['tiny',ordinary,candidate,INNER+'/real-tiny','--resource-dir',resource])
result['security']=invoke('real-security',['security',ordinary,candidate])
for mode,tag in [('debug','d'),('release','r')]:
 root=HOST/('real-root-'+tag);shutil.copytree(old/('smoke-'+mode+'-extract'),root,symlinks=True)
 h.require(h.digest(root/'usr/bin/clang-22')==expected,'20 extracted candidate SHA differs')
 snapshot=h.root_snapshot(root);h.save(E/('real-'+mode+'-before.json'),snapshot)
 reverse=h.no_bolt_products(root)
 injected=root/'usr/bin/llvm-bolt';injected.symlink_to('clang-22')
 try:
  try:h.no_bolt_products(root)
  except h.GateError as error:
   h.require('BOLT tool in buildroot' in str(error),'wrong reverse rejection');rejection=str(error)
  else:raise h.GateError('real reverse gate accepted llvm-bolt')
 finally:injected.unlink()
 unchanged=h.compare_root(root,snapshot,E/('real-'+mode+'-after.json'))
 oldstate=R1/('home/abuild/bolt-work/bolt-v4-20261015-validation/smoke/'+tag+'/work/install-state.json')
 shutil.copyfile(oldstate,HOST/('real-'+mode+'-install-state.json'))
 post=invoke('real-post-'+mode,['post',INNER+'/real-root-'+tag,INNER+'/real-'+mode+'-install-state.json',ordinary,INNER+'/real-post-'+mode,'--resource-dir',resource])
 h.require(h.digest(root/'usr/bin/clang-22')==expected,'post changed candidate')
 result['modes'][mode]={'copied_from':str(old/('smoke-'+mode+'-extract')),'reverse':reverse,'injected_BOLT_rejected':rejection,'compare_root':unchanged,'post':post,'candidate_sha256':expected}
descriptions=json.loads((B/'tools/bolt/results/review-tool-descriptions.json').read_text())
text='\n'.join('[%d/110] %s'%(i+1,desc) for i,desc in enumerate(descriptions))+'\n';(E/'real-tool-plan.txt').write_text(text)
result['tool_plan']=h.tool_plan(text)
bad='Building CXX object lib/Support/ordinary.cpp.o';text='\n'.join('[%d/111] %s'%(i+1,desc) for i,desc in enumerate(descriptions+[bad]))+'\n';(E/'real-tool-plan-negative.txt').write_text(text)
try:h.tool_plan(text)
except h.GateError as error:
 h.require('unapproved BOLT task: '+bad in str(error),'wrong tool-plan rejection');result['tool_plan_negative']=str(error)
else:raise h.GateError('ordinary tool task was accepted')
result['status']='PASS';h.save(E/'real-gates.json',result);print(json.dumps(result,indent=2),flush=True)
