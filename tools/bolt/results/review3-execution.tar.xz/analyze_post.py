from pathlib import Path
import sys,json,re,hashlib,difflib
E=Path(__file__).resolve().parent;sys.path.insert(0,str(E));from new_session import *
sys.path.insert(0,'/home/linhao/Toolchain/development/llvm-optimize-bolt/tools/bolt');import bolt_helper as h
result=json.loads((E/'post-capture-result-first.json').read_text());result.pop('error',None);result['status']='RUNNING';result['preparation_correction']={'count': 1, 'class': 'post-chain boundary locator', 'error': 'old marker is in %post -n lldb, not install script', 'correction': 'start at first platform command line, preserving its indentation and all following bytes; no whitespace normalization and no recapture'}
scripts={(mode,tag):(E/('post-'+mode+'-'+tag+'.sh')).read_text() for mode in ['debug','release'] for tag in ['baseline','candidate']}
try:
 for mode in ['debug','release']:
  def chain(text):
   command='/usr/lib/rpm/find-debuginfo.sh' if mode=='debug' else '/usr/lib/rpm/check-buildroot'
   matches=list(re.finditer(r'^    '+re.escape(command)+r'(?: |$)',text,re.M))
   h.require(len(matches)==1,'cannot uniquely locate first platform post command: '+mode)
   return text[matches[0].start():]
  baseline=chain(scripts[mode,'baseline']);after=chain(scripts[mode,'candidate'])
  (E/('post-chain-'+mode+'-baseline.sh')).write_text(baseline);(E/('post-chain-'+mode+'-candidate.sh')).write_text(after)
  if not after.startswith(baseline):
   (E/('post-chain-'+mode+'.diff')).write_text(''.join(difflib.unified_diff(baseline.splitlines(True),after.splitlines(True),fromfile='cb679968',tofile='candidate')))
  h.require(after.startswith(baseline),'platform post chain differs from cb baseline: '+mode)
  extra=after[len(baseline):]
  h.require(re.fullmatch(r'\s*python3 [^\n]+ \|\| exit 1\s*\n\s*echo BOLT_POST_GATE_PASS\s*',extra) is not None,'unexpected BOLT post tail: '+mode)
  (E/('post-chain-'+mode+'-added.sh')).write_text(extra)
  result['modes'][mode]={'platform_post_byte_equal':True,'platform_post_sha256':hashlib.sha256(baseline.encode()).hexdigest(),'platform_post_bytes':len(baseline.encode()),'tail_is_last':True,'tail':extra,'actual_shell_argv':(E/('post-'+mode+'-candidate.shell.argv')).read_text()}
 result['status']='PASS'
except BaseException as error:
 result['status']='FAIL';result['error']=str(error);raise
finally:
 h.save(E/'post-capture-result.json',result);print(json.dumps(result,indent=2),flush=True)
