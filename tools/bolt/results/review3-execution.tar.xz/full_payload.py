from pathlib import Path,PurePosixPath
import sys,json,subprocess,os,signal,time,importlib.util,shutil
E=Path(__file__).resolve().parent;B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
packages=json.loads((E.parent/'bolt-v4-20261015-validation/RPM-baseline.json').read_text())['packages'];assert len(packages)==22
root=E/'payload-merged';root.mkdir()
budget=sum(p['regular_payload_bytes'] for p in packages)+2*h.GIB
admission=h.disk_preflight(root,budget);h.save(E/'payload-disk-admission.json',admission)
paths={};symlinks=set()
for package in packages:
    for f in package['files']:
        path=PurePosixPath(f['path']);h.require(path.is_absolute() and '..' not in path.parts,'unsafe RPM payload path')
        paths[f['path']]=f
        if f['type']=='symlink':symlinks.add(f['path'])
for name in paths:
    h.require(not any(str(p) in symlinks for p in PurePosixPath(name).parents),'symlink directory ancestor in RPM payload: '+name)
start=time.monotonic();rows=[];free=[]
for package in packages:
    rpm=Path(package['RPM_path']);h.require(h.digest(rpm)==package['RPM_sha256'],'ordinary RPM SHA changed '+str(rpm))
    label=package['name'];before=time.monotonic();a=b=None
    with (E/('payload-'+label+'.stderr')).open('wb') as err:
        try:
            a=subprocess.Popen(['rpm2cpio',str(rpm)],stdout=subprocess.PIPE,stderr=err,start_new_session=True)
            b=subprocess.Popen(['cpio','-idmu','--quiet','--no-absolute-filenames','--no-preserve-owner'],stdin=a.stdout,stdout=err,stderr=err,cwd=root,start_new_session=True)
            a.stdout.close();brc=b.wait(timeout=600);arc=a.wait(timeout=15)
        finally:
            for child in (b,a):
                if child is not None and child.poll() is None:
                    os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
    h.require(arc==brc==0,'full payload extraction failed '+label)
    row={'package':label,'RPM_sha256':package['RPM_sha256'],'rpm2cpio_rc':arc,'cpio_rc':brc,'wall_s':time.monotonic()-before,'free_bytes':shutil.disk_usage(root).free};rows.append(row);free.append(row['free_bytes']);h.save(E/'payload-extraction-progress.json',rows)
    print('EXTRACTED',label,'wall',round(row['wall_s'],3),'free',row['free_bytes'],flush=True)
inventory=h.inventory(root,hash_files=False)
missing=[name for name in paths if name.lstrip('/') not in inventory['files']]
h.require(not missing,'RPM merged payload is incomplete: '+repr(missing[:5]))
new=h.no_bolt_products(root)
spec=importlib.util.spec_from_file_location('d08_helper',E/'helper-d08.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
try:old_result={'status':'PASS','result':old.no_bolt_products(root),'false_rejection':False}
except old.GateError as error:old_result={'status':'REJECTED','error':str(error),'false_rejection':True}
result={'status':'PASS','root':str(root),'RPM_count':22,'extractions':rows,'new_helper':new,'d08_helper_evidence_only':old_result,'header_union_paths':len(paths),'merged_inventory_paths':len(inventory['files']),'cmake_paths':sum(k.lower().endswith('.cmake') for k in inventory['files']),'wall_s':time.monotonic()-start,'minimum_sampled_disk_free_bytes':min(free),'disk_admission':admission,'root_retained':True}
h.save(E/'full-payload-result.json',result);print(json.dumps({k:v for k,v in result.items() if k!='extractions'},indent=2),flush=True)
