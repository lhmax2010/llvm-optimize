from pathlib import Path
import json,sys,re,hashlib,difflib
from new_session import E,R1,INNER,HOST,root_command
B=Path('/home/linhao/Toolchain/development/llvm-optimize-bolt');sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
macros='/usr/lib/rpm/macros:/usr/lib/rpm/macros.d/macros.*:/usr/lib/rpm/platform/%{_target}/macros:/usr/lib/rpm/fileattrs/*.attr:/usr/lib/rpm/tizen/macros:/etc/rpm/macros.*:/etc/rpm/macros:/etc/rpm/%{_target}/macros:/home/abuild/.rpmmacros'
top=INNER+'/post-capture';base=HOST/'post-capture';base.mkdir(exist_ok=True)
for d in ['BUILD','BUILDROOTS','RPMS','SRPMS','SPECS','tmp']:(base/d).mkdir(exist_ok=True)
wrapper=HOST/'capture-install-shell.sh';wrapper.write_text('#!/bin/sh\nset -eu\nprintf "%s\\n" "$@" > '+h.quote(top+'/shell.argv')+'\nfor script do :; done\ncp "$script" '+h.quote(top+'/captured-script.sh')+'\nexit 0\n');wrapper.chmod(0o755)
result={'status':'RUNNING','method':'rpmbuild -bi --short-circuit; replace only __spec_install_cmd with copy-only wrapper; accept only empty BUILDROOT file-list failures after successful script capture','install_or_post_executed':False,'calls':[],'modes':{}};scripts={}
try:
 for mode in ['debug','release']:
  for tag,spec in [('baseline','llvm-baseline.spec'),('candidate','llvm-draft.spec')]:
   label='post-'+mode+'-'+tag;capture=base/'captured-script.sh'
   if capture.exists():capture.unlink()
   argv=['/usr/bin/rpmbuild','--macros='+macros,'-bi','--short-circuit','--nodeps','--nosignature','--target=x86_64','--define','_topdir '+top,'--define','_sourcedir '+INNER,'--define','_builddir '+top+'/BUILD','--define','_buildrootdir '+top+'/BUILDROOTS','--define','_tmppath '+top+'/tmp','--buildroot',top+'/BUILDROOT','--define','__spec_install_cmd '+INNER+'/capture-install-shell.sh %{___build_args}','--define','_build_create_debug 1','--define','_srcdefattr (-,root,root)']
   argv+=['--define','_toolchain clang'] if mode=='debug' else ['--undefine','_toolchain']
   argv+=[INNER+'/'+spec]
   command='. '+h.quote(INNER+'/rpm-env-prefix.sh')+'; exec python3 '+h.quote(INNER+'/record_call.py')+' '+h.quote(label)+' '+' '.join(h.quote(x) for x in argv)
   p=root_command(['/bin/sh','-c',command],True,capture_output=True,text=True,timeout=120)
   (E/(label+'.stdout')).write_text(p.stdout);(E/(label+'.stderr')).write_text(p.stderr)
   combined=p.stdout+'\n'+p.stderr
   errors=[s for s in combined.splitlines() if s.startswith(('error:','fatal:'))]
   allowed=re.compile(r'error: File not found: '+re.escape(top+'/BUILDROOT')+r'/[^\n]+')
   unexpected=[s for s in errors if not allowed.fullmatch(s)]
   receipt=json.loads((HOST/'calls'/(label+'.json')).read_text());receipt.update(file_list_error_count=len(errors),unexpected_errors=unexpected,captured_nonempty=capture.is_file() and capture.stat().st_size>0)
   result['calls'].append(receipt)
   h.require(receipt['captured_nonempty'],'generated install script not captured: '+label)
   (E/(label+'.sh')).write_bytes(capture.read_bytes());(E/(label+'.shell.argv')).write_bytes((base/'shell.argv').read_bytes())
   h.require(not unexpected,'unexpected capture error '+label+': '+repr(unexpected[:5]))
   h.require(p.returncode==0 or (errors and 'Processing files:' in p.stdout),'non-file-list rpmbuild failure '+label)
   scripts[mode,tag]=capture.read_text()
 for mode in ['debug','release']:
  def chain(text):
   command='/usr/lib/rpm/find-debuginfo.sh' if mode=='debug' else '/usr/lib/rpm/check-buildroot'
   matches=list(re.finditer(r'^    '+re.escape(command)+r'(?: |$)',text,re.M))
   h.require(len(matches)==1,'cannot uniquely locate first platform post command: '+mode)
   return text[matches[0].start():]
  baseline=chain(scripts[mode,'baseline']);after=chain(scripts[mode,'candidate'])
  (E/('post-chain-'+mode+'-baseline.sh')).write_text(baseline);(E/('post-chain-'+mode+'-candidate.sh')).write_text(after)
  if not after.startswith(baseline):
   (E/('post-chain-'+mode+'.diff')).write_text(''.join(difflib.unified_diff(baseline.splitlines(True),after.splitlines(True),fromfile='cb679968',tofile='candidate')))
  h.require(after.startswith(baseline),'platform post chain differs from cb baseline: '+mode)
  extra=after[len(baseline):]
  h.require(re.fullmatch(r'\s*python3 [^\n]+ \|\| exit 1\s*\n\s*echo BOLT_POST_GATE_PASS\s*',extra) is not None,'unexpected BOLT post tail: '+mode)
  (E/('post-chain-'+mode+'-added.sh')).write_text(extra)
  result['modes'][mode]={'platform_post_byte_equal':True,'platform_post_sha256':hashlib.sha256(baseline.encode()).hexdigest(),'platform_post_bytes':len(baseline.encode()),'tail_is_last':True,'tail':extra,'actual_shell_argv':(E/('post-'+mode+'-candidate.shell.argv')).read_text()}
 result['status']='PASS'
except BaseException as error:
 result['status']='FAIL';result['error']=str(error);raise
finally:
 h.save(E/'post-capture-result.json',result);print(json.dumps(result,indent=2),flush=True)
