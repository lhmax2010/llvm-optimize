from pathlib import Path
import sys,json,shutil,lzma,hashlib,subprocess,re,tarfile
E=Path(__file__).resolve().parent;W=E.parent.parent;B=W.parent/'llvm-optimize-bolt';S=E.parent/'bolt-v4-20261013/v41/llvm-source';R=B/'tools/bolt/results';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
from metrics import metrics
source=json.loads((E/'source-result.json').read_text());commit=source['squashed_commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
assert (S/'packaging/clang-bolt-helper.py').read_bytes()==(B/'tools/bolt/bolt_helper.py').read_bytes()
for name in ('macro-result.json','post-capture-result.json','real-gates.json','protection-audit.json'):
 r=json.loads((E/name).read_text());assert r['status']=='PASS',name;shutil.copyfile(E/name,R/('review4b-'+name))
real=json.loads((E/'real-gates.json').read_text());assert real['security']['ordinary_sha256']=='7df0ff90dbca7f99ed6a642546281584dbfaab1528a94abf7a1bb524ca371b2c';assert real['security']['candidate_sha256']=='4ec07159aeb4f9300361b95955db05bfca06ece5b748796b28e9b8965145fff9'
assert real['helper_sha256']==source['files'][1]['sha256'] and real['current_source_commit']==commit
for p in E.glob('post-*.sh'):shutil.copyfile(p,R/('review4b-'+p.name))
for p in E.glob('macro-*.expanded.spec'):(R/('review4b-'+p.name+'.xz')).write_bytes(lzma.compress(p.read_bytes()))
for p in E.glob('real-*.stdout'):shutil.copyfile(p,R/('review4b-'+p.name+'.txt'))
for p in E.glob('real-*.stderr'):shutil.copyfile(p,R/('review4b-'+p.name+'.txt'))
for p in E.glob('real-tool-plan*.txt'):shutil.copyfile(p,R/('review4b-'+p.name))
scopes=[p.name[:-6] for p in E.glob('*-scope') if (p/'result.json').is_file()]
resources={name:metrics(name) for name in sorted(scopes)}
assert all(r['status']=='PASS' and r['cgroup_reaped'] for r in resources.values())
resources['payload']['shared_lock']=json.loads((E/'payload-lock/released.json').read_text());h.save(R/'review4b-resources.json',resources)
# User's exact commit-message edits, independently checked after git cleanup.
old=subprocess.check_output(['git','show','-s','--format=%B','8be7348a6baf9d4b8b55c382b8a04dade712208d'],cwd=S,text=True)
new=subprocess.check_output(['git','show','-s','--format=%B',commit],cwd=S,text=True)
oldtail='Maintenance and profile retraining instructions: docs/bolt/maintenance.md\nin the llvm-optimize bolt-v4 evidence repository. Quickbuild and real-tree\nrehearsal are started by the user after PM review of this patch/evidence.'
assert old.replace(oldtail,'Maintenance notes: header of packaging/clang-bolt-helper.py')==new
assert new.count('Change-Id: '+source['Change-Id'])==1 and new.count('Signed-off-by: Hao Lin <hao.lin@samsung.com>')==1
assert 'github' not in new.lower()
h.save(R/'review4b-commit-message-check.json',{'status':'PASS','exact_requested_replacement_only':True,'Change-Id':source['Change-Id'],'author_committer':source['author_committer'],'internal_PM_sentence_absent':True,'external_GitHub_maintenance_pointer_absent':True,'new_message':new})
# Portable internal maintenance guide; training commands remain documentation only.
s=(E/'maintenance-draft.md').read_text().replace('建立与基线同名的clang++调用方式及明确--driver-mode=g++，核对','建立与基线同名的clang++调用方式；ARM脚本按argv[0]选择g++模式，AArch64扩展显式加--driver-mode=g++。核对')
s=s.replace('路径变量是维护者核定的新快照目录。','路径变量是维护者核定的新快照目录。训练脚本输出须在其WORKSPACE/temp下使用新目录，不直接运行硬编码旧现场的phase入口。')
s=s.replace('5. 对去debug的重链输入执行正式OPTIONS', '''压缩和登记命令示例（新profile的SHA必须重新登记，不能沿用旧值）：

```sh
xz -9e -c "$BOLT_AARCH64_COLLECTION/merged-v2.fdata" > "$BOLT_STAGE/clang-bolt-v2.fdata.xz"
sha256sum "$BOLT_AARCH64_COLLECTION/merged-v2.fdata" "$BOLT_STAGE/clang-bolt-v2.fdata.xz"
```

记录xz版本/参数及输出大小，发布前重新检查单文件大小约束。

5. 对去debug的重链输入执行正式OPTIONS''')
(B/'docs/bolt/maintenance.md').write_text(s)
p=B/'docs/bolt/23_closure_post_certification.md';s=p.read_text();note='\n十四B复核：本报告引用的review3-tests.stdout.txt实际为0字节，review3-tests.stderr.txt保留214项原文；后续257项完整原文是review4b-tests.stdout/stderr.txt，另记24，不替换十三A的历史计数。上述闭包证明仍限保存的静态图，未加载.ninja_deps/depfile或完整dirty状态。\n'
assert (R/'review3-tests.stdout.txt').stat().st_size==0
if '十四B复核：' not in s:s+=note
p.write_text(s)
macro=json.loads((E/'macro-result.json').read_text());post=json.loads((E/'post-capture-result.json').read_text())
report='''\n## 续跑十四B最终本地认证（sandbox待推）

总状态：本地认证PASS。最终源`%s`，父`67619ec8bbbac7238a6cfc33a481ccfbcd12206f`，新sandbox尚未推；材料先GitHub，全部公开后才执行已授权推送。没有启动QB或真实树演练。

|本轮要求|结果|证据前缀tools/bolt/results/review4b-|
|---|---|---|
|保全22RPM对docs35附录A大小/SHA|PASS，22/22；不使用docs38包|RPM-identities.json|
|来源spec/Source1005逐字比对|Source相同；spec仅构建差异，%%install及其后逐字相同；准许继续|source-audit.json、llvm.spec.diff、llvm-static-archives-native.py.diff|
|完整合并载荷|PASS，17722路径/47 cmake；旧8be helper及最终helper均检查通过|full-payload-result.json、real-gates.json|
|提交说明两处与嵌入维护|PASS，AST不变、spec/profile不变、Change-Id和Hao Lin署名保持|source-result.json、commit-message-check.json|
|全部夹具|PASS，257=原252+安装顺序1+本轮4；stdout0字节|tests.stdout.txt、tests.stderr.txt、tests-source-certification.json|
|独立index完整二进制patch应用/整树|PASS，tree一致；完整binary patch仅留E，公开文本patch+Source|tests-source-certification.json|
|OFF两模式与67619ec8逐字展开|PASS，debug %d段/release %d段全部一致|macro-result.json、macro-*.expanded.spec.xz|
|ON两模式顺序及OFF转换保留|PASS，snapshot < compare-root < 转换 < install；ON/OFF转换均一次|macro-result.json|
|四份新生成post脚本|PASS，原平台链逐字一致，BOLT尾检最后；debug有FD、release有brp-strip|post-*.sh、post-capture-result.json|
|7df/4ec安全属性|PASS（包括shndx和RPATH/RUNPATH），无属性丢失；两边均无GNU property/CET|real-gates.json、real-security.stdout.txt|
|三目标tiny|PASS，ordinary/candidate完整.o逐字相同，含--no-default-config|real-gates.json、real-tiny.stdout.txt|
|debug/release双根post、反向检查、compare-root|PASS；注入BOLT工具负例被拒，最终SHA不变|real-gates.json、real-post-*.stdout.txt|
|111描述计划正例+普通任务负例|PASS；真实Ninja未执行|real-tool-plan*.txt、real-gates.json|
|受保护树/RPM、原坏配置/缓存、归档证据|PASS，旧文件及4ec未变，原树未运行cmake/ninja/-P|protection-audit.json|
|维护完整版/23说明/manifest/原文与raw索引|已完成，先公开材料后推sandbox|maintenance.md、draft-manifest.json|
|QB、真实树演练、发布模式完整构建、accel/worker实物身份|NOT RUN，仍需后续现场验证|不得由本轮本地认证冒充|

### 后处理与安全要点

新基线debug平台post %d字节、release %d字节；四次捕获均只因空BUILDROOT文件清单错误退出，脚本存在且非空，错误均为预期File not found类别，wrapper没有执行%%install或平台post。真实双根只执行helper尾检；不把采集当作完整%%install实际执行。新helper文件头变更纳入重新采集与真实运行。

候选仍为4ec07159aeb4f9300361b95955db05bfca06ece5b748796b28e9b8965145fff9，普通仍7df0ff90dbca7f99ed6a642546281584dbfaab1528a94abf7a1bb524ca371b2c。本轮不生成候选、不改重链/strip/BOLT参数、不重训profile、不重测先前已认证的性能或120份对象；维持历史工具后备路线。Quickbuild后续应看自己的匹配统计同量级且5%%双门禁PASS、tool-plan/真实构建与TF SHA、compare-root、post/包/DWARF/debugsource清单及自身clang性能，不比较本地与QB clang SHA。

### 资源与准备记录

重阶段payload scope %.3fs，共享锁%.3fs，cgroup峰%dB；准入与运行MemAvailable、每进程VmHWM、swap0/nice/ionice、磁盘预检与scope回收见resources.json及execution包。全部scope回收、各proc挂载finally卸载。单次大写入预检预计写后约316.8GB，实际最低抽样剩余%dB，高于30GiB。

查找阶段更正：曾在源子仓库用W相对路径，改正后才进行产品操作；曾查找不存在的十四A real_gates.py，随后定位并复用十三A脚本，执行前适配111描述及现有错误文本。技能清单的符号链接路径经rg --follow/已安装根定位。均未作为产品输入使用，不计准备错误。产品步骤准备错误修正0次，产品门禁失败0次。

发布前按ship技能适用检查审阅源差异、身份与新鲜测试：本次可执行代码AST无变化、说明文本变更范围准确，无新增审查问题。用户固定父提交/单提交/写入范围/直接sandbox/不提问规则优先于通用PR与全局状态流程；未扩展为PR、版本变更或其他目录写入。
'''%(commit,len(macro['modes']['debug']['OFF_byte_equal_sections']),len(macro['modes']['release']['OFF_byte_equal_sections']),post['modes']['debug']['platform_post_bytes'],post['modes']['release']['platform_post_bytes'],resources['payload']['scope_wall_s'],resources['payload']['shared_lock']['held_s'],resources['payload']['cgroup_peak_bytes'],json.loads((E/'full-payload-result.json').read_text())['minimum_sampled_disk_free_bytes'])
p=B/'docs/bolt/24_rebase_recertification.md';text=p.read_text();text=text.replace('# 24 续跑十四：第三轮修复、变基与停止记录','# 24 第三轮修复、变基与十四B重新认证',1);text=text.replace('以下为十四A历史记录；十四B处置与进展见文末。','当前：十四B本地认证全部PASS，sandbox待推；十四B结果在文末。以下十四A记录是保留的历史停止原文，已由十四B的PM裁决纠正来源解释。',1);text+=report;p.write_text(text)
p=B/'docs/bolt/STATUS.md';s=p.read_text();a=s.index('## 2026-10-15 续跑十四B：');s=s[:a]+'''## 2026-10-15 续跑十四B：本地认证PASS，sandbox待推

PM裁决：docs35原22包在W/temp/archive-fix-v2-final-20261009/rpms-docs35，旧R/RPMS为docs38；十四A停止是来源路径问题，不是产品问题。逐包对照docs35附录A的字节/SHA后使用保全包，Source1005与67619ec8字节相同，spec差异不涉及.cmake安装/%%files（%%install起后文全相同），照常继续。两组历史包均不称作67619ec8新构建物。

最终压缩源%s，父67619ec8bbbac7238a6cfc33a481ccfbcd12206f；仅新增helper文件头维护说明，修改提交说明的内部流程/外部维护入口；可执行AST、spec/profile不变，Hao Lin作者/提交者/Signed-off-by及Change-Id保留。257/257测试PASS（252+安装顺序1+本轮4），最后两项日志诊断微调已覆盖，stdout为空、stderr原文公开；完整二进制补丁独立index apply/tree PASS，公开--no-binary文本patch及单独Source，不再误发超限文件。

22RPM逐包身份PASS；完整合并根no_bolt_products 17722路径/47cmake，最终helper复查PASS。新压缩提交OFF debug20/release18段与新基线逐字相同，ON顺序snapshot<compare-root<转换<install且转换一次；四post平台段逐字一致、尾检最后；真实7df/4ec安全、tiny三目标、双根post/反向/compare-root、111计划正负例全PASS。4ec候选未重生成。受保护22RPM/归档证据/原坏配置/缓存/源码未变，锁/proc/scope回收。产品准备修正0次、产品门禁失败0次；查找更正见24。

维护完整版见maintenance.md（四remedy、运行前提、升级与重训、锚点、资料保留/崩溃/回退）；23已明确静态图边界与stdout实际为空。上次GitHub ls-remote已补核PASS。材料先GitHub公开，才按授权推新sandbox/lhmax2025/bolt_pgo_v2；当前待推，旧sandbox/refs-for/tizen_base不动。QB/真实树演练/发布全构建及accel-worker身份仍NOT RUN，用户在PM审完后启动。完整状态/资源/原文见24和review4b系列。
'''%commit;p.write_text(s)
p=B/'patches/bolt/draft-manifest.json';m=json.loads(p.read_text());m.update(qualification='ALL_LOCAL_14B_GATES_PASS; MATERIALS_BEFORE_NEW_SANDBOX',sandbox_pushed=False,gerrit_review_pushed=False,post_capture='PASS fresh baseline/candidate debug/release on final squashed commit; original platform bytes equal; BOLT tail last',disabled_macro_proof='review4b-macro-result.json',post_proof='review4b-post-capture-result.json',real_product_proof='review4b-real-gates.json',payload_check='PASS preserved docs35 22 identities and complete root; final helper 17722 paths/47 cmake',source_comparison='Source1005 equal; spec differences limited to build; %install and later text byte equal',maintenance_notes='packaging/clang-bolt-helper.py header',internal_maintenance_guide='docs/bolt/maintenance.md',publication_order='All source/test/post/payload/maintenance materials first on GitHub; then push new sandbox branch without force',final_squashed_tests='257/257 PASS on '+commit,publication_correction='Historical oversized artifact retained in old cad1c935; current public patch explicitly --no-binary; full binary patch only local');p.write_text(json.dumps(m,indent=2)+'\n')
# Complete execution log excludes product payloads and oversized local binary patches.
with tarfile.open(R/'review4b-execution.tar.xz','w:xz') as t:
 for p in sorted(E.rglob('*')):
  rel=p.relative_to(E)
  if rel.parts[0]=='payload-merged' or '__pycache__' in rel.parts:continue
  if p.is_file() and not p.is_symlink() and p.stat().st_size<10_000_000 and p.name not in ('apply.index','squashed-complete-binary.patch.xz'):
   t.add(p,arcname=rel.as_posix(),recursive=False)
for p in (B/'docs/bolt/STATUS.md',B/'docs/bolt/24_rebase_recertification.md',B/'docs/bolt/23_closure_post_certification.md',B/'docs/bolt/maintenance.md'):assert p.stat().st_size<50000,(p,p.stat().st_size)
for p in R.glob('review4b-*'):assert p.stat().st_size<10_000_000,p
print(json.dumps({'status':'ALL_LOCAL_GATES_PASS_MATERIALS_READY','source_commit':commit,'resources':{k:{n:v[n] for n in ('scope_wall_s','cgroup_peak_bytes')} for k,v in resources.items()}},indent=2))
