from pathlib import Path,PurePosixPath
import re,json,sys,subprocess,stat,shutil,time,os,signal
E=Path(__file__).resolve().parent;W=E.parent.parent;B=W.parent/'llvm-optimize-bolt';S=E.parent/'bolt-v4-20261013/v41/llvm-source';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
h.require((S/'packaging/clang-bolt-helper.py').read_bytes()==(B/'tools/bolt/bolt_helper.py').read_bytes(),'helper mirrors differ before payload')
old=(W/'temp/llvm-strip-x86_64-20261009/continue-20261009/trial-before.spec').read_text();new=(E/'baseline-llvm.spec').read_text()
h.require(old[old.index('%install\n'):]==new[new.index('%install\n'):],'.cmake installation/%files source comparison differs')
audit=json.loads((E/'source-audit.json').read_text());audit.update(decision='PASS; differences confined to build dependencies/compiler/flags/library linkage; %install and entire subsequent text byte equal',install_and_files_tail_byte_equal=True);h.save(E/'source-audit.json',audit)
doc=(W/'docs/35_archive_fix_v2_final.md').read_text();table=doc[doc.index('## 附录A：'):];expected=re.findall(r'^\| (\S+\.rpm) \| (\d+) \| `([0-9a-f]{64})` \|$',table,re.M);h.require(len(expected)==22,'docs35 Appendix A must list exactly 22 RPMs')
rpmdir=W/'temp/archive-fix-v2-final-20261009/rpms-docs35';identities=[];packages=[]
for name,size,sha in expected:
 path=rpmdir/name;actual_size=path.stat().st_size;actual_sha=h.digest(path)
 row={'path':str(path),'name':name,'expected_bytes':int(size),'actual_bytes':actual_size,'expected_sha256':sha,'actual_sha256':actual_sha};identities.append(row);h.save(E/'RPM-identity-progress.json',identities)
 h.require(actual_size==int(size) and actual_sha==sha,'preserved docs35 RPM identity mismatch: '+name)
 print('RPM_IDENTITY_PASS',name,flush=True)
h.save(E/'RPM-identities.json',{'status':'PASS','count':22,'source':'docs35 Appendix A; preserved rpms-docs35; not a 67619ec8 build','docs35_sha256':h.digest(W/'docs/35_archive_fix_v2_final.md'),'files':identities})
fmt='[%{FILENAMES}\t%{FILEMODES}\t%{FILEDIGESTS}\t%{FILELINKTOS}\t%{LONGFILESIZES}\n]'
paths={};symlinks=set()
for row in identities:
 p=Path(row['path']);q=subprocess.run(['rpm','-qp','--qf',fmt,str(p)],capture_output=True,text=True);h.require(q.returncode==0,'RPM header query failed '+str(p))
 files=[]
 for line in q.stdout.splitlines():
  name,mode,digest,target,size=line.split('\t');mode=int(mode);path=PurePosixPath(name);h.require(path.is_absolute() and '..' not in path.parts,'unsafe RPM payload path '+name)
  kind='file' if stat.S_ISREG(mode) else 'symlink' if stat.S_ISLNK(mode) else 'dir' if stat.S_ISDIR(mode) else 'special';h.require(kind!='special','special RPM path '+name)
  item={'path':name,'type':kind,'bytes':int(size)};files.append(item);paths[name]=item
  if kind=='symlink':symlinks.add(name)
 packages.append({'name':p.name,'path':str(p),'sha256':row['actual_sha256'],'files':files,'payload_bytes':sum(f['bytes'] for f in files if f['type']=='file')})
for name in paths:h.require(not any(str(p) in symlinks for p in PurePosixPath(name).parents),'symlink directory ancestor '+name)
root=E/'payload-merged';root.mkdir();budget=sum(p['payload_bytes'] for p in packages)+2*h.GIB;admission=h.disk_preflight(root,budget);h.save(E/'payload-disk-admission.json',admission)
start=time.monotonic();rows=[]
for package in packages:
 a=b=None;before=time.monotonic()
 with (E/('payload-'+package['name']+'.stderr')).open('wb') as err:
  try:
   a=subprocess.Popen(['rpm2cpio',package['path']],stdout=subprocess.PIPE,stderr=err,start_new_session=True)
   b=subprocess.Popen(['cpio','-idmu','--quiet','--no-absolute-filenames','--no-preserve-owner'],stdin=a.stdout,stdout=err,stderr=err,cwd=root,start_new_session=True);a.stdout.close();brc=b.wait(timeout=600);arc=a.wait(timeout=15)
  finally:
   for child in (b,a):
    if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 h.require(arc==brc==0,'payload extraction failed '+package['name'])
 rows.append({'package':package['name'],'rpm2cpio_rc':arc,'cpio_rc':brc,'wall_s':time.monotonic()-before,'free_bytes':shutil.disk_usage(root).free});h.save(E/'payload-progress.json',rows);print('EXTRACTED',package['name'],round(rows[-1]['wall_s'],3),flush=True)
inventory=h.inventory(root,hash_files=False);missing=[name for name in paths if name.lstrip('/') not in inventory['files']];h.require(not missing,'merged payload missing '+repr(missing[:5]))
r=h.no_bolt_products(root);h.save(E/'full-payload-result.json',{'status':'PASS','source':'preserved docs35 22 RPMs; not a newly built 67619ec8 set','root':str(root),'helper_sha256':h.digest(S/'packaging/clang-bolt-helper.py'),'helper_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'RPM_count':22,'paths_checked':r['paths_checked'],'cmake_files_checked':r['cmake_files_checked'],'no_bolt_products':r,'wall_s':time.monotonic()-start,'extractions':rows,'disk_admission':admission,'minimum_sampled_disk_free_bytes':min(x['free_bytes'] for x in rows)});print('PAYLOAD_GATE_PASS',json.dumps(r),flush=True)
