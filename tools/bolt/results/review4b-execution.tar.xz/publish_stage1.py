from pathlib import Path
import json,shutil
E=Path(__file__).resolve().parent;B=E.parent.parent.parent/'llvm-optimize-bolt';R=B/'tools/bolt/results'
r=json.loads((E/'full-payload-result.json').read_text());assert r['status']=='PASS'
for name in ('source-audit.json','llvm.spec.diff','llvm-static-archives-native.py.diff','RPM-identities.json','full-payload-result.json','payload-disk-admission.json','opening-publication-ls-remote.json'):
 shutil.copyfile(E/name,R/('review4b-'+name))
p=B/'docs/bolt/STATUS.md';s=p.read_text();marker='## 2026-10-15 续跑十四：STOP，RPM身份不符，新sandbox未推';a=s.index(marker);s=s[:a]+'''## 2026-10-15 续跑十四A（历史STOP）

源8be7348a6baf9d4b8b55c382b8a04dade712208d父67619ec8，RPM身份停止，sandbox未推。完整修复、252阶段夹具/宏/post及停止/发布纠正见24与ac56ad25aeda6a96ea5d9488c4b885e60a19d203版STATUS。十四B的PM裁决已解释为旧路径指向docs38产物，未发现产品问题；不删除历史证据。

## 2026-10-15 续跑十四B：进行中

PM裁决：docs35原22包已移至W/temp/archive-fix-v2-final-20261009/rpms-docs35；原R/RPMS为docs38，不能混用或称为67619ec8新构建物。逐包核对docs35附录A后才解包；Source/spec差异若涉及.cmake安装或%%files则停止。作者/提交者/Signed-off-by为Hao Lin，保留Change-Id；生成参数、profile和4ec候选不变；原树禁cmake/ninja/-P，保护/资源/锁规则不变。全部认证PASS、材料先GitHub后，才推新sandbox/lhmax2025/bolt_pgo_v2，不推旧分支/评审/tizen_base；QB由用户在PM审完后启动。

阶段1 PASS：保全22 RPM字节与SHA逐项符合docs35附录A；完整合并根no_bolt_products PASS，paths_checked=%d、cmake_files_checked=%d。Source1005与67619ec8逐字节相同；spec仅构建相关差异，%%install至文件末尾逐字相同，不涉及.cmake安装或%%files。GitHub ls-remote补核PASS，起点ac56ad2。新压缩提交及后续认证尚待完成。
'''%(r['paths_checked'],r['cmake_files_checked']);p.write_text(s)
p=B/'docs/bolt/24_rebase_recertification.md';s=p.read_text();s=s.replace('STOP；压缩源提交','以下为十四A历史记录；十四B处置与进展见文末。\n\nSTOP；压缩源提交',1)
s+='''\n## 续跑十四B：RPM来源纠正与阶段1\n\nPM确认上一轮不是产品问题：旧R/RPMS现存docs38试构建22包，6317baba符合docs38附录A；docs35原件在rpms-docs35，经docs38记录的rename保全。按新授权，逐一用docs35附录A核对保全22包大小/SHA，全部一致后完整合并解包。未读取docs38的RPM载荷，未称任何历史集为67619ec8新构建物。\n\n阶段1 PASS：paths_checked=%d、cmake_files_checked=%d。Source1005字节相同；spec差异为构建依赖、编译器/优化参数与动态链接配置，%%install及之后文本逐字相同，不触及.cmake安装/%%files；完整diff与来源身份公开。最终helper文档更新后还会在同根重跑反向检查。\n\n补做GitHub远端查询成功，起点ac56ad25aeda6a96ea5d9488c4b885e60a19d203。本轮查找曾在源子仓库使用W相对路径，发现不存在后在产品操作前改正；查找阶段不计准备错误，原文记录保留。\n'''%(r['paths_checked'],r['cmake_files_checked']);p.write_text(s)
for p in (B/'docs/bolt/STATUS.md',B/'docs/bolt/24_rebase_recertification.md'):assert p.stat().st_size<50000
print(json.dumps({'stage1':'PASS','paths_checked':r['paths_checked'],'cmake_files_checked':r['cmake_files_checked']}))
