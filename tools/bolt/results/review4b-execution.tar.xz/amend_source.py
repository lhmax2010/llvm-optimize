from pathlib import Path
import subprocess,ast,json,hashlib,sys
E=Path(__file__).resolve().parent;W=E.parent.parent;B=W.parent/'llvm-optimize-bolt';S=E.parent/'bolt-v4-20261013/v41/llvm-source'
def git(*args):return subprocess.check_output(['git',*args],cwd=S)
old=git('rev-parse','HEAD').decode().strip();assert old=='8be7348a6baf9d4b8b55c382b8a04dade712208d'
p=S/'packaging/clang-bolt-helper.py';before=p.read_text();header=(E/'helper-header.txt').read_text().rstrip();a=before.index('"""');b=before.index('"""',a+3)+3;after=before[:a]+header+before[b:]
def normalized(s):
 module=ast.parse(s);assert isinstance(module.body[0],ast.Expr) and isinstance(module.body[0].value,ast.Constant);module.body=module.body[1:];return ast.dump(module,include_attributes=False)
assert normalized(before)==normalized(after),'helper change must be docstring only'
p.write_text(after);(B/'tools/bolt/bolt_helper.py').write_text(after)
message=git('log','-1','--format=%B').decode();ending='Maintenance and profile retraining instructions: docs/bolt/maintenance.md\nin the llvm-optimize bolt-v4 evidence repository. Quickbuild and real-tree\nrehearsal are started by the user after PM review of this patch/evidence.'
assert message.count(ending)==1
newmessage=message.replace(ending,'Maintenance notes: header of packaging/clang-bolt-helper.py')
assert newmessage.split('Change-Id: ')[1].splitlines()[0]==message.split('Change-Id: ')[1].splitlines()[0]
(E/'source-commit-message.txt').write_text(newmessage)
subprocess.run(['git','add','packaging/clang-bolt-helper.py'],cwd=S,check=True)
subprocess.run(['git','-c','user.name=Hao Lin','-c','user.email=hao.lin@samsung.com','commit','--amend','--reset-author','-F',str(E/'source-commit-message.txt')],cwd=S,check=True)
new=git('rev-parse','HEAD').decode().strip();parent=git('rev-parse','HEAD^').decode().strip();assert parent=='67619ec8bbbac7238a6cfc33a481ccfbcd12206f'
for name in ('llvm.spec','clang-bolt-v2.fdata.xz'):
 assert git('show',old+':packaging/'+name)==git('show',new+':packaging/'+name)
result={'status':'PASS','old_squashed_commit':old,'squashed_commit':new,'parent':parent,'helper_change':'module docstring only; AST of all executable statements byte-equivalent via ast.dump without attributes','spec_byte_unchanged':True,'profile_byte_unchanged':True,'Change-Id':newmessage.split('Change-Id: ')[1].splitlines()[0],'author_committer':git('show','-s','--format=%an <%ae>%n%cn <%ce>','HEAD').decode(),'files':[{'path':'packaging/'+name,'sha256':hashlib.sha256((S/'packaging'/name).read_bytes()).hexdigest(),'bytes':(S/'packaging'/name).stat().st_size} for name in ('llvm.spec','clang-bolt-helper.py','clang-bolt-v2.fdata.xz')]}
(E/'source-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
