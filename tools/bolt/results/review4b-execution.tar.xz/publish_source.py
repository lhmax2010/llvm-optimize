from pathlib import Path
import subprocess,os,json,hashlib,shutil,lzma,re
E=Path(__file__).resolve().parent;W=E.parent.parent;B=W.parent/'llvm-optimize-bolt';S=E.parent/'bolt-v4-20261013/v41/llvm-source';R=B/'tools/bolt/results'
r=json.loads((E/'source-result.json').read_text());assert r['status']=='PASS'
stderr=(E/'tests.stderr.txt').read_text();assert re.search(r'Ran 257 tests in .*\n\nOK\n',stderr)
patch=subprocess.check_output(['git','format-patch','-1','--stdout','--binary'],cwd=S);p=E/'squashed-complete-binary.patch';p.write_bytes(patch)
(E/'squashed-complete-binary.patch.xz').write_bytes(lzma.compress(patch))
env=dict(os.environ,GIT_INDEX_FILE=str(E/'apply.index'))
for cmd in (['git','read-tree',r['parent']],['git','apply','--cached','--binary',str(p)]):subprocess.run(cmd,cwd=S,env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=S,env=env,text=True).strip();expected=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=S,text=True).strip();assert tree==expected
p=B/'patches/bolt/0000-clang-bolt-squashed.patch';p.write_bytes(subprocess.check_output(['git','format-patch','-1','--stdout','--no-binary'],cwd=S));assert p.stat().st_size<10_000_000
for n,target in [('packaging/llvm.spec','review4b-final.spec'),('packaging/clang-bolt-helper.py','review4b-final-helper.py')]:shutil.copyfile(S/n,R/target)
for name in ('source-result.json','tests.stdout.txt','tests.stderr.txt'):shutil.copyfile(E/name,R/('review4b-'+name))
evidence={'status':'PASS','tests':257,'original_tests':252,'install_order_tests':1,'new_tests':4,'stdout_bytes':(E/'tests.stdout.txt').stat().st_size,'stderr_bytes':(E/'tests.stderr.txt').stat().st_size,'current_source_commit':r['squashed_commit'],'helper_sha256':r['files'][1]['sha256'],'helper_AST_unchanged':True,'apply_check':True,'tree_equal':True,'tree':tree,'full_binary_patch_local':str(E/'squashed-complete-binary.patch.xz'),'full_binary_patch_sha256':hashlib.sha256(patch).hexdigest(),'full_binary_patch_bytes':len(patch),'public_text_patch_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(E/'tests-source-certification.json').write_text(json.dumps(evidence,indent=2)+'\n');(R/'review4b-tests-source-certification.json').write_text(json.dumps(evidence,indent=2)+'\n')
p=B/'patches/bolt/draft-manifest.json';m=json.loads(p.read_text());m.update(draft_commit=r['squashed_commit'],squashed_commit=r['squashed_commit'],amended_from=r['old_squashed_commit'],tree=tree,files=r['files'],fixtures=257,final_squashed_tests='257/257 PASS; includes both final logging refinements',apply_check=True,tree_equal=True,sandbox_pushed=False,gerrit_review_pushed=False,qualification='HEADER_ONLY_CHANGE_AND_257_TESTS_PASS; FINAL_MACROS_POST_REAL_GATES_PENDING',payload_check='docs35 preserved 22 SHA/size PASS; complete merged root PASS 17722 paths/47 cmake',Change_Id=r['Change-Id'])
m['patch']['sha256']=evidence['public_text_patch_sha256'];m['patch']['complete_binary_format_patch']=False;m['patch']['full_binary_patch_local_only']='complete binary patch retained locally; public text patch plus separately tracked binary Source';p.write_text(json.dumps(m,indent=2)+'\n')
p=B/'docs/bolt/24_rebase_recertification.md';s=p.read_text();s+='''\n### 十四B阶段2–3：提交维护说明与全部测试\n\n新压缩源%s，父67619ec8，Change-Id保留，作者/提交者/Signed-off-by均Hao Lin。只更新helper模块docstring的维护说明，去掉提交说明里的内部PM启动流程，维护入口改为helper文件头；其余提交说明不变。AST逐字表示相同（去除docstring及位置属性），spec/profile字节保持。新增4夹具覆盖文件头/可执行AST和两处最终日志诊断细化；252+安装顺序1+新增4=257/257 PASS，stdout %d字节、stderr完整原文已发布。独立index应用含二进制完整补丁后tree与源提交相同。公开0000用显式--no-binary，profile Source单独保留；完整二进制补丁本地保存，不再误发超限材料。\n'''%(r['squashed_commit'],evidence['stdout_bytes']);p.write_text(s)
print(json.dumps(evidence,indent=2))
