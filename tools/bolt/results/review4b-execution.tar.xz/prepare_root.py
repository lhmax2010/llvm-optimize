from pathlib import Path
import shutil,subprocess,re,json
E=Path(__file__).resolve().parent;old=E.parent/'bolt-v4-20261015-review4';S=E.parent/'bolt-v4-20261013/v41/llvm-source'
for name in ('new_session.py','metrics.py'):
 (E/name).write_text((old/name).read_text().replace('bolt-v4-20261015-review4','bolt-v4-20261015-review4b'))
from new_session import R1,HOST,INNER
HOST.mkdir(exist_ok=False);(HOST/'tmp').mkdir()
for name in ('rpm-env-prefix.sh','record_call.py'):
 shutil.copyfile(R1/'home/abuild/bolt-work/bolt-v4-20261015-review4'/name,HOST/name)
for path in (R1/'home/abuild/rpmbuild/SOURCES').iterdir():(HOST/path.name).symlink_to('/home/abuild/rpmbuild/SOURCES/'+path.name)
for name in ('llvm.spec','clang-bolt-helper.py','clang-bolt-v2.fdata.xz','llvm-static-archives-native.py'):
 dest=HOST/('llvm-draft.spec' if name=='llvm.spec' else name)
 if dest.is_symlink():dest.unlink()
 shutil.copyfile(S/'packaging'/name,dest)
(HOST/'llvm-baseline.spec').write_bytes(subprocess.check_output(['git','show','67619ec8bbbac7238a6cfc33a481ccfbcd12206f:packaging/llvm.spec'],cwd=S))
macros=(R1/'home/abuild/.rpmmacros').read_text();(HOST/'release.rpmmacros').write_text('\n'.join(l for l in macros.splitlines() if not re.match(r'^%_toolchain(?:\s|$)',l))+'\n')
p=HOST/'post-capture/BUILD/llvm-22.1.8';p.mkdir(parents=True);shutil.copyfile(S/'packaging/llvm.manifest',p/'llvm.manifest')
for name in ('macros.py','capture_post.py'):(E/name).write_bytes((old/name).read_bytes())
# Proven real-gate driver, updated to the certified 111-description set and new error wording.
s=(E.parent/'bolt-v4-20261015-review3/real_gates.py').read_text()
s=s.replace("/review-tool-descriptions.json'","/review-tool-descriptions-v2.json'") if False else s.replace("results/review-tool-descriptions.json","results/review-tool-descriptions-v2.json")
s=s.replace("'[%d/110] %s'%(i+1,desc)","'[%d/%d] %s'%(i+1,len(descriptions),desc)").replace("'[%d/111] %s'%(i+1,desc)","'[%d/%d] %s'%(i+1,len(descriptions)+1,desc)")
s=s.replace("'unapproved BOLT task: '+bad in str(error)","'unapproved BOLT task:' in str(error) and bad in str(error)")
s=s.replace("result['status']='PASS';h.save", "result['full_payload_current_helper']=h.no_bolt_products(E/'payload-merged')\nresult['current_source_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()\nresult['helper_sha256']=h.digest(S/'packaging/clang-bolt-helper.py')\nresult['status']='PASS';h.save")
(E/'real_gates.py').write_text(s)
(E/'unit_tests.py').write_bytes((old/'unit_tests.py').read_bytes())
(E/'root-prepared.json').write_text(json.dumps({'root_work':str(HOST),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'macro_environment':'debug original .rpmmacros + _build_create_debug 1; release private .rpmmacros copy removing only _toolchain, no _build_create_debug'},indent=2)+'\n')
