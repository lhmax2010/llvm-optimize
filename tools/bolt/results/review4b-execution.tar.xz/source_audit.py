from pathlib import Path
import json,hashlib,subprocess,difflib,sys
E=Path(__file__).resolve().parent;W=E.parent.parent;B=W.parent/'llvm-optimize-bolt';S=E.parent/'bolt-v4-20261013/v41/llvm-source';sys.path.insert(0,str(B/'tools/bolt'));import bolt_helper as h
oldspec=W/'temp/llvm-strip-x86_64-20261009/continue-20261009/trial-before.spec'
exported=W/'temp/llvm-strip-x86_64-20261009/continue-20261009/exported-before.spec'
oldsource=W/'temp/gbs-root-x86_64-archivefix-v2/local/BUILD-ROOTS/scratch.x86_64.0/home/abuild/rpmbuild/SOURCES/llvm-static-archives-native.py'
expected={oldspec:'6a91a0bf3d8d2044473662b65ed3d32d4696a697ccd52200d983ce4334aeafdf',exported:'91f684691eb35af52b1a9f2a2cba478f88dbfd8a48b4c2281dac6144d71d3bd0',oldsource:'6bd0546a63bd50151296a366ce0e7c688d774e91a36015ba194227e4ca092557'}
checked=[]
for p,sha in expected.items():
 actual=h.digest(p);checked.append({'path':str(p),'expected_sha256':sha,'actual_sha256':actual});h.require(actual==sha,'docs35 source evidence identity mismatch: '+str(p))
results={}
for name,old in [('llvm.spec',oldspec),('llvm-static-archives-native.py',oldsource)]:
 new=subprocess.check_output(['git','show','67619ec8bbbac7238a6cfc33a481ccfbcd12206f:packaging/'+name],cwd=S)
 (E/('baseline-'+name)).write_bytes(new);before=old.read_bytes();diff=''.join(difflib.unified_diff(before.decode().splitlines(True),new.decode().splitlines(True),fromfile='docs35/'+name,tofile='67619ec8/'+name))
 (E/(name+'.diff')).write_text(diff);results[name]={'byte_equal':before==new,'old_sha256':hashlib.sha256(before).hexdigest(),'new_sha256':hashlib.sha256(new).hexdigest(),'diff_file':name+'.diff'}
h.save(E/'source-audit.json',{'checked':checked,'comparisons':results,'decision':'PENDING_DIFF_REVIEW'});print(json.dumps(results,indent=2))
